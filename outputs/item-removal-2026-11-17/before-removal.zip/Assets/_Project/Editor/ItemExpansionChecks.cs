using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Necrocis;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Tilemaps;

namespace NecrocisEditor
{
    public sealed class ExpansionCheckBiome : BiomeManager
    {
        protected override void Awake()
        {
            biomeType = BiomeType.Intestine; mapWidth = mapHeight = 64; chunkSize = 16; enableHeight = false;
            useRandomSeed = false; base.Awake();
        }
        protected override void Start() { }
        protected override void Update() { }
        protected override void GenerateObjectsForChunk(Chunk chunk) { }
        protected override TileSample SampleBaseTile(int x, int y) => new TileSample(default, null, true);
        protected override TileBase GetTileAsset(BiomeTileType type) => null;
        public void ChangeRegion(BiomeType type) => biomeType = type;
    }

    // Run against an isolated project: real inventory, damage ledger, enemy pool, and Play Mode clock.
    public static class ItemExpansionChecks
    {
        private const BindingFlags Members = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        private static bool passed, started, oldOptionsEnabled;
        private static EnterPlayModeOptions oldOptions;
        private static double deadline;
        private static int assertions;
        private static IEnumerator scenario;
        private static PlayerItemManager inventory;
        private static PlayerItemCombatEffects effects;
        private static PlayerController player;
        private static ExpansionCheckBiome biome;
        private static readonly List<GameObject> enemies = new List<GameObject>();
        private static object Executor => typeof(PlayerItemCombatEffects).GetProperty("Expansion", Members).GetValue(effects);
        private static CharacterStats Stats => player.Stats.RuntimeStats;
        private static HealthEffectSource TestSource => player.GetHealthEffectSource("expansion-check");
        public static void Run()
        {
            if (!Application.isBatchMode || EditorApplication.isPlayingOrWillChangePlaymode) throw new InvalidOperationException("Use an isolated batch project.");
            passed = started = false; assertions = 0; scenario = null; enemies.Clear();
            oldOptionsEnabled = EditorSettings.enterPlayModeOptionsEnabled; oldOptions = EditorSettings.enterPlayModeOptions;
            EditorSettings.enterPlayModeOptionsEnabled = true; EditorSettings.enterPlayModeOptions = EnterPlayModeOptions.DisableDomainReload;
            SaveService.UseStorageRootForTests(Path.GetFullPath("tmp/expansion-check-" + Guid.NewGuid().ToString("N")));
            GameplayFocusOwner.TestFocusOverride = true;
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            deadline = EditorApplication.timeSinceStartup + 180;
            EditorApplication.playModeStateChanged += OnState; EditorApplication.update += Tick; EditorApplication.isPlaying = true;
        }
        private static void Tick()
        {
            if (EditorApplication.timeSinceStartup >= deadline) { Debug.LogError("ItemExpansionChecks timed out."); Finish(); return; }
            if (!EditorApplication.isPlaying || EditorApplication.isCompiling || Time.frameCount <= 2 || Time.deltaTime <= 0) return;
            try
            {
                if (!started) { started = true; Setup(); scenario = Checks(); }
                if (scenario != null && !scenario.MoveNext())
                { scenario = null; Debug.Log("ITEM_EXPANSION_PASS assertions=" + assertions); passed = true; EditorApplication.isPlaying = false; }
            }
            catch (Exception error) { Debug.LogException(error); scenario = null; EditorApplication.isPlaying = false; }
        }
        private static void Setup()
        {
            SessionRuntimeBindings.Register();
            Require(SaveService.TryBeginNewGame(GameDifficulty.Normal, out var error), "isolated run: " + error);
            InputManager.Instance.Focus.SetNativeFocused(true); InputManager.ResetSessionClock();
            var root = new GameObject("ExpansionCheckPlayer"); PlayerCompositionRoot.EnsureGameplay(root);
            player = root.GetComponent<PlayerController>(); player.enabled = false; root.GetComponent<Rigidbody>().isKinematic = true;
            root.GetComponent<PlayerAttack>().enabled = false; root.GetComponent<PlayerClassSkillController>().enabled = false;
            inventory = root.GetComponent<PlayerItemManager>(); inventory.PopulateBasicProjectileTemplateItems();
            effects = root.GetComponent<PlayerItemCombatEffects>();
            Stats.SetBaseStat(CharacterStatType.AttackPower, 20); Stats.SetBaseStat(CharacterStatType.MaxHealth, 100);
            Stats.SetBaseStat(CharacterStatType.MoveSpeed, 5); Stats.SetCurrentHealth(100);
            biome = new GameObject("ExpansionCheckRegion").AddComponent<ExpansionCheckBiome>();
            var approved = new Dictionary<string,float>
            {
                {"explosiveBloodCellRangedDamageMultiplier",.7f},{"bioResonanceStackDamageBonus",.1f},{"voidCellDamageMultiplier",.7f},
                {"bloodContractIncomingDamageMultiplier",1.25f},{"heartSniperDamageBonusRatio",.25f},{"berserkCellAttackBonus",.5f},
                {"berserkCellAttackSpeedBonus",.25f},{"unstableCellSlowDamageMultiplier",1.3f},{"forbiddenGrowthMaxHealthPenalty",3},
                {"forbiddenGrowthFlatAttackBonus",.75f},{"hyperplasiaMissingHealthAttackBonusMax",.75f},{"decayOrganSecondsPerAttackBonus",180},
                {"decayOrganMaxAttackBonus",3},{"ruptureMuscleAttackBonusPerStack",.2f},{"severanceReflexDuration",3},
                {"severanceReflexFlatAttackBonus",.75f},{"bioBarrierIdleSecondsPerStep",1.5f},{"splitRegenerationReviveHealth",4},
                {"macrophageAttackBonusPerStack",.2f},{"focusedNerveHighAttackBonus",.5f},{"focusedNerveLowAttackBonus",.25f},
                {"executionInstinctHealthThreshold",.2f},{"executionInstinctChance",.2f},{"executionInstinctBossDamageMultiplier",1.5f},
                {"grotesqueGrowthLargeAttackBonus",.5f},{"grotesqueGrowthLargeMovePenalty",.5f},{"mutationRampageDuration",7},
                {"frenzyHormoneDuration",3},{"mutantEyeAccuracyPenaltyAngle",40},{"mutantEyeFlatDamageBonus",.75f}
            };
            string authored = File.ReadAllText("Assets/_Project/Scenes/Hub.unity");
            foreach(var entry in approved)
            {
                Near(Convert.ToSingle(effects.GetType().GetField(entry.Key,Members).GetValue(effects)),entry.Value,entry.Key+" document default");
                var match=System.Text.RegularExpressions.Regex.Match(authored,@"(?m)^  "+entry.Key+@": ([-\d.]+)\r?$");
                if(match.Success) Near(float.Parse(match.Groups[1].Value,System.Globalization.CultureInfo.InvariantCulture),entry.Value,entry.Key+" Hub authored balance");
            }
            Require(CampaignRewardRules.ShouldDropItem(MonsterTier.Normal,.005f,ItemDropScenario.OriginalTable)
                && !CampaignRewardRules.ShouldDropItem(MonsterTier.Normal,.005f,ItemDropScenario.ReviewMemo),"both documented drop scenarios available");
            Require(ItemExpansionCatalog.All.Count == 50 && ItemDefinitions.All.Count == 162, "50 new items, 162 total");
            Require(ItemDefinitions.All.Select(item => item.ItemId).Distinct(StringComparer.OrdinalIgnoreCase).Count() == 162, "catalog IDs unique");
            foreach (var item in ItemExpansionCatalog.All)
            {
                Require(inventory.TryGetItemEntry(item.ItemId, out var entry) && entry.Description == item.LegacyDescription && entry.Icon != null, item.ItemId + " catalog and description");
                Pick(item.ItemId); Require(!inventory.TryAcquireItem(item.ItemId, out _), item.ItemId + " duplicate rejected");
            }
            var save = inventory.CaptureSavedItems();
            Require(save.All(item => item.hasExpansionState), "every added item captures state");
            inventory.RestoreSavedItems(save);
            Require(ItemExpansionCatalog.All.All(item => inventory.ContainsItem(item.ItemId)), "all 50 IDs restored");
        }
        private static IEnumerator Checks()
        {
            Reset("swift_cell");
            Require(PlayerStatItemCatalog.TryGet("swift_cell", out var swift) && Mathf.Approximately(swift.Amount, .15f), "user exception: swift remains +15 percent");
            Reset("ciliated_sole"); Near(Stats.MoveSpeed, 5, "sole has no permanent speed bonus");
            effects.NotifyItemDashEnded(player.transform.position); Step(); Near(Stats.MoveSpeed, 5.7f, "sole after ordinary dash");
            RestoreState("ciliated_sole", window: 0); Step(); Near(Stats.MoveSpeed, 5, "sole expires");
            Reset("friction_mucus"); var enemy = Enemy(player.transform.position); effects.NotifyItemDashStarted(player.transform.position, .15f); Step();
            Require(Status(enemy).IsSlowed, "friction slow at dash start");
            var far = Enemy(player.transform.position + Vector3.forward * 3); effects.NotifyItemDashEnded(far.transform.position); Step(); Require(!Status(far).IsSlowed, "friction is not a dash-path attack");
            Reset("afterimage_fiber"); enemy = Enemy(player.transform.position + Vector3.forward);
            effects.NotifyItemDashEnded(player.transform.position); BasicHit(enemy, false, 1);
            Near(enemy.Stats.CurrentHealth, 999, "afterimage is delayed"); float until = Time.time + .25f; while (Time.time < until) yield return null;
            Near(enemy.Stats.CurrentHealth, 992, "afterimage adds 35 percent attack");
            Reset("elastic_joint"); Set(player,"isMoving",true); Set(player,"lastMoveDirection",Vector3.forward);
            until = Time.time + .55f; while (Time.time < until) yield return null;
            Set(player,"lastMoveDirection",Vector3.back); Step(); Near(Stats.MoveSpeed, 5.55f, "sharp walking turn speed");
            Near(effects.GetItemDashCooldown(.8f), .8f, "elastic joint does not shorten dash");
            Reset("pressure_pouch"); enemy = Enemy(player.transform.position + Vector3.forward * .7f); Vector3 beforePosition = enemy.GetComponent<Rigidbody>().position;
            effects.NotifyItemDashEnded(player.transform.position); Require((enemy.GetComponent<Rigidbody>().position - beforePosition).magnitude > .1f, "pressure pushes nearby normal enemy"); Near(enemy.Stats.CurrentHealth, 1000, "pressure deals no damage");
            Reset("landing_pad"); effects.NotifyItemTraversalEnded(); Near(effects.ProcessItemCombatDamage(10,new EnemyDamageRequest(10,null)),8,"landing reduces one combat hit");
            Near(effects.ProcessItemCombatDamage(10,new EnemyDamageRequest(10,null)),10,"landing reduction consumed once");
            Reset("corner_nerve"); Set(player,"isMoving",true); biome.AddRuntimeBlockedCells(new[]{new Vector2Int(11,10)}); Move(player.transform,new Vector3(10.5f,0,10.5f)); Step(); Near(Stats.MoveSpeed,5.35f,"wall walking bonus");
            Set(player,"isDashing",true); Step(); Near(Stats.MoveSpeed,5,"wall bonus excluded during dash"); Set(player,"isDashing",false); biome.RemoveRuntimeBlockedCells(new[]{new Vector2Int(11,10)});
            Reset("twin_step"); effects.NotifyItemDashEnded(player.transform.position); Set(player,"lastDashTime",Time.time); float dashAt=Get<float>(player,"lastDashTime");
            Set(player,"isMoving",true); Move(player.transform,player.transform.position+Vector3.right*.5f); Step(); Move(player.transform,player.transform.position+Vector3.right*.5f); Step(); Move(player.transform,player.transform.position+Vector3.right*.5f); Step();
            Near(Get<float>(player,"lastDashTime"),dashAt-.25f,"walking after dash refunds fixed cooldown once");
            Reset("steady_step"); Set(player,"isMoving",true); enemy=Enemy(player.transform.position+Vector3.forward); Near(effects.GetItemKnockbackMultiplier(enemy),.75f,"walking reduces normal knockback");
            enemy.SetEncounterRole(EnemyEncounterRole.Boss); Near(effects.GetItemKnockbackMultiplier(enemy),1,"boss displacement unchanged");
            Reset("escape_vein"); effects.NotifySkillItemCombatDamage(1); Step(); Near(Stats.MoveSpeed,5.85f,"escape actual HP hit bonus");

            Reset("infectious_mucus"); enemy=Enemy(player.transform.position+Vector3.forward); var neighbor=Enemy(player.transform.position+Vector3.forward*2);
            Status(enemy).ApplyPoison(4,1,2,TestSource); BasicHit(enemy,false,1); Require(!Status(neighbor).IsPoisoned,"infection does not transfer on a hit"); Kill(enemy); Require(Status(neighbor).IsPoisoned && !Status(neighbor).PoisonCanTransfer,"death transfers poison once without retransfer");
            Reset("frozen_fissure"); enemy=Enemy(player.transform.position+Vector3.forward); Status(enemy).ApplyMoveSpeedSlow(.3f,3); SkillHit(enemy,10); Near(enemy.Stats.CurrentHealth,979,"skill consumes slow for 55 percent attack bonus");
            SkillHit(enemy,10); Near(enemy.Stats.CurrentHealth,969,"fissure per-target cooldown");
            Reset("bloodtrail_receptor"); enemy=Enemy(player.transform.position+Vector3.forward*3); Status(enemy).ApplyBleed(4,1,1,TestSource); Set(player,"isMoving",true); Set(player,"lastMoveDirection",Vector3.forward); Step(); Near(Stats.MoveSpeed,5.55f,"walking toward bleeding target");
            Set(player,"lastMoveDirection",Vector3.back); Step(); Near(Stats.MoveSpeed,5,"bloodtrail direction cone");
            Reset("clot_disruptor"); enemy=Enemy(player.transform.position+Vector3.forward); Set(enemy,"facingDirection",0); Status(enemy).ApplyBleed(4,1,2,TestSource); BasicHit(enemy,false,1); Near(enemy.Stats.CurrentHealth,997,"rear basic hit immediately consumes one bleed tick");
            Reset("compound_antigen"); enemy=Enemy(player.transform.position+Vector3.forward); Status(enemy).ApplyPoison(5,1,1,TestSource); Status(enemy).ApplyBleed(5,1,1,TestSource);
            BasicHit(enemy,false,10); Near(enemy.Stats.CurrentHealth,990,"compound excludes basic attacks"); SkillHit(enemy,10); Near(enemy.Stats.CurrentHealth,978,"compound skill bonus includes per-source fraction");
            Reset("acid_seal"); enemy=Enemy(player.transform.position+Vector3.forward); Status(enemy).ApplyPoison(5,1,1,TestSource); BasicHit(enemy,true,1); Require(UnityEngine.Object.FindObjectsByType<AcidPuddle>(FindObjectsSortMode.None).Length==0,"acid seal excludes W");
            BasicHit(enemy,false,1); var acid=UnityEngine.Object.FindFirstObjectByType<AcidPuddle>(); Require(acid!=null,"acid seal Q creates area"); Near(Get<float>(acid,"tickDamage"),.4f,"acid seal fixed tick damage"); Near(Get<float>(acid,"radius"),.9f,"acid seal radius");
            Reset("nerve_wick","toxic_mucosa"); enemy=Enemy(player.transform.position+Vector3.forward); Status(enemy).ApplyBleed(5,1,1,TestSource); BasicHit(enemy,false,1); Near(enemy.Stats.CurrentHealth,994,"first direct poison on bleeding enemy wick bonus");
            BasicHit(enemy,false,1); Near(enemy.Stats.CurrentHealth,993,"poison refresh cannot retrigger wick");
            Reset("slow_coagulum"); enemy=Enemy(player.transform.position+Vector3.forward); Status(enemy).ApplyBleed(3,1,1,TestSource); Status(enemy).ApplyMoveSpeedSlow(.3f,5); float bleedEnd=Get<float>(Status(enemy),"bleedEndTime"); BasicHit(enemy,false,1); Near(Get<float>(Status(enemy),"bleedEndTime"),bleedEnd+.6f,"Q extends existing bleed");
            BasicHit(enemy,false,1); Near(Get<float>(Status(enemy),"bleedEndTime"),bleedEnd+.6f,"same bleed cannot extend twice");
            Reset("serum_leech"); Stats.SetCurrentHealth(50); KillMany(5,poisoned:true); Near(Stats.CurrentHealth,50,"five kills not enough"); KillMany(1,poisoned:true); Near(Stats.CurrentHealth,51,"six distinct status kills heal"); KillMany(6,poisoned:true); Near(Stats.CurrentHealth,51,"serum 12 second accumulation lock");
            Reset("cold_bloom"); enemy=Enemy(player.transform.position+Vector3.forward); neighbor=Enemy(player.transform.position+Vector3.forward*2); Status(enemy).ApplyMoveSpeedSlow(.3f,5); Kill(enemy); Require(Status(neighbor).IsSlowed,"cold death spreads slow"); Near(neighbor.Stats.CurrentHealth,1000,"cold bloom deals no damage");

            Reset("rupture_platelets","clot_membrane"); enemy=Enemy(player.transform.position+Vector3.forward*.7f); beforePosition=enemy.GetComponent<Rigidbody>().position; effects.ProcessIncomingDamage(1); Require((enemy.GetComponent<Rigidbody>().position-beforePosition).magnitude>.1f,"shield break pushes"); Near(enemy.Stats.CurrentHealth,1000,"shield break no explosion damage");
            Reset("surplus_serum"); player.Stats.Heal(2,TestSource); Near(effects.ProcessItemCombatDamage(2,new EnemyDamageRequest(2,null)),2,"less than three overheal gives no shield"); player.Stats.Heal(1,TestSource); Near(effects.ProcessItemCombatDamage(2,new EnemyDamageRequest(2,null)),1,"three overheal grants one shield");
            Reset("buffer_fat"); var coordinator=player.GetComponent<PlayerDamageCoordinator>(); coordinator.TryApplyIncoming(new EnemyDamageRequest(4,null)); Near(Stats.CurrentHealth,97,"buffer defers exactly one HP");
            until=Time.time+1.1f; while(Time.time<until)yield return null; Near(Stats.CurrentHealth,96,"deferred HP still applied later");
            Reset("scar_tissue"); effects.NotifySkillItemCombatDamage(1); enemy=Enemy(player.transform.position+Vector3.forward); Kill(enemy); Near(effects.ProcessItemCombatDamage(10,new EnemyDamageRequest(10,null)),8.5f,"hit then kill arms scar"); Near(effects.ProcessItemCombatDamage(10,new EnemyDamageRequest(10,null)),10,"scar next hit only");
            Reset("leukocyte_barrier"); effects.NotifyItemProjectileNearMiss(); Require(effects.TryBlockItemProjectile(),"near miss arms one projectile block"); Require(!effects.TryBlockItemProjectile(),"projectile block one use");
            Reset("shock_absorber"); var terrainSource=player.GetHealthEffectSource("terrain/check"); Near(effects.ProcessItemTerrainDamage(3,terrainSource),2,"terrain damage reduced by fixed HP"); Near(effects.ProcessItemTerrainDamage(3,terrainSource),3,"shock cooldown");
            Reset("pulse_stitch"); Require(new EnemyDamageRequest(1,null).IsCombatDamage && Get<PlayerItemCombatEffects>(coordinator,"effects")==effects,"combat request bound to item effects"); Stats.SetCurrentHealth(36); coordinator.TryApplyIncoming(new EnemyDamageRequest(1,null)); Near(Stats.CurrentHealth,35,"pulse crossing threshold"); Require(inventory.CaptureSavedItems()[0].expansionAuxRemaining > 2.9f,"pulse heal scheduled: " + JsonUtility.ToJson(inventory.CaptureSavedItems()[0]) + " max=" + Stats.MaxHealth); until=Time.time+3.1f; while(Time.time<until)yield return null; Near(Stats.CurrentHealth,36,"pulse delayed threshold heal");
            Reset("fibrin_lock"); coordinator.TryApplyIncoming(new EnemyDamageRequest(2,null)); Near(effects.ProcessItemCombatDamage(10,new EnemyDamageRequest(10,null)),8.8f,"large actual hit arms follow-up reduction"); Require(!effects.TryExpansionLethalGuard(),"fibrin is not a lethal guard");
            Reset("serous_rind"); Set(Executor,"lastCombatDamage",Time.time-8.1f); enemy=Enemy(player.transform.position+Vector3.forward); Near(effects.ProcessItemCombatDamage(2,enemy.CreateContactDamage(2)),1,"serous no-hit preparation reduces normal contact"); Near(effects.ProcessItemCombatDamage(2,enemy.CreateContactDamage(2)),2,"serous consumed");
            Reset("recovery_capsule"); enemy=Enemy(player.transform.position+Vector3.forward,boss:true); Stats.SetCurrentHealth(50); for(int i=0;i<12;i++)BasicHit(enemy,true,1); Near(Stats.CurrentHealth,51,"boss direct hit recovery");
            for(int i=0;i<24;i++)BasicHit(enemy,true,1); Near(Stats.CurrentHealth,52,"boss recovery max two per encounter");

            Reset("target_lymphocyte"); enemy=Enemy(player.transform.position+Vector3.forward*3); BasicHit(enemy,true,1); Require(effects.GetExpansionPreferredTarget(player.transform.position,8)==enemy,"last direct target prioritized"); Near(effects.ModifyExpansionCompanionDamage(enemy,10),10,"mark has no damage multiplier");
            Reset("predator_larva"); enemy=Enemy(player.transform.position+Vector3.forward*3); Step(); var larva=CompanionObjects("predator_larva").Single(); var projectile=EnemyProjectile.Acquire(larva.transform.position,null,Vector3.one); projectile.Launch(Vector3.forward,1,0,20); Step(); Require(!projectile.IsLaunched,"predator eats one bullet");
            until=Time.time+.6f; while(Time.time<until)yield return null; Near(enemy.Stats.CurrentHealth,990,"predator rush after eating bullet");
            Reset("bilobed_parasite"); enemy=Enemy(player.transform.position); Step(); Require(CompanionObjects("bilobed_parasite").Length==2,"paired orbiters"); Near(enemy.Stats.CurrentHealth,996,"pair line deals one 20 percent hit"); Step(); Near(enemy.Stats.CurrentHealth,996,"pair per-target interval");
            Reset("marrow_nest"); enemy=Enemy(player.transform.position+Vector3.forward*2); var cast=Cast(); cast.Dispose(); Step(); Near(enemy.Stats.CurrentHealth,995,"E creates nest attacking within 3m"); var nest=CompanionObjects("marrow_nest").Single(); beforePosition=nest.transform.position; Move(player.transform,player.transform.position+Vector3.right); Require(nest.transform.position==beforePosition,"nest remains at E origin");
            Reset("retrieval_tentacle"); for(int i=0;i<3;i++)WorldExperiencePickup.Spawn(player.transform.position+Vector3.forward*(2+i*.1f),1,true,1); Step();
            var xp=UnityEngine.Object.FindObjectsByType<WorldExperiencePickup>(FindObjectsSortMode.None); Require(xp.Count(value=>Get<bool>(value,"pulling"))==2,"retrieval pulls at most two experience pickups");
            foreach(var value in xp)UnityEngine.Object.DestroyImmediate(value.gameObject);
            Reset("guardian_spore"); Step(); enemy=Enemy(player.transform.position+Vector3.back*2); effects.NotifyCombatInteraction(); Step(); Near(enemy.Stats.CurrentHealth,992,"combat entry spore strikes rear enemy");
            Reset("feeder_sac"); enemy=Enemy(player.transform.position+Vector3.forward*3); for(int i=0;i<3;i++)SkillHit(enemy,1); Near(effects.ModifyExpansionCompanionDamage(enemy,10),12,"three distinct skill casts feed summons");
            Reset("patrolling_rib"); effects.BeginTrajectoryAttack(true,Vector3.forward,20,~0,10); Step(); Require(CompanionObjects("patrolling_rib").Length==0,"W does not create rib"); effects.BeginTrajectoryAttack(false,Vector3.forward,20,~0,10); Step(); var rib=CompanionObjects("patrolling_rib").Single(); enemy=Enemy(rib.transform.position); Step(); Near(enemy.Stats.CurrentHealth,995,"Q rib contact hit"); Step(); Near(enemy.Stats.CurrentHealth,995,"rib hits each life only once");
            Reset("pulse_companion"); enemy=Enemy(player.transform.position+Vector3.forward*2); for(int i=0;i<4;i++)BasicHit(enemy,true,1); Near(enemy.Stats.CurrentHealth,996,"pulse needs five W activations"); BasicHit(enemy,true,1); Near(enemy.Stats.CurrentHealth,987,"fifth W adds 40 percent attack pulse");
            Reset("relay_colony"); enemy=Enemy(player.transform.position+Vector3.forward); neighbor=Enemy(player.transform.position+Vector3.forward*2); enemy.TakeCompanionDamage(1,TestSource); Near(neighbor.Stats.CurrentHealth,1000,"nonlethal companion hit does not relay"); enemy.Stats.SetCurrentHealth(1); enemy.TakeCompanionDamage(1,TestSource); Near(neighbor.Stats.CurrentHealth,994,"companion normal kill relays 30 percent");

            Reset("scent_receptor"); var box=new GameObject("DocumentTestChest"); box.transform.position=player.transform.position+Vector3.forward*3; box.AddComponent<BoxCollider>().isTrigger=true; var pickup=box.AddComponent<WorldItemBoxPickup>(); pickup.Initialize("dense_muscle",null,null,0); Step(); Require(Get<Vector3?>(Executor,"scentTarget").HasValue,"scent indicates actual unopened chest"); UnityEngine.Object.DestroyImmediate(box);
            Reset("trophy_receptor"); enemy=Enemy(player.transform.position+Vector3.forward*4,elite:true); Set(Executor,"nextIndicatorScan",0f); Step(); Require(Get<Vector3?>(Executor,"trophyTarget").HasValue,"trophy indicates active elite"); Near(Stats.AttackPower,20,"trophy does not grant attack growth");
            CheckRewards();
            Reset("regional_buffer"); Near(effects.ProcessItemTerrainDamage(3,terrainSource),2,"regional first terrain HP reduction"); Near(effects.ProcessItemTerrainDamage(3,terrainSource),3,"regional once per visit"); inventory.RemoveItem("regional_buffer"); Pick("regional_buffer"); Near(effects.ProcessItemTerrainDamage(3,terrainSource),3,"reacquisition cannot farm visit protection");
            Reset("clot_membrane"); effects.ProcessIncomingDamage(1); Pick("aggregated_platelets"); Near(effects.ProcessIncomingDamage(1),1,"upper shield does not instantly refill");
            Reset("regeneration_fragment"); var save=inventory.CaptureSavedItems(); save[0].recoveryFactorCooldownRemaining=7; inventory.RestoreSavedItems(save); Pick("regenerative_marrow"); Near(inventory.CaptureSavedItems()[0].recoveryFactorCooldownRemaining,7,"upper regen keeps shorter remaining cooldown");
            Reset("toxic_mucosa"); enemy=Enemy(player.transform.position+Vector3.forward); Status(enemy).ApplyBleed(4,1,2,TestSource); BasicHit(enemy,false,1); Require(Status(enemy).IsPoisoned,"item poison present"); Pick("concentrated_mucosa"); Require(!Status(enemy).IsPoisoned && Status(enemy).IsBleeding,"upgrade removes lower poison but preserves other bleed");
            Reset("reflective_skin"); enemy=Enemy(player.transform.position+Vector3.forward); var reflectSource=effects.GetItemHealthEffectSource("reflective_skin","reflection");
            for(int i=0;i<2;i++){Set(player.GetComponent<Health>(),"isInvincible",false); coordinator.TryApplyIncoming(new EnemyDamageRequest(.4f,enemy));} Near(enemy.Stats.DamageRemainder(reflectSource),0,"no actual HP loss means no reflection");
            Set(player.GetComponent<Health>(),"isInvincible",false); coordinator.TryApplyIncoming(new EnemyDamageRequest(.4f,enemy)); Near(enemy.Stats.DamageRemainder(reflectSource),.75f,"reflection based on actual whole HP");
            foreach(var item in ItemExpansionCatalog.All)
            {
                Reset(item.ItemId); var state=inventory.CaptureSavedItems()[0]; state.expansionCooldownRemaining=4; state.expansionWindowRemaining=3; state.expansionProgress=1;
                inventory.RestoreSavedItems(new[]{state}); var restored=inventory.CaptureSavedItems()[0]; Require(restored.hasExpansionState && restored.expansionCooldownRemaining>3.8f && restored.expansionCooldownRemaining<=4.01f,item.ItemId+" relative timer round trip");
                inventory.RemoveItem(item.ItemId); Near(Stats.MoveSpeed,5,item.ItemId+" clears movement modifier"); Near(Stats.AttackPower,20,item.ItemId+" no stale attack modifier");
            }
        }
        private static void CheckRewards()
        {
            var full=ItemDefinitions.All.Select(item=>item.ItemId).ToArray();
            for(int seed=0;seed<100;seed++)
            {
                var offers=CampaignRewardRules.ChooseStarterOffers(full,Array.Empty<string>(),seed);
                Require(offers.Count==3 && offers.Select(ItemReplacementCatalog.CanonicalId).Distinct().Count()==3,"three distinct reward families seed "+seed);
            }
            Reset("organ_imprint"); var reward=Reward("document.region"); reward.itemChoices=new List<string>{"dense_muscle","vital_cell","swift_cell"};
            ItemExpansionRewards.ApplyToReward(reward,inventory); Require(reward.itemChoices.Any(id=>id.Contains("muc") || ItemReplacementCatalog.CanonicalId(id)=="hemorrhage_organ" || id.Contains("bleed") || id.Contains("hemorr") || id.Contains("infection") || id=="bloodtrail_receptor" || id=="clot_disruptor" || id=="nerve_wick" || id=="acid_seal" || id=="slow_coagulum"),"imprint guarantees regional candidate"); Near(Stats.AttackPower,20,"imprint is a reward policy, no attack growth");
            Reset("mutation_lens"); reward=Reward("document.reroll"); Require(ItemExpansionRewards.TryReroll(reward,inventory,reward.itemChoices[0]),"one candidate can reroll"); Require(!ItemExpansionRewards.TryReroll(reward,inventory,reward.itemChoices[0]),"reroll once per visit");
            Reset("marrow_memory"); SaveService.RememberItemStatChoice((int)CharacterStatType.Magic); var choices=new List<CharacterStatType>{CharacterStatType.AttackPower,CharacterStatType.AttackRange,CharacterStatType.AttackSpeed,CharacterStatType.MoveSpeed,CharacterStatType.MaxHealth}; ItemExpansionRewards.EnsureMemoryChoice(choices); Require(choices.Contains(CharacterStatType.Magic),"memory includes exact previous stat");
            Reset("symbiotic_receptor","toxic_mucosa"); reward=Reward("document.synergy"); ItemExpansionRewards.ApplyToReward(reward,inventory); Require(reward.itemChoices.Any(id=>id.Contains("muc")||id.Contains("infection")||id=="acid_seal"||id=="nerve_wick"),"synergy tag guarantee");
            Reset("boss_marrow_seal","dilute_mucus"); reward=Reward("region.Intestine.boss"); ItemExpansionRewards.ApplyToReward(reward,inventory); Require(reward.itemChoices.Contains("piercing_mucus")||reward.itemChoices.Contains("binding_mucus"),"boss guarantees valid owned-family upgrade");
            Reset("lymph_reservoir"); Stats.SetCurrentHealth(50); ItemExpansionRewards.ItemSelected(player); Near(Stats.CurrentHealth,51,"first chosen item visit heal"); ItemExpansionRewards.ItemSelected(player); Near(Stats.CurrentHealth,51,"repeated selection cannot farm heal");
            Reset("redundancy_filter"); reward=Reward("document.filter"); ItemExpansionRewards.ApplyToReward(reward,inventory); Require(reward.itemChoices.Any(id=>!PlayerStatItemCatalog.TryGet(id,out _)),"all-basic offer filtered once");
            for(int seed=0;seed<20;seed++)
            {
                Require(SaveService.TryBeginNewGame(GameDifficulty.Normal,out _),"combined reward isolated visit");
                UnityEngine.Random.InitState(seed);
                Reset("organ_imprint","symbiotic_receptor","boss_marrow_seal","blood_larva");
                reward=Reward("region.Intestine.boss"); ItemExpansionRewards.ApplyToReward(reward,inventory);
                Require(reward.itemChoices.Any(id=>(bool)typeof(ItemExpansionRewards).GetMethod("Regional",BindingFlags.Static|BindingFlags.NonPublic).Invoke(null,new object[]{id,BiomeType.Intestine})),"combined guarantees retain regional candidate "+seed);
                Require(reward.itemChoices.Contains("blood_drone")||reward.itemChoices.Contains("pulsing_blood_drone"),"combined guarantees retain boss and summon synergy "+seed);
                Require(CampaignRewardRules.HasUsableChoice(reward.itemChoices,inventory.AcquiredItems.Select(item=>item.ItemId)),"combined reward retains usable candidate "+seed);
                Require(reward.itemChoices.Select(ItemReplacementCatalog.CanonicalId).Distinct().Count()==3,"combined reward families remain distinct "+seed);
                Reset("mutation_lens"); reward=Reward("document.reroll-ready"); reward.itemChoices=new List<string>{"dense_muscle","acid_seal","nerve_wick"};
                Require(ItemExpansionRewards.TryReroll(reward,inventory,"dense_muscle") && CampaignRewardRules.HasUsableChoice(reward.itemChoices,Array.Empty<string>()),"reroll retains usable candidate "+seed);
            }
        }
        private static WorldRewardSaveData Reward(string id)=>new WorldRewardSaveData{id=id,biome=biome.BiomeType,itemChoices=new List<string>{"dense_muscle","vital_cell","swift_cell"}};
        private static TrajectoryAttackContext BasicHit(EnemyController enemy,bool ranged,float damage)
        {
            var context=effects.BeginTrajectoryAttack(ranged,Vector3.forward,damage,~0,10); effects.PrepareTrajectoryDirectHit(context,enemy);
            uint generation=enemy.SpawnGeneration; var result=enemy.TryTakeDamage(damage,TestSource);
            if(result.HitAccepted){effects.ApplyCommonOnHitEffects(enemy,damage,enemy.transform.position,generation); effects.NotifyTrajectoryDirectHit(context,enemy,generation,damage,enemy.transform.position);} return context;
        }
        private static SkillCastContext Cast()=> (SkillCastContext)Invoke(player.GetComponent<PlayerClassSkillController>(),"BeginSkillItemCast",PlayerClassSkillController.SkillSlot.Skill1);
        private static void SkillHit(EnemyController enemy,float damage){using var cast=Cast(); Invoke(cast,"ApplyDirect",enemy,damage,TestSource,enemy.transform.position);}
        private static T Get<T>(object target,string name)=>(T)target.GetType().GetField(name,Members).GetValue(target);

        private static void Reset(params string[] ids)
        {
            foreach (var go in enemies) if (go != null) UnityEngine.Object.DestroyImmediate(go); enemies.Clear();
            foreach (var puddle in UnityEngine.Object.FindObjectsByType<AcidPuddle>(FindObjectsSortMode.None)) puddle.gameObject.SetActive(false);
            inventory.ClearAllItems(); Move(player.transform, new Vector3(10, 0, 10));
            Stats.BeginHealthLifetime(); Stats.SetCurrentHealth(100); Set(player.GetComponent<Health>(), "isInvincible", false);
            Set(player, "isMoving", false); Set(player,"isDashing",false); Set(player,"lastMoveDirection",Vector3.forward);
            foreach (string id in ids) Pick(id);
        }
        private static void RestoreState(string id, float cooldown = 0, float window = 0, int progress = 0)
        {
            var saved = inventory.CaptureSavedItems(); var state = saved.Find(item => item.itemId == id);
            state.expansionCooldownRemaining = cooldown; state.expansionWindowRemaining = window; state.expansionProgress = progress;
            inventory.RestoreSavedItems(saved);
        }
        private static void Step() => Invoke(Executor, "Tick");

        private static void Kill(EnemyController enemy) { enemy.Stats.SetCurrentHealth(1); enemy.TakeDamage(1, TestSource); }
        private static void KillMany(int count, bool poisoned = false)
        {
            for (int i = 0; i < count; i++) { var enemy = Enemy(player.transform.position + Vector3.forward * 3); if (poisoned) Status(enemy).ApplyPoison(5, 1, 1, TestSource); Kill(enemy); }
        }
        private static EnemyStatusEffectController Status(EnemyController enemy)
        {
            var status = enemy.GetComponent<EnemyStatusEffectController>();
            if (status == null) { status = enemy.gameObject.AddComponent<EnemyStatusEffectController>(); status.Initialize(enemy); }
            return status;
        }
        private static GameObject[] CompanionObjects(string id) => UnityEngine.Object.FindObjectsByType<SpriteRenderer>(FindObjectsSortMode.None)
            .Where(sprite => sprite.name == "ItemCompanion_" + id).Select(sprite => sprite.gameObject).ToArray();
        private static EnemyController Enemy(Vector3 position, bool elite = false, bool boss = false)
        {
            var rule = new EnemySpawnRuleConfig { name = "ExpansionCheckEnemy", maxHealth = 1000, moveSpeed = 0, isElite = elite,
                colliderSize = new Vector3(.1f, 1, .1f), enableContactDamage = false, expReward = 0 };
            var enemy = EnemyController.Acquire(null, rule.name, EnemyController.GetPoolArchetypeId(rule));
            enemy.ConfigureWithContext(null, rule, position, position, new EnemySpawnContext(null, new FlatWorld(), boss ? EnemyEncounterRole.Boss : EnemyEncounterRole.Field));
            enemy.SetAiSuppressed(true); enemy.Stats.SetBaseStat(CharacterStatType.MaxHealth, 1000); enemy.Stats.SetCurrentHealth(1000);
            Move(enemy.transform, position); enemies.Add(enemy.gameObject); return enemy;
        }
        private static void Pick(string id) => Require(inventory.TryAcquireItem(id, out var reason), "acquire " + id + ": " + reason);
        private static void Move(Transform target, Vector3 position) { target.position = position; var rb = target.GetComponent<Rigidbody>(); if (rb != null) rb.position = position; Physics.SyncTransforms(); }
        private static object Invoke(object target, string name, params object[] args) => target.GetType().GetMethod(name, Members).Invoke(target, args);
        private static void Set(object target, string name, object value) => target.GetType().GetField(name, Members).SetValue(target, value);
        private static void Near(float value, float expected, string label) => Require(Mathf.Abs(value - expected) < .005f, label + ": " + value + " != " + expected);
        private static void Require(bool value, string label) { assertions++; if (!value) throw new InvalidOperationException(label); }
        private static void OnState(PlayModeStateChange state) { if (state == PlayModeStateChange.EnteredEditMode) Finish(); }
        private static void Finish()
        {
            EditorApplication.update -= Tick; EditorApplication.playModeStateChanged -= OnState;
            EditorSettings.enterPlayModeOptionsEnabled = oldOptionsEnabled; EditorSettings.enterPlayModeOptions = oldOptions;
            GameplayFocusOwner.TestFocusOverride = null; SaveService.ResetStaticStateForTests(); EditorApplication.Exit(passed ? 0 : 1);
        }
        private sealed class FlatWorld : IEnemyWorldQueries
        {
            public bool HasTerrain => false;
            public bool IsValidCell(Vector2Int cell) => true;
            public bool IsWalkableCell(Vector2Int cell) => true;
            public Vector2Int WorldToCell(Vector3 p) => new Vector2Int(Mathf.FloorToInt(p.x), Mathf.FloorToInt(p.z));
            public Vector3 CellToWorld(Vector2Int c) => new Vector3(c.x, 0, c.y);
            public float GetGroundHeight(Vector3 p) => 0;
            public float GetGroundHeight(Vector2Int c) => 0;
            public bool CanEnemyMove(Vector3 from, Vector3 to, Vector2 half) => true;
            public bool IsPlayerInsideLockedEncounter(Vector3 p) => false;
        }
    }
}
