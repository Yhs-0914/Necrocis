using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Necrocis;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace NecrocisEditor
{
    // Run only in an isolated batch project. Uses real inventory, combat and save-state paths.
    public static class ItemReplacementChecks
    {
        private const BindingFlags Members = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        private static bool passed, started, oldOptionsEnabled;
        private static EnterPlayModeOptions oldOptions;
        private static double deadline;
        private static int assertions;
        private static PlayerItemManager inventory;
        private static PlayerItemCombatEffects effects;
        private static PlayerController player;
        private static readonly Dictionary<string, float[]> expected = new Dictionary<string, float[]>
        {
            { "piercingHitCount", new[] { 2f, 3f, 3f } },
            { "piercingSubsequentHitDamageMultiplier", new[] { .75f, .75f, .9f } },
            { "beamDamageMultiplier", new[] { .8f, .8f, .95f } },
            { "splitDamageMultiplier", new[] { .2f, .35f, .45f } },
            { "acidRadius", new[] { 1.5f, 2f, 2.5f } }, { "acidMaxCount", new[] { 1f, 2f, 2f } },
            { "reflectionBounceCount", new[] { 1f, 3f, 4f } },
            { "poisonDuration", new[] { 2f, 4f, 4f } }, { "poisonTickDamageRatio", new[] { .15f, .15f, .22f } },
            { "freezeSlowRatio", new[] { .15f, .3f, .3f } }, { "freezeDuration", new[] { 2f, 2f, 3f } },
            { "bleedDuration", new[] { 1.6f, 3.2f, 4f } },
            { "plateletMembraneInterval", new[] { 28f, 20f, 20f } }, { "plateletMembraneShieldAmount", new[] { 1f, 1f, 2f } },
            { "recoveryFactorInterval", new[] { 60f, 45f, 32f } },
            { "bloodDroneFireInterval", new[] { 1.5f, 1f, 1f } }, { "bloodDroneDamageMultiplier", new[] { .25f, .25f, .35f } },
            { "guardianOrganCooldown", new[] { 5.5f, 4f, 3.2f } },
        };
        private static readonly Dictionary<string, string[]> settingsByFamily = new Dictionary<string, string[]>
        {
            { "piercing_mucus", new[] { "piercingHitCount", "piercingSubsequentHitDamageMultiplier" } },
            { "beam_organ", new[] { "beamDamageMultiplier" } }, { "split_tissue", new[] { "splitDamageMultiplier" } },
            { "acidic_rupture", new[] { "acidRadius", "acidMaxCount" } },
            { "vascular_reflection", new[] { "reflectionBounceCount" } },
            { "toxic_mucosa", new[] { "poisonDuration", "poisonTickDamageRatio" } },
            { "freezing_nerve", new[] { "freezeSlowRatio", "freezeDuration" } },
            { "hemorrhage_organ", new[] { "bleedDuration" } },
            { "platelet_membrane", new[] { "plateletMembraneInterval", "plateletMembraneShieldAmount" } },
            { "recovery_factor", new[] { "recoveryFactorInterval" } },
            { "blood_drone", new[] { "bloodDroneFireInterval", "bloodDroneDamageMultiplier" } },
            { "guardian_organ", new[] { "guardianOrganCooldown" } },
        };
        public static void Run()
        {
            if (!Application.isBatchMode || EditorApplication.isPlayingOrWillChangePlaymode)
                throw new InvalidOperationException("Use an isolated Unity batch project.");
            passed = started = false; assertions = 0;
            oldOptionsEnabled = EditorSettings.enterPlayModeOptionsEnabled; oldOptions = EditorSettings.enterPlayModeOptions;
            EditorSettings.enterPlayModeOptionsEnabled = true;
            EditorSettings.enterPlayModeOptions = EnterPlayModeOptions.DisableDomainReload;
            SaveService.UseStorageRootForTests(Path.GetFullPath("tmp/replacement-check-" + Guid.NewGuid().ToString("N")));
            GameplayFocusOwner.TestFocusOverride = true;
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            deadline = EditorApplication.timeSinceStartup + 120;
            EditorApplication.playModeStateChanged += OnState;
            EditorApplication.update += Tick;
            EditorApplication.isPlaying = true;
        }
        private static void Tick()
        {
            if (!started && EditorApplication.isPlaying && !EditorApplication.isCompiling && Time.frameCount > 2)
            { started = true; Execute(); return; }
            if (EditorApplication.timeSinceStartup < deadline) return;
            Debug.LogError("ItemReplacementChecks timed out."); Finish();
        }
        private static void Execute()
        {
            try
            {
                SessionRuntimeBindings.Register();
                Require(SaveService.TryBeginNewGame(GameDifficulty.Normal, out var error), "isolated run: " + error);
                InputManager.Instance.Focus.SetNativeFocused(true); InputManager.ResetSessionClock();
                var root = new GameObject("ReplacementCheckPlayer");
                PlayerCompositionRoot.EnsureGameplay(root);
                player = root.GetComponent<PlayerController>(); player.enabled = false;
                inventory = root.GetComponent<PlayerItemManager>(); inventory.PopulateBasicProjectileTemplateItems();
                effects = root.GetComponent<PlayerItemCombatEffects>();
                Require(ItemReplacementCatalog.All.Count == 36 && ItemDefinitions.All.Count == 112 + ItemExpansionCatalog.All.Count, "36 replacement items in full catalog");
                var enemy = Spawn(new Vector3(0, 0, 4));
                foreach (var family in ItemReplacementCatalog.All.GroupBy(item => item.FamilyId))
                {
                    inventory.ClearAllItems(); Acquire("dense_muscle");
                    int acquired = 0, removed = 0;
                    Action<PlayerItemManager, PlayerItemManager.AcquiredPlayerItem> onAcquire = (_, item) => acquired++;
                    Action<PlayerItemManager, PlayerItemManager.AcquiredPlayerItem> onRemove = (_, item) => removed++;
                    inventory.ItemAcquired += onAcquire; inventory.ItemRemoved += onRemove;
                    foreach (var item in family.OrderBy(item => item.Tier))
                    {
                        Acquire(item.Id);
                        Require(inventory.ItemCount == 2 && inventory.ContainsItem("dense_muscle"), item.Id + " replaces in place");
                        Require(acquired == item.Tier && removed == item.Tier - 1, item.Id + " single event pair");
                        Require(effects.HasItem(family.Key), item.Id + " activates family runtime");
                        Require(inventory.TryGetItemEntry(item.Id, out var entry) && entry.Description == item.Description
                            && entry.DisplayName == item.Name && entry.Icon != null, item.Id + " selection presentation");
                        Require(!inventory.TryAcquireItem(item.Id, out _) && !inventory.CanAcquireItem(item.Id), item.Id + " cannot stack");
                        foreach (string name in settingsByFamily[family.Key])
                            Near(Setting(name), expected[name][item.Tier - 1], item.Id + " " + name);
                        CheckRuntime(item, enemy);
                        var saved = inventory.CaptureSavedItems();
                        inventory.RestoreSavedItems(saved);
                        Require(inventory.ItemCount == 2 && inventory.ContainsItem(item.Id) && effects.HasItem(family.Key),
                            item.Id + " round trip");
                        // Restore emits normal lifecycle notifications; count the next acquisition independently.
                        acquired = item.Tier; removed = item.Tier - 1;
                    }
                    foreach (var item in family.Where(item => item.Tier < 3))
                        Require(!inventory.TryAcquireItem(item.Id, out _) && !inventory.TryReplaceItem(family.Last().Id, item.Id),
                            item.Id + " downgrade blocked");
                    var ids = family.Select(item => item.Id).ToArray();
                    Require(CampaignRewardRules.ChooseStarterOffers(ids, new[] { ids[1] }, 7).SequenceEqual(new[] { ids[2] }),
                        family.Key + " starter offers only upgrade");
                    Require(CampaignRewardRules.ChooseOffers(ids, new[] { ids[2] }, null, 7).Count == 0,
                        family.Key + " max tier excluded from drops");
                    Require(CampaignRewardRules.RefreshOffers(ids, ids, new[] { ids[1] }, null, 7).SequenceEqual(new[] { ids[2] }),
                        family.Key + " stale saved offers refreshed");
                    inventory.ItemAcquired -= onAcquire; inventory.ItemRemoved -= onRemove;
                }
                CheckMixedSave();
                CheckBeams();
                CheckSplitChildren();
                CheckRewardSelection();
                inventory.ClearAllItems();
                Require(!effects.HasItem("blood_drone") && !effects.HasItem("guardian_organ") && !effects.HasItem("recovery_factor"),
                    "removal clears family ownership");
                Debug.Log("ITEM_REPLACEMENT_PASS assertions=" + assertions); passed = true;
            }
            catch (Exception error) { Debug.LogException(error); }
            EditorApplication.isPlaying = false;
        }
        private static void CheckRuntime(ItemReplacementDefinition item, EnemyController enemy)
        {
            if (item.FamilyId == "platelet_membrane")
            {
                float amount = item.Tier == 1 ? expected["plateletMembraneShieldAmount"][item.Tier - 1] : 0f;
                Near(effects.ProcessIncomingDamage(3), 3 - amount, item.Id + " actual shield absorption");
                var saved = inventory.CaptureSavedItems().Find(state => state.itemId == item.Id);
                Near(saved.plateletMembraneCooldownRemaining, expected["plateletMembraneInterval"][item.Tier - 1], item.Id + " depleted cooldown");
                inventory.RestoreSavedItems(inventory.CaptureSavedItems());
                var restored = inventory.CaptureSavedItems().Find(state => state.itemId == item.Id);
                Near(restored.plateletMembraneShield, 0, item.Id + " depleted shield preserved");
                Near(restored.plateletMembraneCooldownRemaining, saved.plateletMembraneCooldownRemaining, item.Id + " shield cooldown preserved");
            }
            else if (item.FamilyId == "recovery_factor")
            {
                var state = inventory.CaptureSavedItems().Find(state => state.itemId == item.Id);
                Near(state.recoveryFactorCooldownRemaining, expected["recoveryFactorInterval"][item.Tier - 1], item.Id + " scheduled");
                Invoke(effects, "Update");
                Near(inventory.CaptureSavedItems().Find(value => value.itemId == item.Id).recoveryFactorCooldownRemaining,
                    state.recoveryFactorCooldownRemaining + Time.deltaTime, item.Id + " noncombat timer paused");
            }
            else if (item.FamilyId == "blood_drone" || item.FamilyId == "guardian_organ")
            {
                Invoke(effects, "Update");
                var owner = (IItemCompanionOwner)effects;
                if (item.FamilyId == "blood_drone")
                {
                    Require(owner.HasBloodDroneItem && UnityEngine.Object.FindObjectsByType<PlayerBloodDrone>(FindObjectsSortMode.None).Length == 1,
                        item.Id + " one drone");
                    Near(owner.BloodDroneFireInterval, Setting("bloodDroneFireInterval"), item.Id + " companion interval");
                    Near(owner.BloodDroneDamageMultiplier, Setting("bloodDroneDamageMultiplier"), item.Id + " companion damage");
                }
                else
                {
                    Require(owner.HasGuardianOrganItem && UnityEngine.Object.FindObjectsByType<PlayerGuardianOrgan>(FindObjectsSortMode.None).Length == 1,
                        item.Id + " one guardian");
                    Near(owner.GuardianOrganCooldown, Setting("guardianOrganCooldown"), item.Id + " guardian interval");
                }
            }
            else if (item.FamilyId == "acidic_rupture")
            {
                foreach (var old in UnityEngine.Object.FindObjectsByType<AcidPuddle>(FindObjectsSortMode.None)) RuntimePool.Release(old.gameObject);
                effects.ApplyCommonOnHitEffects(enemy, 10, Vector3.zero);
                effects.ApplyCommonOnHitEffects(enemy, 10, Vector3.right * 10);
                effects.ApplyCommonOnHitEffects(enemy, 10, Vector3.right * 20);
                var puddles = UnityEngine.Object.FindObjectsByType<AcidPuddle>(FindObjectsSortMode.None);
                Require(puddles.Length == (item.Tier == 1 ? 1 : 2), item.Id + " actual area cap");
                foreach (var puddle in puddles)
                {
                    Near(Get<float>(puddle, "radius"), expected["acidRadius"][item.Tier - 1], item.Id + " actual area radius");
                    Near(Get<float>(puddle, "tickDamage"), .5f, item.Id + " fixed damage");
                    Near(Get<float>(puddle, "lifeDuration"), 4, item.Id + " duration");
                    RuntimePool.Release(puddle.gameObject);
                }
            }
            else if (item.FamilyId == "toxic_mucosa" || item.FamilyId == "hemorrhage_organ" || item.FamilyId == "freezing_nerve")
            {
                enemy.StatusEffects.ResetEffects();
                effects.ApplyCommonOnHitEffects(enemy, 10, enemy.transform.position);
                var status = enemy.StatusEffects;
                if (item.FamilyId == "freezing_nerve")
                {
                    Near(Get<float>(status, "appliedSlowRatio"), Setting("freezeSlowRatio"), item.Id + " actual slow");
                    Near(Get<float>(status, "freezeVisualEndTime") - Time.time, Setting("freezeDuration"), item.Id + " actual slow duration");
                }
                else
                {
                    string prefix = item.FamilyId == "toxic_mucosa" ? "poison" : "bleed";
                    Near(Get<float>(status, prefix + "TickDamage"), 10 * Setting(prefix + "TickDamageRatio"), item.Id + " actual dot damage");
                    Near(Get<float>(status, prefix + "EndTime") - Time.time, Setting(prefix + "Duration"), item.Id + " actual dot duration");
                }
                status.ResetEffects();
            }
            else if (item.FamilyId == "piercing_mucus" || item.FamilyId == "vascular_reflection")
            {
                var projectile = new GameObject("ReplacementCheckProjectile").AddComponent<Projectile>();
                projectile.Launch(Vector3.forward, 8, ~0, 20, effects, source: player.GetHealthEffectSource("replacement-check"));
                Near(Get<int>(projectile, item.FamilyId == "piercing_mucus" ? "maxHitCount" : "remainingBounces"),
                    Setting(item.FamilyId == "piercing_mucus" ? "piercingHitCount" : "reflectionBounceCount"), item.Id + " launched projectile");
                UnityEngine.Object.DestroyImmediate(projectile.gameObject);
            }
        }
        private static void CheckMixedSave()
        {
            inventory.RestoreSavedItems(new List<SavedItemStateData>
            {
                new SavedItemStateData { itemId = "regenerative_marrow", recoveryFactorCooldownRemaining = 7 },
                new SavedItemStateData { itemId = "recovery_factor", recoveryFactorCooldownRemaining = 40 },
                new SavedItemStateData { itemId = "regeneration_fragment", recoveryFactorCooldownRemaining = 55 },
                new SavedItemStateData { itemId = "aggregated_platelets", plateletMembraneShield = 1.5f, plateletMembraneCooldownRemaining = 11 },
                new SavedItemStateData { itemId = "clot_membrane", plateletMembraneShield = 1 },
            });
            Require(inventory.ItemCount == 2 && inventory.ContainsItem("regenerative_marrow") && inventory.ContainsItem("aggregated_platelets"),
                "mixed save keeps strongest tier independent of order");
            var saved = inventory.CaptureSavedItems();
            Near(saved.Find(state => state.itemId == "regenerative_marrow").recoveryFactorCooldownRemaining, 7, "lower tier cannot overwrite cooldown");
            Near(saved.Find(state => state.itemId == "aggregated_platelets").plateletMembraneShield, 1.5f, "higher tier shield state preserved");
        }
        private static void CheckBeams()
        {
            inventory.ClearAllItems(); Acquire("luminous_tissue");
            var attack = player.GetComponent<PlayerAttack>(); attack.enabled = false;
            Set(attack, "projectileSpawnHeight", 0f); Set(attack, "projectileSpawnExtraHeight", 0f); Set(attack, "beamHeightOffset", 0f);
            var far = Spawn(new Vector3(0, 0, 8)); var near = Spawn(new Vector3(0, 0, 3));
            Physics.SyncTransforms();
            float nearHealth = near.Stats.CurrentHealth, farHealth = far.Stats.CurrentHealth;
            Invoke(attack, "FireBeam", Vector3.forward, 8f, 12f);
            Require(near.Stats.CurrentHealth < nearHealth && far.Stats.CurrentHealth == farHealth, "tier 1 beam hits nearest only");
            Acquire("focusing_organ");
            nearHealth = near.Stats.CurrentHealth; farHealth = far.Stats.CurrentHealth;
            Invoke(attack, "FireBeam", Vector3.forward, 8f, 12f);
            Require(near.Stats.CurrentHealth < nearHealth && far.Stats.CurrentHealth < farHealth, "upgraded beam pierces");
        }
        private static void CheckSplitChildren()
        {
            var prefab = new GameObject("ReplacementCheckBulletPrefab");
            prefab.AddComponent<Projectile>(); prefab.SetActive(false);
            var poolObject = new GameObject("ReplacementCheckBulletPool"); poolObject.SetActive(false);
            var pool = poolObject.AddComponent<PlayerProjectilePool>();
            Set(pool, "objectToPool", prefab); Set(pool, "amountToPool", 8);
            poolObject.SetActive(true);
            var enemy = Spawn(new Vector3(10, 0, 5));
            foreach (var item in ItemReplacementCatalog.All.Where(item => item.FamilyId == "split_tissue"))
            {
                inventory.ClearAllItems(); Acquire(item.Id);
                var main = new GameObject("ReplacementCheckMainBullet").AddComponent<Projectile>();
                main.Launch(Vector3.forward, 10, ~0, 20, effects, source: player.GetHealthEffectSource("split-check"));
                float before = enemy.Stats.CurrentHealth;
                Invoke(main, "HandleHit", enemy.GetComponent<Collider>());
                var children = UnityEngine.Object.FindObjectsByType<Projectile>(FindObjectsSortMode.None);
                Require(children.Length == 2, item.Id + " spawns two side bullets");
                float hitDamage = before - enemy.Stats.CurrentHealth;
                foreach (var child in children)
                {
                    Require(Get<Projectile.SpawnKind>(child, "spawnKind") == Projectile.SpawnKind.SplitChild, item.Id + " child marked");
                    Near(Get<float>(child, "damage"), hitDamage * expected["splitDamageMultiplier"][item.Tier - 1],
                        item.Id + " side bullet uses actual hit damage");
                    Invoke(child, "HandleHit", enemy.GetComponent<Collider>());
                }
                Require(UnityEngine.Object.FindObjectsByType<Projectile>(FindObjectsSortMode.None).Length == 0,
                    item.Id + " children never split again");
                UnityEngine.Object.DestroyImmediate(main.gameObject);
            }
            UnityEngine.Object.DestroyImmediate(poolObject); UnityEngine.Object.DestroyImmediate(prefab);
        }
        private static void CheckRewardSelection()
        {
            inventory.ClearAllItems(); Acquire("dilute_mucus");
            var ui = player.gameObject.AddComponent<PlayerItemInventoryUI>();
            int callbacks = 0;
            Require(ui.RequestReward(new[] { "dilute_mucus", "piercing_mucus", "binding_mucus" }, _ => callbacks++),
                "chest reward UI accepts upgrade choices");
            Invoke(ui, "SelectReward", "binding_mucus");
            Require(!ui.IsOpen && callbacks == 1 && inventory.ItemCount == 1 && inventory.ContainsItem("binding_mucus"),
                "reward selection automatically replaces lower tier");
            Invoke(ui, "SelectReward", "binding_mucus");
            Require(callbacks == 1 && inventory.ItemCount == 1, "upgrade reward cannot grant twice");
        }
        private static EnemyController Spawn(Vector3 position)
        {
            var rule = new EnemySpawnRuleConfig { name = "ReplacementCheckEnemy", maxHealth = 100, enableContactDamage = false };
            var enemy = EnemyController.Acquire(null, rule.name, EnemyController.GetPoolArchetypeId(rule));
            enemy.ConfigureWithContext(null, rule, position, position, new EnemySpawnContext(null, new FlatWorld()));
            enemy.transform.position = position; enemy.GetComponent<Rigidbody>().position = position;
            return enemy;
        }
        private static void Acquire(string id) => Require(inventory.TryAcquireItem(id, out var reason), "acquire " + id + ": " + reason);
        private static float Setting(string name) => Convert.ToSingle(typeof(PlayerItemCombatEffects).GetInterface("Necrocis.IItemCombatSettings").GetProperty(name).GetValue(effects));
        private static object Invoke(object target, string name, params object[] args) => target.GetType().GetMethod(name, Members).Invoke(target, args);
        private static T Get<T>(object target, string name) => (T)target.GetType().GetField(name, Members).GetValue(target);
        private static void Set(object target, string name, object value) => target.GetType().GetField(name, Members).SetValue(target, value);
        private static void Near(float value, float expectedValue, string label) => Require(Mathf.Abs(value - expectedValue) < .002f, label + ": " + value + " != " + expectedValue);
        private static void Require(bool value, string label) { assertions++; if (!value) throw new InvalidOperationException(label); }
        private static void OnState(PlayModeStateChange state) { if (state == PlayModeStateChange.EnteredEditMode) Finish(); }
        private static void Finish()
        {
            EditorApplication.update -= Tick; EditorApplication.playModeStateChanged -= OnState;
            EditorSettings.enterPlayModeOptionsEnabled = oldOptionsEnabled; EditorSettings.enterPlayModeOptions = oldOptions;
            GameplayFocusOwner.TestFocusOverride = null; SaveService.ResetStaticStateForTests(); EditorApplication.Exit(passed ? 0 : 1);
        }
        private sealed class FlatWorld : IEnemyWorldQueries
        {
            public bool HasTerrain => false;
            public bool IsValidCell(Vector2Int cell) => true;
            public bool IsWalkableCell(Vector2Int cell) => true;
            public Vector2Int WorldToCell(Vector3 position) => new Vector2Int(Mathf.FloorToInt(position.x), Mathf.FloorToInt(position.z));
            public Vector3 CellToWorld(Vector2Int cell) => new Vector3(cell.x, 0, cell.y);
            public float GetGroundHeight(Vector3 position) => 0;
            public float GetGroundHeight(Vector2Int cell) => 0;
            public bool CanEnemyMove(Vector3 from, Vector3 to, Vector2 halfExtents) => true;
            public bool IsPlayerInsideLockedEncounter(Vector3 position) => false;
        }
    }
}
