using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Necrocis;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace NecrocisEditor
{
    public static class ItemSkillChecks
    {
        private const BindingFlags Members = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        private static bool passed, started, oldOptionsEnabled;
        private static EnterPlayModeOptions oldOptions;
        private static double deadline;
        private static int assertions;
        private static IEnumerator scenario;
        private static PlayerItemManager inventory;
        private static PlayerItemCombatEffects effects;
        private static PlayerController player;
        private static PlayerClassSkillController skills;
        private static PlayerAttack basic;
        private static readonly List<GameObject> enemies = new List<GameObject>();
        private static object Executor => typeof(PlayerItemCombatEffects).GetProperty("SkillItems", Members).GetValue(effects);
        private static HealthEffectSource TestSource => player.GetHealthEffectSource("skill-item-check");
        public static void Run()
        {
            if (!Application.isBatchMode || EditorApplication.isPlayingOrWillChangePlaymode) throw new InvalidOperationException("Use an isolated batch project.");
            passed = started = false; assertions = 0; scenario = null; enemies.Clear();
            oldOptionsEnabled = EditorSettings.enterPlayModeOptionsEnabled; oldOptions = EditorSettings.enterPlayModeOptions;
            EditorSettings.enterPlayModeOptionsEnabled = true; EditorSettings.enterPlayModeOptions = EnterPlayModeOptions.DisableDomainReload;
            SaveService.UseStorageRootForTests(Path.GetFullPath("tmp/skill-item-check-" + Guid.NewGuid().ToString("N")));
            GameplayFocusOwner.TestFocusOverride = true;
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            deadline = EditorApplication.timeSinceStartup + 150;
            EditorApplication.playModeStateChanged += OnState; EditorApplication.update += Tick; EditorApplication.isPlaying = true;
        }
        private static void Tick()
        {
            if (EditorApplication.timeSinceStartup >= deadline) { Debug.LogError("ItemSkillChecks timed out."); Finish(); return; }
            if (!EditorApplication.isPlaying || EditorApplication.isCompiling || Time.frameCount <= 2) return;
            try
            {
                if (!started) { started = true; Setup(); scenario = Checks(); }
                if (scenario != null && !scenario.MoveNext())
                { scenario = null; Debug.Log("ITEM_SKILL_PASS assertions=" + assertions); passed = true; EditorApplication.isPlaying = false; }
            }
            catch (Exception error) { Debug.LogException(error); scenario = null; EditorApplication.isPlaying = false; }
        }
        private static void Setup()
        {
            SessionRuntimeBindings.Register();
            Require(SaveService.TryBeginNewGame(GameDifficulty.Normal, out var error), "isolated run: " + error);
            InputManager.Instance.Focus.SetNativeFocused(true); InputManager.ResetSessionClock();
            var root = new GameObject("SkillItemCheckPlayer"); PlayerCompositionRoot.EnsureGameplay(root);
            player = root.GetComponent<PlayerController>(); player.enabled = false; root.GetComponent<Rigidbody>().isKinematic = true;
            Set(player, "lastMoveDirection", Vector3.forward); Set(player, "movement", Vector3.zero);
            inventory = root.GetComponent<PlayerItemManager>(); inventory.PopulateBasicProjectileTemplateItems();
            effects = root.GetComponent<PlayerItemCombatEffects>(); skills = root.GetComponent<PlayerClassSkillController>();
            basic = root.GetComponent<PlayerAttack>(); basic.enabled = false;
            player.Stats.RuntimeStats.SetBaseStat(CharacterStatType.AttackPower, 20);
            player.Stats.RuntimeStats.SetBaseStat(CharacterStatType.Magic, 0);
            player.Stats.RuntimeStats.SetBaseStat(CharacterStatType.MaxHealth, 100); player.Stats.RuntimeStats.SetCurrentHealth(100);
            Set(basic, "projectileSpawnHeight", 0f); Set(basic, "projectileSpawnExtraHeight", 0f);
            Set(basic, "meleeAttackOffset", 1f); Set(basic, "meleeAttackBoxSize", new Vector3(3, 3, 3));
            Set(basic, "meleeSlashSpriteLoadAttempted", true); Set(basic, "meleeSlashSprite", null);
            Set(skills, "projectileSpawnHeight", 0f); Set(skills, "skillVerticalOffset", 0f);
            SetConfig("warriorSkill1", "damage", 10f); SetConfig("warriorSkill1", "bleedDuration", 0f);
            SetConfig("warriorSkill2", "damage", 10f); SetConfig("warriorSkill2", "searchRange", 0f);
            SetConfig("mageSkill1", "baseDamage", 10f); SetConfig("mageSkill1", "additionalDamage", 0f);
            SetConfig("mageSkill1", "additionalDamageMin", 0f); SetConfig("mageSkill1", "additionalDamageMax", 0f);
            SetConfig("mageSkill2", "baseDamage", 10f); SetConfig("mageSkill2", "detonationDelay", .05f);
            SetConfig("archerSkill1", "projectileDamage", 10f); SetConfig("archerSkill1", "poisonDuration", 0f);
            SetConfig("archerSkill1", "projectileSpeed", .1f); SetConfig("archerSkill1", "projectileRange", 2f);
            SetConfig("archerSkill2", "aimDuration", .05f); SetConfig("archerSkill2", "projectileDamage", 10f);
            SetConfig("archerSkill2", "projectileTravelSpeed", .1f); SetConfig("archerSkill2", "projectileLifeTime", 5f);
            var prefab = new GameObject("SkillCheckBasicBulletPrefab"); prefab.AddComponent<Projectile>(); prefab.SetActive(false);
            var poolRoot = new GameObject("SkillCheckBasicBulletPool"); poolRoot.SetActive(false);
            var pool = poolRoot.AddComponent<PlayerProjectilePool>(); Set(pool, "objectToPool", prefab); Set(pool, "amountToPool", 20); poolRoot.SetActive(true);
            Require(ItemSkillCatalog.All.Count == 10 && ItemDefinitions.All.Count == 112 + ItemExpansionCatalog.All.Count, "ten skill items registered");
            foreach (var item in ItemSkillCatalog.All)
            {
                Require(inventory.TryGetItemEntry(item.ItemId, out var entry) && entry.Description == item.LegacyDescription
                    && entry.Icon != null, item.ItemId + " catalog presentation");
                Pick(item.ItemId); Require(!inventory.TryAcquireItem(item.ItemId, out _), item.ItemId + " duplicate blocked");
            }
            inventory.RestoreSavedItems(inventory.CaptureSavedItems());
            Require(ItemSkillCatalog.All.All(item => inventory.ContainsItem(item.ItemId)), "all ten ownership round trips");
        }
        private static IEnumerator Checks()
        {
            Reset("reflex_ganglion");
            var target = Enemy(Vector3.forward);
            Invoke(skills, "ExecuteWarriorSkill1Cleave");
            float before = target.Stats.CurrentHealth;
            BasicHit(target, false);
            Near(before - target.Stats.CurrentHealth, 6, "reflex adds 30 percent to first Q after E");
            before = target.Stats.CurrentHealth; BasicHit(target, true);
            Near(target.Stats.CurrentHealth, before, "reflex consumes its window once");
            Invoke(skills, "ExecuteWarriorSkill1Cleave"); before = target.Stats.CurrentHealth; BasicHit(target, false);
            Near(target.Stats.CurrentHealth, before, "reflex internal cooldown blocks rearming");
            var state = inventory.CaptureSavedItems()[0]; state.skillItemCooldownRemaining = 0; state.skillItemWindowRemaining = 0;
            inventory.RestoreSavedItems(new[] { state }); before = target.Stats.CurrentHealth; BasicHit(target, false);
            Near(target.Stats.CurrentHealth, before, "expired reflex window does not fire");

            Reset("resonant_bone");
            var a = Enemy(Vector3.forward); var b = Enemy(new Vector3(.3f, 0, 1.3f)); var c = Enemy(new Vector3(.6f, 0, 1.6f));
            Invoke(skills, "ExecuteWarriorSkill1Cleave");
            Near(a.Stats.CurrentHealth, 981, "three-target E adds attack-power 45 percent pulse");
            Near(c.Stats.CurrentHealth, 981, "pulse at last hit reaches nearby targets");
            Near(inventory.CaptureSavedItems()[0].skillItemCooldownRemaining, 5, "resonant cooldown starts once");
            Reset("resonant_bone");
            a = Enemy(Vector3.forward);
            var cast = Cast(true); Direct(cast, a, 1); Direct(cast, a, 1); Direct(cast, a, 1); cast.Dispose();
            Near(a.Stats.CurrentHealth, 997, "repeated hits on one enemy do not count as three targets");
            Reset("resonant_bone");
            skills.SetClass(PlayerClassType.Archer);
            a = Enemy(new Vector3(0, 0, 10)); b = Enemy(new Vector3(.2f, 0, 10)); c = Enemy(new Vector3(.4f, 0, 10));
            Invoke(skills, "ExecuteArcherSkill1FanShot");
            var projectiles = UnityEngine.Object.FindObjectsByType<SkillProjectile>(FindObjectsSortMode.None);
            Require(projectiles.Length == 5, "archer E creates five tracked projectiles");
            HitSkill(projectiles[0], a); HitSkill(projectiles[1], b); HitSkill(projectiles[2], c);
            Near(a.Stats.CurrentHealth, 990, "resonant waits until all projectile judgments end");
            foreach (var projectile in projectiles) projectile.gameObject.SetActive(false);
            Near(a.Stats.CurrentHealth, 981, "resonant fires after last E projectile closes");

            Reset("mana_reservoir");
            a = Enemy(Vector3.forward); b = Enemy(new Vector3(.3f, 0, 1));
            for (int i = 0; i < 6; i++)
            {
                var basicContext = effects.BeginTrajectoryAttack(true, Vector3.forward, 20, ~0, 10);
                effects.NotifyTrajectoryDirectHit(basicContext, a, a.SpawnGeneration, 20, a.transform.position);
                effects.NotifyTrajectoryDirectHit(basicContext, b, b.SpawnGeneration, 20, b.transform.position);
            }
            Require(inventory.CaptureSavedItems()[0].skillItemProgress == 6, "mana counts one per activation and caps at six");
            inventory.RestoreSavedItems(inventory.CaptureSavedItems());
            using (var r = Cast(false)) DirectDamage(r, a, 10, "R does not consume charged E");
            Require(inventory.CaptureSavedItems()[0].skillItemProgress == 6, "R retains mana charge");
            float aBefore = a.Stats.CurrentHealth, bBefore = b.Stats.CurrentHealth;
            Invoke(skills, "ExecuteWarriorSkill1Cleave");
            Near(aBefore - a.Stats.CurrentHealth, 12, "charged E gains 20 percent");
            Near(bBefore - b.Stats.CurrentHealth, 12, "charged E buffs every direct target");
            Require(inventory.CaptureSavedItems()[0].skillItemProgress == 0, "E consumes six charges once");
            aBefore = a.Stats.CurrentHealth; Invoke(skills, "ExecuteWarriorSkill1Cleave");
            Near(aBefore - a.Stats.CurrentHealth, 10, "next E returns to base damage");
            // The real Q pipeline must produce a context even without a trajectory item.
            Reset("mana_reservoir"); a = Enemy(Vector3.forward);
            Invoke(basic, "MeleeAttack");
            Require(inventory.CaptureSavedItems()[0].skillItemProgress == 1, "actual Q registers one mana hit");

            Reset("rehearsal_tissue");
            Ready(true, 20); Invoke(skills, "ExecuteWarriorSkill1Cleave");
            Near(skills.GetRemainingCooldown(PlayerClassSkillController.SkillSlot.Skill1), 18, "missed E refund capped at two seconds");
            Invoke(skills, "ExecuteWarriorSkill1Cleave");
            Near(skills.GetRemainingCooldown(PlayerClassSkillController.SkillSlot.Skill1), 18, "rehearsal internal cooldown");
            Reset("rehearsal_tissue"); Ready(true, 5); Invoke(skills, "ExecuteMageSkill1");
            Near(skills.GetRemainingCooldown(PlayerClassSkillController.SkillSlot.Skill1), 4, "short cooldown refund is twenty percent");
            Reset("rehearsal_tissue"); skills.SetClass(PlayerClassType.Archer); Ready(true, 20);
            Invoke(skills, "ExecuteArcherSkill1FanShot");
            projectiles = UnityEngine.Object.FindObjectsByType<SkillProjectile>(FindObjectsSortMode.None);
            Near(skills.GetRemainingCooldown(PlayerClassSkillController.SkillSlot.Skill1), 20, "refund waits for fan shots");
            for (int i = 0; i < projectiles.Length - 1; i++) projectiles[i].gameObject.SetActive(false);
            Near(skills.GetRemainingCooldown(PlayerClassSkillController.SkillSlot.Skill1), 20, "last projectile still pending");
            projectiles.Last().gameObject.SetActive(false);
            Near(skills.GetRemainingCooldown(PlayerClassSkillController.SkillSlot.Skill1), 18, "last missed projectile refunds once");
            Reset("rehearsal_tissue"); a = Enemy(Vector3.forward); Ready(true, 10);
            cast = Cast(true);
            var reentrant = NewSkillProjectile(cast);
            cast.Dispose();
            a.DamageAccepted += _ => reentrant.gameObject.SetActive(false);
            HitSkill(reentrant, a);
            Require(cast.IsComplete && cast.DirectHitCount == 1, "reentrant projectile release waits for hit recording");
            Near(skills.GetRemainingCooldown(PlayerClassSkillController.SkillSlot.Skill1), 10, "reentrant hit cannot be mistaken for a miss");
            Reset("rehearsal_tissue"); Ready(true, 10); cast = Cast(true);
            reentrant = NewSkillProjectile(cast); cast.Dispose();
            skills.SetClass(PlayerClassType.Mage);
            reentrant.gameObject.SetActive(false);
            Require(cast.IsCancelled, "class change cancels pending cast");
            Near(inventory.CaptureSavedItems()[0].skillItemCooldownRemaining, 0, "cancelled cast cannot start rehearsal cooldown");

            Reset("differentiation_cell");
            a = Enemy(Vector3.forward); b = Enemy(-Vector3.forward);
            cast = Cast(true); cast.Dispose();
            Near(a.Stats.CurrentHealth, 991, "warrior E extra deals forty-five percent attack power");
            Near(b.Stats.CurrentHealth, 1000, "warrior extra respects forward direction");
            Require(cast.DirectHitCount == 0, "item extra does not count as E direct hit");
            Reset("differentiation_cell"); skills.SetClass(PlayerClassType.Archer); cast = Cast(true); cast.Dispose();
            var extras = UnityEngine.Object.FindObjectsByType<Projectile>(FindObjectsSortMode.None);
            Require(extras.Length == 1 && Get<Projectile.SpawnKind>(extras[0], "spawnKind") == Projectile.SpawnKind.TrajectoryExtra,
                "archer E makes exactly one independent afterimage arrow");
            Near(Get<float>(extras[0], "damage"), 9, "afterimage arrow damage");
            Near(Get<float>(extras[0], "launchRange"), 3, "afterimage arrow range");
            Reset("differentiation_cell"); skills.SetClass(PlayerClassType.Mage);
            a = Enemy(Vector3.forward * .5f); cast = Cast(true); cast.Dispose();
            Move(player.transform, Vector3.right * 10);
            float until = Time.time + .2f; while (Time.time < until) yield return null;
            Near(a.Stats.CurrentHealth, 1000, "mage extra waits for 0.45 seconds");
            until = Time.time + .3f; while (Time.time < until) yield return null;
            Near(a.Stats.CurrentHealth, 991, "mage extra uses original cast location");

            Reset("residual_muscle");
            a = Enemy(Vector3.forward); b = Enemy(new Vector3(.3f, 0, 1));
            cast = Cast(false); cast.Dispose(); BasicHit(a, true);
            Near(a.Stats.CurrentHealth, 1000, "R followup does not fire on W");
            BasicHit(a, false);
            Near(a.Stats.CurrentHealth, 993, "R then Q triggers attack-power thirty-five percent pulse");
            Near(b.Stats.CurrentHealth, 993, "R followup area hits neighbor");
            BasicHit(a, false); Near(a.Stats.CurrentHealth, 993, "R followup consumed once");
            state = inventory.CaptureSavedItems()[0]; state.skillItemWindowRemaining = 0;
            inventory.RestoreSavedItems(new[] { state }); BasicHit(a, false);
            Near(a.Stats.CurrentHealth, 993, "expired residual window cannot replay");

            Reset("medulla_valve");
            a = Enemy(Vector3.forward, health: 5); b = Enemy(new Vector3(.3f, 0, 1), health: 5);
            Ready(false, 10); Invoke(skills, "ExecuteWarriorSkill1Cleave");
            Near(skills.GetRemainingCooldown(PlayerClassSkillController.SkillSlot.Skill2), 9.3f, "E kills reduce R cooldown once per cast");
            c = Enemy(Vector3.forward * 1.5f, health: 5); Invoke(skills, "ExecuteWarriorSkill1Cleave");
            Near(skills.GetRemainingCooldown(PlayerClassSkillController.SkillSlot.Skill2), 9.3f, "medulla internal cooldown");
            Reset("medulla_valve"); a = Enemy(Vector3.forward, elite: true, health: 5); Ready(false, 10);
            Invoke(skills, "ExecuteWarriorSkill1Cleave");
            Near(skills.GetRemainingCooldown(PlayerClassSkillController.SkillSlot.Skill2), 10, "elite kills do not trigger medulla");
            Reset("medulla_valve"); a = Enemy(Vector3.forward, health: 2); Ready(false, 10);
            using (var e = Cast(true)) Direct(e, a, 1);
            a.TakeDamage(1, TestSource.WithEffect("bleed"));
            Near(skills.GetRemainingCooldown(PlayerClassSkillController.SkillSlot.Skill2), 10, "secondary damage kills do not trigger medulla");

            Reset("paired_nerve");
            a = Enemy(Vector3.forward); b = Enemy(Vector3.forward * 2);
            using (var e = Cast(true)) Direct(e, a, 1);
            using (var r = Cast(false))
            { DirectDamage(r, a, 12, "E marked target gets boosted first R hit"); DirectDamage(r, a, 10, "same R gains bonus only once"); }
            using (var r = Cast(false)) DirectDamage(r, a, 10, "paired nerve internal cooldown");
            Reset("paired_nerve"); a = Enemy(Vector3.forward); b = Enemy(Vector3.forward * 2);
            using (var e = Cast(true)) Direct(e, a, 1);
            using (var r = Cast(false))
            { DirectDamage(r, b, 10, "different first R target not boosted"); DirectDamage(r, a, 10, "later R target cannot reuse first-hit bonus"); }
            Reset("paired_nerve"); a = Enemy(Vector3.forward);
            using (var e = Cast(true)) Direct(e, a, 1);
            a.ConfigureWithContext(null, Rule(), a.transform.position, a.transform.position, new EnemySpawnContext(null, new FlatWorld()));
            a.SetAiSuppressed(true); a.Stats.SetBaseStat(CharacterStatType.MaxHealth, 1000); a.Stats.SetCurrentHealth(1000);
            using (var r = Cast(false)) DirectDamage(r, a, 10, "recycled target does not inherit paired mark");

            Reset("retaliation_cortex", "platelet_membrane");
            a = Enemy(Vector3.forward);
            var damageCoordinator = player.GetComponent<PlayerDamageCoordinator>();
            var health = player.GetComponent<Health>(); Set(health, "isInvincible", false);
            var result = damageCoordinator.TryApplyIncoming(new EnemyDamageRequest(1, a));
            Require(result.HpApplied == 0, "shield absorbs combat hit");
            Near(State("retaliation_cortex").skillItemWindowRemaining, 0, "absorbed damage cannot arm retaliation");
            Set(health, "isInvincible", false);
            result = damageCoordinator.TryApplyIncoming(new EnemyDamageRequest(1, null, HealthEffectSource.ForOwner(health, "toxic-rain")));
            Require(result.HpApplied == 1, "terrain fixture loses actual HP");
            Near(State("retaliation_cortex").skillItemWindowRemaining, 0, "terrain HP damage cannot arm retaliation");
            Set(health, "isInvincible", false); result = damageCoordinator.TryApplyIncoming(new EnemyDamageRequest(1, a));
            Require(result.HpApplied == 1 && State("retaliation_cortex").skillItemWindowRemaining > 3.9f, "combat HP damage arms four-second window");
            inventory.RestoreSavedItems(inventory.CaptureSavedItems());
            using (var e = Cast(true)) DirectDamage(e, a, 11.8f, "retaliation adds eighteen percent to next E");
            using (var e = Cast(true)) DirectDamage(e, a, 10, "retaliation consumed on first E");
            Set(health, "isInvincible", false); damageCoordinator.TryApplyIncoming(new EnemyDamageRequest(1, a));
            Near(State("retaliation_cortex").skillItemWindowRemaining, 0, "retaliation cooldown prevents rearming");
            Reset("retaliation_cortex"); damageCoordinator.ApplyBypassDamage(1, TestSource.WithEffect("self"));
            Near(State("retaliation_cortex").skillItemWindowRemaining, 0, "self bypass damage cannot arm retaliation");

            Reset("long_synapse");
            a = Enemy(Vector3.forward * 5); b = Enemy(Vector3.forward * 2); c = Enemy(Vector3.forward * 7);
            cast = Cast(true);
            Move(a.transform, Vector3.forward); Move(b.transform, Vector3.forward * 6); Move(player.transform, Vector3.forward * 10);
            DirectDamage(cast, b, 10, "near-at-cast target cannot become eligible by moving away");
            DirectDamage(cast, a, 11.5f, "far-at-cast target stays eligible after approaching");
            DirectDamage(cast, c, 10, "long bonus limited to one qualifying hit per cast"); cast.Dispose();
            Reset("long_synapse", "differentiation_cell");
            var nearTrigger = Enemy(Vector3.forward * .5f);
            var initiallyFar = Enemy(Vector3.forward * 5);
            nearTrigger.DamageAccepted += _ => Move(initiallyFar.transform, Vector3.forward);
            cast = Cast(true);
            DirectDamage(cast, initiallyFar, 11.5f, "cast distance captured before synchronous item-extra callbacks");
            cast.Dispose();

            // Every real E/R path must share the same direct-hit tracking, including delayed casts.
            Reset("reflex_ganglion"); skills.SetClass(PlayerClassType.Mage); a = Enemy(Vector3.forward);
            Invoke(skills, "ExecuteMageSkill1");
            Require(State("reflex_ganglion").skillItemWindowRemaining > 1.9f, "mage E emits skill direct hit");
            cast = null;
            var mageR = (IEnumerator)Invoke(skills, "ExecuteMageSkill2", a);
            Require(mageR.MoveNext(), "mage R yields detonation delay");
            until = Time.time + .07f; while (Time.time < until) yield return null;
            Require(!mageR.MoveNext(), "mage R detonation completes");
            Require(State("reflex_ganglion").skillItemWindowRemaining > 1.9f, "mage R emits skill direct hit");
            Reset("reflex_ganglion"); skills.SetClass(PlayerClassType.Warrior); a = Enemy(Vector3.forward * 4.5f);
            var warriorR = (IEnumerator)Invoke(skills, "ExecuteWarriorSkill2Dash");
            Require(!warriorR.MoveNext(), "warrior R resolves zero-distance test dash");
            Require(State("reflex_ganglion").skillItemWindowRemaining > 1.9f, "warrior R emits skill direct hit");
            Reset("reflex_ganglion"); skills.SetClass(PlayerClassType.Archer); a = Enemy(Vector3.forward * 10);
            var archerR = (IEnumerator)Invoke(skills, "ExecuteArcherSkill2");
            Require(archerR.MoveNext(), "archer R yields aim delay");
            until = Time.time + .07f; while (Time.time < until) yield return null;
            Require(!archerR.MoveNext(), "archer R emits projectile");
            var spear = UnityEngine.Object.FindObjectsByType<SkillProjectile>(FindObjectsSortMode.None).Single();
            HitSkill(spear, a); Require(State("reflex_ganglion").skillItemWindowRemaining > 1.9f, "archer R emits skill direct hit");

            foreach (var item in ItemSkillCatalog.All)
            {
                Reset(item.ItemId);
                state = inventory.CaptureSavedItems()[0]; state.skillItemCooldownRemaining = .5f;
                state.skillItemWindowRemaining = .7f; state.skillItemProgress = 4;
                inventory.RestoreSavedItems(new[] { state });
                Require(inventory.ContainsItem(item.ItemId) && State(item.ItemId).hasSkillItemState, item.ItemId + " persistent state round trip");
                cast = Cast(true); inventory.RemoveItem(item.ItemId); Pick(item.ItemId);
                a = Enemy(Vector3.forward); DirectDamage(cast, a, 10, item.ItemId + " old cast cannot inherit reacquired effects"); cast.Dispose();
            }
        }
        private static void Reset(params string[] ids)
        {
            skills.SetClass(PlayerClassType.Warrior);
            foreach (var projectile in UnityEngine.Object.FindObjectsByType<SkillProjectile>(FindObjectsSortMode.None)) projectile.gameObject.SetActive(false);
            foreach (var projectile in UnityEngine.Object.FindObjectsByType<Projectile>(FindObjectsSortMode.None)) projectile.gameObject.SetActive(false);
            foreach (var go in enemies) if (go != null) UnityEngine.Object.DestroyImmediate(go); enemies.Clear();
            inventory.ClearAllItems(); Move(player.transform, Vector3.zero); Set(player, "lastMoveDirection", Vector3.forward);
            Set(player.GetComponent<Health>(), "isInvincible", false);
            foreach (string id in ids) Pick(id);
        }
        private static void Pick(string id) => Require(inventory.TryAcquireItem(id, out var reason), "acquire " + id + ": " + reason);
        private static SavedItemStateData State(string id) => inventory.CaptureSavedItems().Find(state => state.itemId == id);
        private static SkillCastContext Cast(bool e) => (SkillCastContext)Invoke(skills, "BeginSkillItemCast",
            e ? PlayerClassSkillController.SkillSlot.Skill1 : PlayerClassSkillController.SkillSlot.Skill2);
        private static void Ready(bool e, float seconds) => Set(skills, e ? "nextSkill1ReadyTime" : "nextSkill2ReadyTime", Time.time + seconds);
        private static void BasicHit(EnemyController target, bool ranged)
        {
            var context = effects.BeginTrajectoryAttack(ranged, Vector3.forward, 20, ~0, 10);
            Require(context != null, "basic activation context");
            effects.NotifyTrajectoryDirectHit(context, target, target.SpawnGeneration, 20, target.transform.position);
        }
        private static void Direct(SkillCastContext cast, EnemyController target, float damage)
            => Invoke(cast, "ApplyDirect", target, damage, TestSource, target.transform.position);
        private static void DirectDamage(SkillCastContext cast, EnemyController target, float expected, string label)
        {
            float before = target.Stats.CurrentHealth, remainder = target.Stats.DamageRemainder(TestSource);
            Direct(cast, target, 10);
            Near(before - target.Stats.CurrentHealth + target.Stats.DamageRemainder(TestSource) - remainder, expected, label);
        }
        private static void HitSkill(SkillProjectile projectile, EnemyController target)
        {
            Move(projectile.transform, target.transform.position);
            Invoke(projectile, "TryApplyHit", target.GetComponent<Collider>());
        }
        private static SkillProjectile NewSkillProjectile(SkillCastContext cast)
        {
            var go = new GameObject("SkillItemTrackedProjectile"); var projectile = go.AddComponent<SkillProjectile>();
            projectile.Launch(Vector3.forward, 10, .1f, 20, ~0, false, default, source: TestSource);
            projectile.BindSkillCast(cast); return projectile;
        }
        private static EnemySpawnRuleConfig Rule(bool elite = false) => new EnemySpawnRuleConfig { name = "SkillItemCheckEnemy",
            maxHealth = 1000, moveSpeed = 0, isElite = elite, colliderSize = new Vector3(.1f, 1, .1f), enableContactDamage = false, expReward = 0 };
        private static EnemyController Enemy(Vector3 position, bool elite = false, float health = 1000)
        {
            var rule = Rule(elite); var enemy = EnemyController.Acquire(null, rule.name, EnemyController.GetPoolArchetypeId(rule));
            enemy.ConfigureWithContext(null, rule, position, position, new EnemySpawnContext(null, new FlatWorld()));
            enemy.SetAiSuppressed(true); enemy.Stats.SetBaseStat(CharacterStatType.MaxHealth, 1000); enemy.Stats.SetCurrentHealth(health);
            Move(enemy.transform, position); enemies.Add(enemy.gameObject); return enemy;
        }
        private static void SetConfig(string name, string field, object value) => Set(Get<object>(skills, name), field, value);
        private static void Move(Transform target, Vector3 position)
        { target.position = position; var rb = target.GetComponent<Rigidbody>(); if (rb != null) rb.position = position; Physics.SyncTransforms(); }
        private static object Invoke(object target, string name, params object[] args) => target.GetType().GetMethod(name, Members).Invoke(target, args);
        private static T Get<T>(object target, string name) => (T)target.GetType().GetField(name, Members).GetValue(target);
        private static void Set(object target, string name, object value) => target.GetType().GetField(name, Members).SetValue(target, value);
        private static void Near(float value, float expected, string label) => Require(Mathf.Abs(value - expected) < .005f, label + ": " + value + " != " + expected);
        private static void Require(bool value, string label) { assertions++; if (!value) throw new InvalidOperationException(label); }
        private static void OnState(PlayModeStateChange state) { if (state == PlayModeStateChange.EnteredEditMode) Finish(); }
        private static void Finish()
        {
            EditorApplication.update -= Tick; EditorApplication.playModeStateChanged -= OnState;
            EditorSettings.enterPlayModeOptionsEnabled = oldOptionsEnabled; EditorSettings.enterPlayModeOptions = oldOptions;
            GameplayFocusOwner.TestFocusOverride = null; SaveService.ResetStaticStateForTests(); EditorApplication.Exit(passed ? 0 : 1);
        }
        private sealed class FlatWorld : IEnemyWorldQueries
        {
            public bool HasTerrain => false;
            public bool IsValidCell(Vector2Int cell) => true;
            public bool IsWalkableCell(Vector2Int cell) => true;
            public Vector2Int WorldToCell(Vector3 p) => new Vector2Int(Mathf.FloorToInt(p.x), Mathf.FloorToInt(p.z));
            public Vector3 CellToWorld(Vector2Int c) => new Vector3(c.x, 0, c.y);
            public float GetGroundHeight(Vector3 p) => 0;
            public float GetGroundHeight(Vector2Int c) => 0;
            public bool CanEnemyMove(Vector3 from, Vector3 to, Vector2 half) => true;
            public bool IsPlayerInsideLockedEncounter(Vector3 p) => false;
        }
    }
}
