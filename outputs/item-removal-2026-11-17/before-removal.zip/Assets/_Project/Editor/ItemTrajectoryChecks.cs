using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Necrocis;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace NecrocisEditor
{
    public static class ItemTrajectoryChecks
    {
        private const BindingFlags Members = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        private static bool passed, started, oldOptionsEnabled;
        private static EnterPlayModeOptions oldOptions;
        private static double deadline;
        private static int assertions;
        private static IEnumerator scenario;
        private static PlayerItemManager inventory;
        private static PlayerItemCombatEffects effects;
        private static PlayerAttack attack;
        private static PlayerController player;
        private static PlayerProjectilePool pool;
        private static readonly List<GameObject> enemies = new List<GameObject>();
        private static object Executor => typeof(PlayerItemCombatEffects).GetProperty("Trajectory", Members).GetValue(effects);
        public static void Run()
        {
            if (!Application.isBatchMode || EditorApplication.isPlayingOrWillChangePlaymode)
                throw new InvalidOperationException("Use an isolated batch project.");
            passed = started = false; assertions = 0; scenario = null; enemies.Clear();
            oldOptionsEnabled = EditorSettings.enterPlayModeOptionsEnabled; oldOptions = EditorSettings.enterPlayModeOptions;
            EditorSettings.enterPlayModeOptionsEnabled = true;
            EditorSettings.enterPlayModeOptions = EnterPlayModeOptions.DisableDomainReload;
            SaveService.UseStorageRootForTests(Path.GetFullPath("tmp/trajectory-check-" + Guid.NewGuid().ToString("N")));
            GameplayFocusOwner.TestFocusOverride = true;
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            deadline = EditorApplication.timeSinceStartup + 120;
            EditorApplication.playModeStateChanged += OnState; EditorApplication.update += Tick;
            EditorApplication.isPlaying = true;
        }
        private static void Tick()
        {
            if (EditorApplication.timeSinceStartup >= deadline) { Debug.LogError("ItemTrajectoryChecks timed out."); Finish(); return; }
            if (!EditorApplication.isPlaying || EditorApplication.isCompiling || Time.frameCount <= 2) return;
            try
            {
                if (!started) { started = true; Setup(); scenario = Checks(); }
                if (scenario != null && !scenario.MoveNext())
                {
                    scenario = null; Debug.Log("ITEM_TRAJECTORY_PASS assertions=" + assertions);
                    passed = true; EditorApplication.isPlaying = false;
                }
            }
            catch (Exception error) { Debug.LogException(error); scenario = null; EditorApplication.isPlaying = false; }
        }
        private static void Setup()
        {
            SessionRuntimeBindings.Register();
            Require(SaveService.TryBeginNewGame(GameDifficulty.Normal, out var error), "isolated run: " + error);
            InputManager.Instance.Focus.SetNativeFocused(true); InputManager.ResetSessionClock();
            var root = new GameObject("TrajectoryCheckPlayer"); PlayerCompositionRoot.EnsureGameplay(root);
            player = root.GetComponent<PlayerController>(); player.enabled = false;
            root.GetComponent<Rigidbody>().isKinematic = true;
            Set(player, "lastMoveDirection", Vector3.forward);
            Set(player, "movement", Vector3.zero);
            inventory = root.GetComponent<PlayerItemManager>(); inventory.PopulateBasicProjectileTemplateItems();
            effects = root.GetComponent<PlayerItemCombatEffects>();
            attack = root.GetComponent<PlayerAttack>(); attack.enabled = false;
            Set(attack, "projectileSpawnHeight", 0f); Set(attack, "projectileSpawnExtraHeight", 0f);
            Set(attack, "beamHeightOffset", 0f); Set(attack, "meleeSlashSpriteResourcePath", "");
            Set(attack, "meleeSlashSpriteLoadAttempted", true); Set(attack, "meleeSlashSprite", null);
            var prefab = new GameObject("TrajectoryBulletPrefab"); prefab.AddComponent<Projectile>(); prefab.SetActive(false);
            var poolRoot = new GameObject("TrajectoryBulletPool"); poolRoot.SetActive(false);
            pool = poolRoot.AddComponent<PlayerProjectilePool>(); Set(pool, "objectToPool", prefab); Set(pool, "amountToPool", 40);
            poolRoot.SetActive(true);
            Require(ItemTrajectoryCatalog.All.Count == 10 && ItemDefinitions.All.Count == 112 + ItemExpansionCatalog.All.Count, "10 additional items registered");
            foreach (var item in ItemTrajectoryCatalog.All)
            {
                Require(inventory.TryGetItemEntry(item.ItemId, out var entry) && entry.Icon != null
                    && entry.Description == item.LegacyDescription, item.ItemId + " selectable presentation");
                Pick(item.ItemId);
                Require(effects.HasTrajectoryItem(item.ItemId) && !inventory.TryAcquireItem(item.ItemId, out _), item.ItemId + " ownership and duplicate prevention");
            }
            var saved = inventory.CaptureSavedItems(); inventory.RestoreSavedItems(saved);
            Require(ItemTrajectoryCatalog.All.All(item => inventory.ContainsItem(item.ItemId)), "all 10 ownership round trips");
            Require(CampaignRewardRules.ChooseOffers(ItemTrajectoryCatalog.All.Select(item => item.ItemId),
                inventory.AcquiredItems.Select(item => item.ItemId), null, 3).Count == 0, "owned items excluded from rewards");
        }
        private static IEnumerator Checks()
        {
            Reset("spiral_fiber");
            var projectile = Bullet(Vector3.zero);
            float expires = Get<float>(projectile, "deactivateTime");
            Vector3 first = (Vector3)Invoke(projectile, "TrajectoryStep", .1125f, 1f);
            Near(first.x, .45f, "spiral positive amplitude"); Near(first.z, 1, "spiral forward speed");
            Vector3 half = first + (Vector3)Invoke(projectile, "TrajectoryStep", .1125f, 1f);
            Near(half.x, 0, "spiral half period");
            Vector3 negative = half + (Vector3)Invoke(projectile, "TrajectoryStep", .1125f, 1f);
            Near(negative.x, -.45f, "spiral negative amplitude");
            Near(Get<float>(projectile, "deactivateTime"), expires, "spiral keeps original lifetime");
            Near(Get<float>(projectile, "damage"), 10, "spiral keeps damage");
            projectile.Launch(Vector3.forward, 10, ~0, 20, effects);
            Near(Get<float>(projectile, "trajectoryAge"), 0, "pooled launch resets trajectory time");
            var child = Bullet(Vector3.zero, Projectile.SpawnKind.SplitChild);
            Near(((Vector3)Invoke(child, "TrajectoryStep", .1125f, 1f)).x, 0, "split children do not inherit spiral");

            Reset("compressed_alveolus");
            var front = Enemy(new Vector3(0, 0, 1)); var side = Enemy(new Vector3(1, 0, 0)); var far = Enemy(new Vector3(0, 0, 2));
            Begin(false);
            Near(front.Stats.CurrentHealth, 100, "wave not available immediately after acquisition");
            Set(Executor, "lastBasicAttackTime", Time.time - 2.6f); Begin(true);
            Near(front.Stats.CurrentHealth, 97, "wave adds 30 percent damage");
            Near(side.Stats.CurrentHealth, 100, "wave obeys 100 degree cone");
            Near(far.Stats.CurrentHealth, 100, "wave obeys 1.8 metre radius");
            Begin(false); Near(front.Stats.CurrentHealth, 97, "Q and W share idle charge");
            var quietSave = inventory.CaptureSavedItems(); quietSave[0].trajectoryIdleSeconds = 2.5f;
            inventory.RestoreSavedItems(quietSave); Begin(false);
            Near(front.Stats.CurrentHealth, 94, "charged idle state restored");

            Reset("suture_stinger", "piercing_mucus");
            var a = Enemy(Vector3.forward); var b = Enemy(Vector3.forward * 2);
            var context = Begin(true);
            projectile = Bullet(Vector3.zero); projectile.BindTrajectoryAttack(context);
            Hit(projectile, a); Hit(projectile, b);
            Near(a.Stats.CurrentHealth, 90, "suture initial hit unchanged");
            Near(b.Stats.CurrentHealth, 93, "piercing whole HP unchanged");
            Near(b.Stats.DamageRemainder(Get<HealthEffectSource>(projectile, "damageSource")), .5f, "piercing fractional damage preserved");
            Require(SutureCount() == 1, "one suture target across piercing hits");
            var duplicate = Bullet(Vector3.zero); duplicate.BindTrajectoryAttack(context); Hit(duplicate, b);
            Require(SutureCount() == 1, "shared multishot context cannot schedule twice");
            foreach (var bullet in UnityEngine.Object.FindObjectsByType<Projectile>(FindObjectsSortMode.None)) bullet.gameObject.SetActive(false);
            float beforeA = a.Stats.CurrentHealth, beforeB = b.Stats.CurrentHealth;
            var sutureSource = effects.GetItemHealthEffectSource("suture_stinger", "delayed-hit");
            float sutureRemainder = a.Stats.DamageRemainder(sutureSource);
            float until = Time.time + .2f;
            while (Time.time < until) yield return null;
            Near(a.Stats.CurrentHealth, beforeA, "suture waits before 0.4 seconds");
            until = Time.time + .26f;
            while (Time.time < until) yield return null;
            Near(beforeA - a.Stats.CurrentHealth + a.Stats.DamageRemainder(sutureSource) - sutureRemainder,
                2.5f, "suture applies 25 percent after delay including fractional HP");
            Near(b.Stats.CurrentHealth, beforeB, "suture does not affect second target");
            Require(SutureCount() == 0, "suture consumed once");
            var cooldown = inventory.CaptureSavedItems().Find(value => value.itemId == "suture_stinger");
            Require(cooldown.trajectoryCooldownRemaining > 0, "suture internal cooldown still running");
            inventory.RestoreSavedItems(inventory.CaptureSavedItems());
            projectile = Bullet(Vector3.zero); projectile.BindTrajectoryAttack(Begin(true)); Hit(projectile, a);
            Require(SutureCount() == 0, "restored cooldown prevents immediate repeat");
            Set(Executor, "sutureReadyAt", Time.time);
            context = Begin(true); projectile = Bullet(Vector3.zero); projectile.BindTrajectoryAttack(context); Hit(projectile, a);
            Require(SutureCount() == 1, "new attack schedules after cooldown");
            inventory.RemoveItem("suture_stinger"); Pick("suture_stinger");
            effects.NotifyTrajectoryDirectHit(context, a, a.SpawnGeneration, 10, a.transform.position);
            Require(SutureCount() == 0, "remove and reacquire cancels old attack tickets");
            // A pending hit must not damage a recycled actor's new logical life.
            projectile = Bullet(Vector3.zero); projectile.BindTrajectoryAttack(Begin(true)); Hit(projectile, b);
            float reusedHealth;
            var rule = Rule(); b.ConfigureWithContext(null, rule, b.transform.position, b.transform.position, new EnemySpawnContext(null, new FlatWorld()));
            b.SetAiSuppressed(true); reusedHealth = b.Stats.CurrentHealth;
            foreach (var bullet in UnityEngine.Object.FindObjectsByType<Projectile>(FindObjectsSortMode.None)) bullet.gameObject.SetActive(false);
            until = Time.time + .45f;
            while (Time.time < until) yield return null;
            Near(b.Stats.CurrentHealth, reusedHealth, "pending hit rejects respawned generation");

            Reset("orbit_vesicle", "double_core");
            Begin(true); Begin(false); Begin(true); Begin(true);
            var orbitSave = inventory.CaptureSavedItems();
            Require(orbitSave.Find(value => value.itemId == "orbit_vesicle").trajectoryAttackProgress == 3, "Q does not count toward four W attacks");
            inventory.RestoreSavedItems(orbitSave);
            Invoke(attack, "RangedAttack");
            var activeOrbits = (IList)Get<object>(Executor, "orbits");
            Require(activeOrbits.Count == 1, "fourth W makes one orb despite double shot");
            var orbitVisual = (GameObject)activeOrbits[0].GetType().GetField("Visual").GetValue(activeOrbits[0]);
            Vector3 offset = orbitVisual.transform.position - player.transform.position; offset.y = 0;
            Near(offset.magnitude, 1, "orb follows one metre orbit");
            foreach (var bullet in UnityEngine.Object.FindObjectsByType<Projectile>(FindObjectsSortMode.None)) bullet.gameObject.SetActive(false);
            until = Time.time + .12f; while (Time.time < until) yield return null;
            Require(activeOrbits.Count == 1, "orb waits through half of windup");
            until = Time.time + .18f; while (Time.time < until) yield return null;
            Require(activeOrbits.Count == 0, "orb leaves orbit after 0.25 seconds");
            var shots = UnityEngine.Object.FindObjectsByType<Projectile>(FindObjectsSortMode.None);
            Require(shots.Length == 1 && Get<Projectile.SpawnKind>(shots[0], "spawnKind") == Projectile.SpawnKind.TrajectoryExtra,
                "orb launches one additional projectile");
            Near(Get<float>(shots[0], "damage"), player.Stats.AttackPower * .4f, "orb projectile damage");
            Require(inventory.CaptureSavedItems().Find(value => value.itemId == "orbit_vesicle").trajectoryAttackProgress == 0,
                "orb counter consumed");
            Begin(true); Begin(true); Begin(true); Begin(true);
            inventory.RemoveItem("orbit_vesicle");
            Require(activeOrbits.Count == 0, "removing orb item releases pending visuals");

            CheckWalls();
            CheckLens();
            CheckDisplacements();
            CheckCombos();
            CheckBasicAttackContexts();
            foreach (var item in ItemTrajectoryCatalog.All)
            {
                Reset(item.ItemId);
                var state = inventory.CaptureSavedItems()[0];
                state.hasTrajectoryState = true; state.trajectoryCooldownRemaining = .5f;
                state.trajectoryWindowRemaining = .6f; state.trajectoryAttackProgress = 3; state.trajectoryIdleSeconds = 2;
                inventory.RestoreSavedItems(new[] { state });
                var roundTrip = inventory.CaptureSavedItems()[0];
                Require(roundTrip.hasTrajectoryState && inventory.ContainsItem(item.ItemId), item.ItemId + " runtime restore");
            }
            // New callbacks must not fire from a split child or a different effect's extra projectile.
            Reset("suture_stinger");
            var target = Enemy(Vector3.forward);
            foreach (var kind in new[] { Projectile.SpawnKind.SplitChild, Projectile.SpawnKind.TrajectoryExtra })
            {
                var bullet = Bullet(Vector3.zero, kind); bullet.BindTrajectoryAttack(Begin(true)); Hit(bullet, target);
                Require(SutureCount() == 0, kind + " cannot recursively trigger suture");
            }
        }
        private static void CheckWalls()
        {
            Reset();
            var wall = new GameObject("TrajectoryWall"); wall.transform.position = new Vector3(30, 1, 1);
            wall.AddComponent<BoxCollider>().size = new Vector3(5, 3, .2f); Physics.SyncTransforms();
            var bullet = Bullet(new Vector3(30, 1, 0)); ResolveWall(bullet);
            Require(!bullet.gameObject.activeSelf, "ordinary bullet stops at wall without reflections");
            Pick("spinal_hook");
            bullet = Bullet(new Vector3(30, 1, 0)); ResolveWall(bullet);
            Require(bullet.gameObject.activeSelf && Get<bool>(bullet, "isWallSliding"), "hook enters wall slide");
            Near(Get<float>(bullet, "wallSlideRemaining"), 1.4f, "hook has 1.4 metre budget");
            Near(Mathf.Abs(Get<Vector3>(bullet, "moveDirection").x), 1, "head-on hook chooses wall tangent");
            var target = Enemy(new Vector3(30, 0, 0));
            Hit(bullet, target);
            Near(target.Stats.CurrentHealth, 96, "hook gives 40 percent damage to first target");
            Require(!bullet.gameObject.activeSelf, "hook terminates on first target");
            bullet = Bullet(new Vector3(30, 1, 0)); ResolveWall(bullet);
            Vector3 start = bullet.transform.position;
            for (int i = 0; i < 300 && bullet.gameObject.activeSelf; i++) { Invoke(bullet, "Update"); Physics.SyncTransforms(); }
            Require(!bullet.gameObject.activeSelf, "wall slide ends at budget");
            Require(Vector3.Distance(start, bullet.transform.position) <= 1.402f, "hook cannot exceed 1.4 metres");
            Pick("elastic_vessel"); bullet = Bullet(new Vector3(30, 1, 0)); ResolveWall(bullet);
            Require(!Get<bool>(bullet, "wallSlideUsed") && Get<int>(bullet, "remainingBounces") == 0, "normal reflection takes priority");
            Require(Get<Vector3>(bullet, "moveDirection").z < 0, "reflection retains normal direction behavior");
            Move(bullet.transform, new Vector3(30, 1, 0)); Set(bullet, "moveDirection", Vector3.forward);
            ResolveWall(bullet);
            Require(Get<bool>(bullet, "isWallSliding"), "hook starts after reflection budget exhausted");
            bullet.Launch(Vector3.forward, 10, ~0, 20, effects);
            Require(!Get<bool>(bullet, "wallSlideUsed") && !Get<bool>(bullet, "isWallSliding"), "pooled bullet resets hook");
            var rubble = new GameObject("TrajectoryRubbleFixture");
            rubble.AddComponent<ResidueRubble>(); var rubbleCollider = rubble.AddComponent<BoxCollider>();
            Require(!(bool)Invoke(bullet, "IsValidObstacleCollider", rubbleCollider), "breakable residue retains its own hit path");
            UnityEngine.Object.DestroyImmediate(rubble);
            UnityEngine.Object.DestroyImmediate(wall);
        }
        private static void CheckLens()
        {
            Reset("distance_lens", "piercing_mucus");
            var first = Enemy(Vector3.forward * 5); var second = Enemy(Vector3.forward * 6);
            var bullet = Bullet(Vector3.zero); Move(bullet.transform, Vector3.forward * 4);
            HitDamage(bullet, first, 11.8f, "first distant hit gains 18 percent");
            Move(bullet.transform, Vector3.forward * 5);
            HitDamage(bullet, second, 7.5f, "later piercing hit gains no lens bonus");
            bullet = Bullet(Vector3.zero); Move(bullet.transform, Vector3.forward * 2); Hit(bullet, first);
            Move(bullet.transform, Vector3.forward * 5);
            HitDamage(bullet, second, 7.5f, "near first hit consumes lens opportunity");
            var extra = Bullet(Vector3.zero, Projectile.SpawnKind.TrajectoryExtra);
            Move(extra.transform, Vector3.forward * 5);
            HitDamage(extra, first, 10, "item-generated extras do not inherit lens");
        }
        private static void CheckDisplacements()
        {
            Reset("impact_marrow");
            Set(attack, "meleeAttackOffset", .4f); Set(attack, "meleeAttackBoxSize", new Vector3(2, 3, 2));
            var closest = Enemy(Vector3.forward * .4f); var farther = Enemy(Vector3.forward * .8f);
            var elite = Enemy(new Vector3(.3f, 0, .1f), elite: true);
            Invoke(attack, "MeleeAttack");
            Require(closest.Stats.CurrentHealth < 100, "actual Q hit fixture: player=" + player.transform.position
                + " facing=" + player.GetLogicalFacingDirection() + " target=" + closest.transform.position);
            Near(closest.transform.position.z, 1, "actual Q pushes closest normal by 0.6");
            Near(farther.transform.position.z, .8f, "actual Q pushes only one normal");
            Near(elite.transform.position.z, .1f, "Q displacement excludes elites");
            float pos = closest.transform.position.z; Invoke(attack, "MeleeAttack");
            Near(closest.transform.position.z, pos, "impact internal cooldown");
            Reset("impact_marrow");
            var blockedWorld = new FlatWorld { MaxZ = .65f };
            var blocked = Enemy(Vector3.forward * .4f, world: blockedWorld);
            var ctx = Begin(false); effects.PrepareTrajectoryMeleeTargets(ctx, new[] { blocked });
            effects.NotifyTrajectoryDirectHit(ctx, blocked, blocked.SpawnGeneration, 10, blocked.transform.position);
            Require(blocked.transform.position.z <= .651f, "impact stops at world boundary");

            Reset("clasping_tendon");
            Set(attack, "meleeAttackOffset", 1.5f); Set(attack, "meleeAttackBoxSize", new Vector3(3, 3, 3));
            var pulled = Enemy(Vector3.forward * 1.4f); var near = Enemy(new Vector3(.2f, 0, .9f));
            Invoke(attack, "MeleeAttack");
            Near(pulled.transform.position.z, 1, "actual Q pulls far normal by 0.4");
            Near(near.transform.position.z, .9f, "near target not pulled");
            Reset("clasping_tendon");
            pulled = Enemy(Vector3.forward * 1.2f);
            pulled.GetComponent<BoxCollider>().size = new Vector3(1, 1, 1); Physics.SyncTransforms();
            ctx = Begin(false);
            effects.NotifyTrajectoryDirectHit(ctx, pulled, pulled.SpawnGeneration, 10, pulled.transform.position);
            var body = pulled.GetComponent<Collider>().bounds; var playerBody = player.GetComponent<Collider>().bounds;
            Require(Mathf.Abs(body.center.z - playerBody.center.z) > body.extents.z + playerBody.extents.z,
                "pull stops outside player collision body");
        }
        private static void CheckCombos()
        {
            Reset("burst_valve");
            var near = Enemy(Vector3.forward); var far = Enemy(Vector3.forward * 1.8f); var side = Enemy(new Vector3(.5f, 0, 1));
            Begin(false); Begin(true);
            Near(near.Stats.CurrentHealth, 97, "Q then W jet applies whole HP damage");
            Near(near.Stats.DamageRemainder(effects.GetItemHealthEffectSource("burst_valve", "jet")), .5f,
                "jet preserves 35 percent fractional damage");
            Near(far.Stats.CurrentHealth, 100, "jet targets nearest one only");
            Near(side.Stats.CurrentHealth, 100, "jet stays narrow");
            Begin(true); Near(near.Stats.CurrentHealth, 97, "only first W uses combo");
            Begin(false); Begin(true); Near(near.Stats.CurrentHealth, 97, "jet respects two second cooldown");
            var saved = inventory.CaptureSavedItems(); saved[0].trajectoryCooldownRemaining = 0;
            saved[0].trajectoryWindowRemaining = .2f; inventory.RestoreSavedItems(saved); Begin(true);
            Near(near.Stats.CurrentHealth, 94, "jet pending window restored");
            saved = inventory.CaptureSavedItems(); saved[0].trajectoryCooldownRemaining = 0; saved[0].trajectoryWindowRemaining = 0;
            inventory.RestoreSavedItems(saved); Begin(true);
            Near(near.Stats.CurrentHealth, 94, "expired combo cannot replay");

            Reset("opening_cartilage");
            Begin(true); Near(effects.ConsumeTrajectoryMeleeRangeMultiplier(), 1.2f, "W then Q range multiplier");
            Near(effects.ConsumeTrajectoryMeleeRangeMultiplier(), 1, "range window consumed once");
            Begin(true); Near(effects.ConsumeTrajectoryMeleeRangeMultiplier(), 1, "range bonus respects cooldown");
            saved = inventory.CaptureSavedItems(); saved[0].trajectoryCooldownRemaining = 0; saved[0].trajectoryWindowRemaining = .4f;
            inventory.RestoreSavedItems(saved); Near(effects.ConsumeTrajectoryMeleeRangeMultiplier(), 1.2f, "range window restored");
            Reset();
            Set(attack, "meleeAttackOffset", 1f); Set(attack, "meleeAttackBoxSize", new Vector3(1, 3, 1));
            var edge = Enemy(Vector3.forward * 1.75f);
            Invoke(attack, "MeleeAttack"); Near(edge.Stats.CurrentHealth, 100, "edge target outside baseline Q");
            Pick("opening_cartilage"); Begin(true); Invoke(attack, "MeleeAttack");
            Require(edge.Stats.CurrentHealth < 100, "expanded Q actually reaches edge target");
        }
        private static void CheckBasicAttackContexts()
        {
            Reset("suture_stinger", "double_core", "laryngeal_nerve");
            Invoke(attack, "RangedAttack");
            var bullets = UnityEngine.Object.FindObjectsByType<Projectile>(FindObjectsSortMode.None);
            Require(bullets.Length == 3, "double core and backshot still emit three bullets");
            var shared = Get<TrajectoryAttackContext>(bullets[0], "trajectoryAttack");
            Require(shared != null && bullets.All(bullet => ReferenceEquals(Get<TrajectoryAttackContext>(bullet, "trajectoryAttack"), shared)),
                "all bullets share original attack context");
            // Delayed proliferation must keep the original context even if another attack starts.
            var delayed = (IEnumerator)Invoke(attack, "FireCellProliferationVolleyDelayedFromSource",
                Vector3.forward, 10f, 20f, player.GetHealthEffectSource("trajectory-proliferation"), shared);
            Require(delayed.MoveNext(), "proliferation yields delay");
            foreach (var bullet in bullets) bullet.gameObject.SetActive(false);
            Begin(true);
            attack.enabled = true;
            Require(!delayed.MoveNext(), "proliferation finishes without a new activation");
            attack.enabled = false;
            bullets = UnityEngine.Object.FindObjectsByType<Projectile>(FindObjectsSortMode.None);
            Require(bullets.Length == 3 && bullets.All(bullet => ReferenceEquals(Get<TrajectoryAttackContext>(bullet, "trajectoryAttack"), shared)),
                "delayed proliferation retains original attack ticket");
            Reset("suture_stinger", "luminous_tissue");
            var near = Enemy(Vector3.forward * 2); var far = Enemy(Vector3.forward * 4);
            Invoke(attack, "RangedAttack");
            var beamSource = player.GetHealthEffectSource("basic/beam");
            Near(100 - near.Stats.CurrentHealth + near.Stats.DamageRemainder(beamSource),
                player.Stats.AttackPower * effects.BeamDamageMultiplier, "single target beam damage including fractional HP");
            Require(far.Stats.CurrentHealth == 100 && far.Stats.DamageRemainder(beamSource) == 0 && SutureCount() == 1,
                "single target beam cooperates with suture exactly once");
        }
        private static TrajectoryAttackContext Begin(bool ranged) => effects.BeginTrajectoryAttack(ranged, Vector3.forward, 10, ~0, 20);
        private static void Reset(params string[] ids)
        {
            Time.timeScale = 1;
            Move(player.transform, Vector3.zero);
            Set(player, "lastMoveDirection", Vector3.forward);
            foreach (var go in enemies) if (go != null) UnityEngine.Object.DestroyImmediate(go);
            enemies.Clear();
            foreach (var bullet in UnityEngine.Object.FindObjectsByType<Projectile>(FindObjectsSortMode.None)) bullet.gameObject.SetActive(false);
            inventory.ClearAllItems();
            foreach (string id in ids) Pick(id);
        }
        private static void Pick(string id) => Require(inventory.TryAcquireItem(id, out var reason), "acquire " + id + ": " + reason);
        private static EnemySpawnRuleConfig Rule(bool elite = false) => new EnemySpawnRuleConfig { name = "TrajectoryCheckEnemy", maxHealth = 100,
            moveSpeed = 0, isElite = elite, colliderSize = new Vector3(.1f, 1, .1f), enableContactDamage = false };
        private static EnemyController Enemy(Vector3 position, bool elite = false, FlatWorld world = null)
        {
            var rule = Rule(elite);
            var enemy = EnemyController.Acquire(null, rule.name, EnemyController.GetPoolArchetypeId(rule));
            enemy.ConfigureWithContext(null, rule, position, position, new EnemySpawnContext(null, world ?? new FlatWorld()));
            enemy.SetAiSuppressed(true); Move(enemy.transform, position); enemies.Add(enemy.gameObject); return enemy;
        }
        private static Projectile Bullet(Vector3 position, Projectile.SpawnKind kind = Projectile.SpawnKind.Normal)
        {
            var go = pool.GetPooledObject(); Require(go != null, "projectile pool capacity");
            go.transform.position = position; go.SetActive(true);
            var bullet = go.GetComponent<Projectile>(); bullet.Launch(Vector3.forward, 10, ~0, 20, effects, kind,
                player.GetHealthEffectSource("trajectory-check"));
            return bullet;
        }
        private static void Hit(Projectile bullet, EnemyController enemy) => Invoke(bullet, "HandleHit", enemy.GetComponent<Collider>());
        private static void HitDamage(Projectile bullet, EnemyController enemy, float expected, string label)
        {
            var source = Get<HealthEffectSource>(bullet, "damageSource");
            float before = enemy.Stats.CurrentHealth, remainder = enemy.Stats.DamageRemainder(source);
            Hit(bullet, enemy);
            Near(before - enemy.Stats.CurrentHealth + enemy.Stats.DamageRemainder(source) - remainder, expected, label);
        }
        private static void ResolveWall(Projectile bullet)
        {
            Physics.SyncTransforms();
            object[] args = { Vector3.forward * 2 }; Invoke(bullet, "TryReflectFromObstacleCollider", args);
        }
        private static int SutureCount() => ((IList)Get<object>(Executor, "sutures")).Count;
        private static void Move(Transform target, Vector3 position)
        {
            target.position = position; var body = target.GetComponent<Rigidbody>(); if (body != null) body.position = position; Physics.SyncTransforms();
        }
        private static object Invoke(object target, string name, params object[] args) => target.GetType().GetMethod(name, Members).Invoke(target, args);
        private static T Get<T>(object target, string name) => (T)target.GetType().GetField(name, Members).GetValue(target);
        private static void Set(object target, string name, object value) => target.GetType().GetField(name, Members).SetValue(target, value);
        private static void Near(float value, float expected, string label) => Require(Mathf.Abs(value - expected) < .003f, label + ": " + value + " != " + expected);
        private static void Require(bool value, string label) { assertions++; if (!value) throw new InvalidOperationException(label); }
        private static void OnState(PlayModeStateChange state) { if (state == PlayModeStateChange.EnteredEditMode) Finish(); }
        private static void Finish()
        {
            EditorApplication.update -= Tick; EditorApplication.playModeStateChanged -= OnState;
            EditorSettings.enterPlayModeOptionsEnabled = oldOptionsEnabled; EditorSettings.enterPlayModeOptions = oldOptions;
            GameplayFocusOwner.TestFocusOverride = null; SaveService.ResetStaticStateForTests(); EditorApplication.Exit(passed ? 0 : 1);
        }
        private sealed class FlatWorld : IEnemyWorldQueries
        {
            public float MaxZ = float.PositiveInfinity;
            public bool HasTerrain => false;
            public bool IsValidCell(Vector2Int cell) => true;
            public bool IsWalkableCell(Vector2Int cell) => true;
            public Vector2Int WorldToCell(Vector3 position) => new Vector2Int(Mathf.FloorToInt(position.x), Mathf.FloorToInt(position.z));
            public Vector3 CellToWorld(Vector2Int cell) => new Vector3(cell.x, 0, cell.y);
            public float GetGroundHeight(Vector3 position) => 0;
            public float GetGroundHeight(Vector2Int cell) => 0;
            public bool CanEnemyMove(Vector3 from, Vector3 to, Vector2 halfExtents) => to.z <= MaxZ;
            public bool IsPlayerInsideLockedEncounter(Vector3 position) => false;
        }
    }
}
