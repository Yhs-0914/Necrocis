using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Necrocis
{
    public enum ItemDescriptionMode { Legacy = 0, Auto = 1, Custom = 2 }

    public sealed class ItemDefinition
    {
        public string ItemId { get; }
        public string DisplayName { get; }
        public string LegacyDescription { get; }
        public PlayerItemCategory Category { get; }
        public ItemDefinition(string id, string name, string description, PlayerItemCategory category)
        { ItemId = id; DisplayName = name; LegacyDescription = description; Category = category; }
    }

    public static class ItemDefinitions
    {
        private static readonly ReadOnlyCollection<ItemDefinition> definitions = Array.AsReadOnly(new[]
        {
            new ItemDefinition("double_core", "이중핵", "발사체 2개 발사. 각각 70% 피해.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("triple_core", "삼중핵", "발사체 3개 발사. 각각 50% 피해.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("homing_cell", "유도 세포", "적을 추적하는 유도 투사체. 문서에 범위 미기재. Unity 참고값 탐지 8m, 회전 계수 7.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("hypertrophy_cell", "비대 세포", "투사체 크기·충돌 범위 45%, 사거리 25% 증가.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("reflux_organ", "역류 장기", "왕복 경로마다 최대 3명 타격. 복귀 중 같은 적 재적중 시 60% 피해.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("piercing_mucus", "관통 점액", "최대 3명 관통. 관통할 때마다 피해 25% 감소.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("laryngeal_nerve", "후두 신경", "뒤쪽으로 75% 피해의 추가 투사체 발사.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("beam_organ", "광선 기관", "80% 피해의 관통 광선 공격. 다중핵·후방 발사·세포 증식 적용.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("split_tissue", "분열 조직", "적 명중 시 양옆으로 각각 35% 피해의 추가 투사체 생성. 추가 분열 없음.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("explosive_blood_cell", "폭발 혈구", "원거리 직접 피해 70%. 주변 적에게 같은 피해의 폭발 공격.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("acidic_rupture", "산성 파열", "적중 위치에 4초간 산성 장판 생성. 1초마다 0.5 피해, 동시 최대 2개. 반경은 문서에 미기재. Unity 참고값 2m.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("cell_proliferation", "세포 증식", "공격마다 25% 확률로 0.5초 후 70% 피해의 추가 공격.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("pulse_bullet", "맥동 탄환", "이동 중 투사체 크기와 실제 충돌 범위가 증가하거나 감소. Unity 참고값 최대 2.6배, 최소 0.2배.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("vascular_reflection", "혈관 반사", "벽에 튕기는 반사 투사체. 문서에 횟수 미기재. Unity 참고값 최대 3회.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("toxic_mucosa", "독성 점막", "적중 시 4초간 1초마다 적중 피해의 15% 중독 피해. 재적중 시 지속시간 갱신.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("freezing_nerve", "빙결 신경", "공격 적중 시 2초간 적 이동속도 30% 감소.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("hemorrhage_organ", "출혈 기관", "적중 시 3.2초간 0.8초마다 적중 피해의 15% 출혈 피해. 재적중 시 지속시간 갱신.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("overheated_organ", "과열 기관", "연속 공격마다 공격속도 +6%. 10중첩 시 주변에 150% 피해, 자신에게 체력 1 피해.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("mutant_eye", "돌연변이 안구", "발사 방향이 좌우 40도 내에서 무작위 변화. 기본 공격 피해 +0.75.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("organ_tentacle", "장기 촉수", "주변 적 최대 2명을 1.2초마다 30% 피해로 공격. 기본 공격 피해 20% 감소.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("rampage_bloodflow", "폭주 혈류", "이동 8초마다 기본 공격 피해 +0.25, 최대 +0.75. 정지 시 4초마다 감소.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("muscle_spasm", "근육 경련", "근접 공격 범위 1.7배. 공격속도 20% 감소.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("unstable_core", "불안정 핵", "5초마다 기본 공격 피해가 70~150% 사이에서 변경.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("bio_resonance", "생체 공명", "3초 내 같은 적 연속 공격 시 피해 +10%, 최대 +30%.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("blood_pressure_burst", "혈압 폭발", "잃은 체력 10%당 공격속도 +6%, 최대 +54%.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("void_cell", "공허 세포", "공격 시 20% 확률로 적 주변에서 70% 피해의 추가 탄환 생성.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("forbidden_growth", "금단 성장", "최대 체력 -3, 공격력 +0.75.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("overclock_nerve", "과속 신경", "최대 체력 -2, 이동속도 +2.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("blood_contract", "피의 계약", "적 20명 처치 시 최대 체력 +1, 최대 +4. 받는 피해 1.25배.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("hyperplasia_heart", "과증식 심장", "잃은 체력에 비례해 기본 공격 피해 증가, 최대 +0.75.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("decay_organ", "부패 장기", "전투 시간 3분마다 기본 공격 피해 +0.25, 최대 +0.75.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("rupture_muscle", "파열 근육", "공격 2회마다 기본 공격 피해 +0.2, 이동속도 -0.25. 최대 3중첩.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("imperfect_regeneration", "불완전 재생", "최대 체력 -2. 피격 2초 후 체력 +1 회복, 대기시간 15초.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("severance_reflex", "절단 반사", "피격 후 3초간 기본 공격 피해 +0.75.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("bio_gamble", "생체 도박", "레벨업 성장량이 0배·1배·2배로 결정. 확률은 각각 20%·60%·20%.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("exoskeleton", "외골격", "받는 피해 25% 감소. 이동속도 -1.5.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("platelet_membrane", "혈소판 막", "20초마다 피해 1을 막는 보호막 생성.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("recovery_factor", "회복 인자", "전투 시간 45초마다 체력 +1 회복.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("reflective_skin", "반사 피부", "피격 시 실제 받은 피해의 75% 반사.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("bio_barrier", "생체 장막", "정지 1.5초마다 받는 피해 10% 감소, 최대 30%.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("split_regeneration", "분열 재생", "한 런에 한 번, 체력이 0이 되기 직전 체력 4로 부활하고 1.5초 무적.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("infected_host", "감염 숙주", "잡몹 처치 시 15% 확률로 6초간 30% 피해의 아군 생성. 최대 2명.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("spore_colony", "포자 군집", "일정 시간마다 적에게 달려드는 작은 포자 생명체 소환. Unity 참고값 8초마다, 수명 6초, 피해 공격력 100%.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("blood_drone", "혈액 드론", "1초마다 가까운 적에게 공격력의 25% 피해.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("guardian_organ", "수호 장기", "플레이어 주변을 맴돌며 4초마다 적 투사체 하나 방어.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("tentacle_colony", "촉수 군체", "3초마다 적 2명에게 1.2초간 50% 둔화와 10% 피해.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("electric_neural_network", "전기 신경망", "적 처치 시 최대 3명에게 피해 1의 연쇄 전류. 대기시간 5초.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("infection_transference", "감염 전이", "적 처치 시 주변 3명에게 3초간 초당 0.5 감염 피해. 대기시간 5초.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("macrophage", "대식 세포", "적 처치 시 5초간 공격력 +0.2, 최대 3중첩.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("gluttonous_organ", "폭식 장기", "적 처치 시 3초 동안 이동속도 증가, 최대 4중첩. Unity 참고값 중첩당 +0.5.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("heart_sniper", "심장 저격", "체력 60% 이상인 적에게 직접 공격 피해 25% 증가.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("bloodflow_acceleration", "혈류 가속", "보스·엘리트 근처에서 공격속도 25% 증가. 문서에 거리 미기재. Unity 참고값 9m.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("focused_nerve", "집중 신경", "주변 적 1명 이하일 때 기본 공격 피해 +0.5, 2~3명일 때 +0.25. Unity 참고값 6m.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("execution_instinct", "처형 본능", "체력 20% 미만인 적을 20% 확률로 처형. 보스·엘리트는 추가 피해 50%.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("berserk_cell", "광폭 세포", "보스전 진입 시 15초간 공격력 +0.5, 이동속도 +0.5, 공격속도 +25%.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("unstable_cell", "불안정 세포", "투사체 속도 50~150%. 80% 이하의 느린 탄은 피해 130%.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("grotesque_growth", "기괴 성장", "10초마다 소형화·이동속도 +1 또는 대형화·공격력 +0.5·이동속도 -0.5.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("mutation_rampage", "돌연변이 폭주", "15초마다 7초간 무작위 능력치 강화 또는 약화. Unity 참고값 강화 확률 60%.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("parasitic_bomb", "기생 폭탄", "적 처치 시 20% 확률로 반경 4에 공격력 100% 폭발.", PlayerItemCategory.BasicProjectile),
            new ItemDefinition("frenzy_hormone", "광란 호르몬", "피격 시 공격력 +0.5·이동속도 +1·공격속도 +20% 중 하나 적용. 지속 3초, 대기시간 8초.", PlayerItemCategory.BasicProjectile),
        });
        private static readonly Dictionary<string, ItemDefinition> byId = BuildIndex();
        public static IReadOnlyList<ItemDefinition> All => new List<ItemDefinition>(byId.Values);
        public static bool TryGet(string id, out ItemDefinition definition)
        {
            definition = null;
            return id != null && byId.TryGetValue(id, out definition);
        }
        private static Dictionary<string, ItemDefinition> BuildIndex()
        {
            var result = new Dictionary<string, ItemDefinition>(StringComparer.OrdinalIgnoreCase);
            foreach (var definition in definitions) result.Add(definition.ItemId, definition);
            foreach (var definition in ItemTrajectoryCatalog.All) result.Add(definition.ItemId, definition);
            foreach (var definition in ItemSkillCatalog.All) result.Add(definition.ItemId, definition);
            foreach (var definition in ItemExpansionCatalog.All) result.Add(definition.ItemId, definition);
            foreach (var item in ItemReplacementCatalog.All)
                result[item.Id] = new ItemDefinition(item.Id, item.Name, item.Description,
                    item.FamilyId == PlayerItemIds.PlateletMembraneId || item.FamilyId == PlayerItemIds.RecoveryFactorId
                        || item.FamilyId == PlayerItemIds.GuardianOrganId
                        ? PlayerItemCategory.SurvivalDefense : PlayerItemCategory.BasicProjectile);
            foreach (var item in PlayerStatItemCatalog.Items) result.Add(item.Id, new ItemDefinition(item.Id, item.Name, item.Description,
                item.Stat == CharacterStatType.MaxHealth ? PlayerItemCategory.SurvivalDefense : PlayerItemCategory.AttackStyle));
            return result;
        }
    }
}
