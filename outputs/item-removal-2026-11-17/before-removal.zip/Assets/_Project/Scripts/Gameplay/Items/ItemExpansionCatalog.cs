using System;
using System.Collections.Generic;

namespace Necrocis
{
    // Effects from the user-supplied November 10 review document.
    public static class ItemExpansionCatalog
    {
        public static IReadOnlyList<ItemDefinition> All { get; } = Array.AsReadOnly(new[]
        {
            new ItemDefinition("ciliated_sole", "섬모 신발", "일반 대시 종료 직후 1.2초간 이동속도 +0.7. 내부 대기 2초.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("friction_mucus", "마찰 점액", "일반 대시 시작 지점에 반경 1m, 1.8초 동안 적 이동속도 18%를 줄이는 흔적. 동시 최대 1개.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("afterimage_fiber", "잔상 근섬유", "일반 대시 종료 1.3초 이내 첫 Q·W가 직접 적중하면 0.18초 뒤 그 적에게 공격력 35% 추가 피해. 내부 대기 3초.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("elastic_joint", "탄성 관절", "0.5초 이상 이동한 뒤 100° 이상 방향을 바꾸면 0.7초간 이동속도 +0.55. 내부 대기 2.5초.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("pressure_pouch", "압력 주머니", "일반 대시 종료 시 반경 1.1m의 잡몹을 최대 0.55m 밀어냄. 내부 대기 3초.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("landing_pad", "착지 연골", "정상적으로 지형 이동을 마치면 2초 동안 받는 첫 일반 전투 피해 20% 감소. 내부 대기 10초.", PlayerItemCategory.SurvivalDefense),
            new ItemDefinition("corner_nerve", "모서리 감각", "걸어서 단단한 벽에서 0.6m 안에 있을 때 이동속도 +0.35. 대시·강제 이동에는 적용되지 않음.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("twin_step", "쌍박 보행", "일반 대시 후 1.5초 안에 걸어서 1.5m 이상 이동하면 해당 대시의 남은 대기시간 0.25초 감소. 대시당 한 번, 내부 대기 4초.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("steady_step", "안정 족궁", "걷는 동안 잡몹 공격에서 받는 넉백 거리 25% 감소. 보스 강제 이동과 지형 이동에는 적용되지 않음.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("escape_vein", "도주 정맥", "전투 피해로 실제 HP가 줄면 1.5초 동안 이동속도 +0.85. 내부 대기 8초.", PlayerItemCategory.SurvivalDefense),
            new ItemDefinition("infectious_mucus", "전염 점액", "중독된 적이 죽으면 반경 2m의 아직 중독되지 않은 가장 가까운 적 1명에게 남은 틱을 옮긴다. 내부 대기 3초. 전이된 독은 다시 전이하지 않음.", PlayerItemCategory.ChainClear),
            new ItemDefinition("frozen_fissure", "동결 균열", "둔화된 적에게 E·R이 처음 적중하면 둔화 잔여시간을 최대 0.75초 소모하고 공격력 55% 추가 피해. 대상별 6초, 시전당 최대 2명.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("bloodtrail_receptor", "혈흔 추적기", "4m 안의 출혈 중인 가장 가까운 적을 향해 ±40°로 걸으면 이동속도 +0.55.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("clot_disruptor", "응고 방해소", "출혈 중인 적의 후방 120°에서 Q·W가 적중하면 남은 출혈 틱 하나를 즉시 적용. 대상별 4초, 남은 틱에서 1회 차감.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("compound_antigen", "복합 항원", "독·출혈·둔화 중 2종 이상이 걸린 적에게 E·R 첫 직접 적중 시 피해 +22%. 대상별 6초, 시전당 최대 2명.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("acid_seal", "산성 밀봉포", "독 상태 적을 Q로 맞히면 적 주위 반경 0.9m에 2초 장판. 초당 피해 0.4, 내부 대기 5초, 최대 1개.", PlayerItemCategory.ChainClear),
            new ItemDefinition("nerve_wick", "신경 심지", "출혈 중인 적에게 직접 공격으로 독을 처음 걸면 즉시 공격력의 25% 피해. 대상별 5초.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("slow_coagulum", "한랭 응고체", "둔화된 적을 Q로 맞히면 기존 출혈의 지속시간 +0.6초. 같은 출혈 부여당 한 번만, 최대 1명.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("serum_leech", "혈청 흡착체", "독·출혈 상태의 서로 다른 적 6명을 처치하면 체력 1 회복. 회복 후 12초 동안 추가 처치 누적 중지.", PlayerItemCategory.SurvivalDefense),
            new ItemDefinition("cold_bloom", "냉포 발아체", "둔화 상태의 잡몹을 처치하면 주변 1.5m의 잡몹 최대 2명에게 1.2초간 15% 둔화. 내부 대기 4초, 이 둔화 자체로 재발동하지 않음.", PlayerItemCategory.ChainClear),
            new ItemDefinition("rupture_platelets", "파열 혈소판", "아이템 보호막이 피해로 모두 소진되면 반경 1.4m의 잡몹을 최대 0.65m 밀어낸다. 내부 대기 6초.", PlayerItemCategory.SurvivalDefense),
            new ItemDefinition("surplus_serum", "잔여 혈청", "초과 회복 3HP를 모으면 10초간 보호막 1. 동시 최대 1개, 생성 후 12초 동안 초과 회복 누적 중지.", PlayerItemCategory.SurvivalDefense),
            new ItemDefinition("buffer_fat", "완충 지방층", "보호막 이후 한 타격의 HP 피해량이 3 이상일 때 1HP를 1초 뒤로 이연. 내부 대기 10초. 이연분은 최초 타격 피해에 속하며 피격 발동을 반복하지 않음.", PlayerItemCategory.SurvivalDefense),
            new ItemDefinition("scar_tissue", "흉터 조직", "전투 피격으로 실제 HP를 잃은 뒤 4초 안에 적을 처치하면 다음 8초 내 전투 피격 피해 15% 감소. 내부 대기 10초.", PlayerItemCategory.SurvivalDefense),
            new ItemDefinition("leukocyte_barrier", "백혈구 방벽", "적 투사체가 몸에 닿지 않고 0.45m 안을 지나가면 2.5초 안에 들어오는 다음 적 탄 1개를 막음. 내부 대기 18초.", PlayerItemCategory.SurvivalDefense),
            new ItemDefinition("shock_absorber", "충격 연골", "정상 지형 기믹으로 받는 첫 HP 피해 1 감소. 내부 대기 22초. 낙사·강제 이동·입력 잠금의 규칙은 유지.", PlayerItemCategory.SurvivalDefense),
            new ItemDefinition("pulse_stitch", "맥박 봉합선", "피해로 체력이 처음 35% 이하가 되면 3초 뒤 HP 1 회복. 내부 대기 25초.", PlayerItemCategory.SurvivalDefense),
            new ItemDefinition("fibrin_lock", "섬유소 잠금판", "한 타격으로 실제 HP가 2 이상 줄면 3초간 이후 일반 전투 피해 12% 감소. 내부 대기 14초.", PlayerItemCategory.SurvivalDefense),
            new ItemDefinition("serous_rind", "장액 외피", "8초간 전투 피해를 받지 않으면 다음 잡몹 접촉 피해 1 감소. 발동 후 12초가 지나야 준비를 다시 시작함.", PlayerItemCategory.SurvivalDefense),
            new ItemDefinition("recovery_capsule", "회복 캡슐", "바이옴 보스전에서 보스에게 준 직접 적중 12회마다 HP 1 회복. 공격·시전 한 번당 1회, 보스전당 최대 2회.", PlayerItemCategory.SurvivalDefense),
            new ItemDefinition("target_lymphocyte", "표식 림프구", "플레이어가 직접 맞힌 마지막 적에게 2초간 표식. 공격형 소환물은 각자 기존 탐지 반경 안에서 그 적을 우선 공격함.", PlayerItemCategory.SummonPet),
            new ItemDefinition("predator_larva", "포식 유생", "동시에 유생 1마리. 5초마다 주변 1.5m에서 적 탄 하나를 먹으면 가장 가까운 적에게 돌진해 공격력 50% 피해.", PlayerItemCategory.SummonPet),
            new ItemDefinition("bilobed_parasite", "쌍엽 기생체", "두 소환물이 플레이어 주변 반경 1m를 마주 보며 회전. 둘 사이 선에 닿는 적에게 0.7초마다 공격력 20% 피해. 대상별 간격.", PlayerItemCategory.SummonPet),
            new ItemDefinition("marrow_nest", "둥지 골수", "E 시전 위치에 3초 둥지. 1초마다 반경 3m에서 가까운 적에게 공격력 25% 피해. 내부 대기 7초, 최대 1개.", PlayerItemCategory.SummonPet),
            new ItemDefinition("retrieval_tentacle", "회수 촉수", "1초마다 반경 2.8m의 경험치 최대 2개를 플레이어 쪽으로 당김. 획득량 유지.", PlayerItemCategory.SummonPet),
            new ItemDefinition("guardian_spore", "초계 포자", "전투 진입 시 포자 1개가 최대 8초 따라다님. 3m 내 적이 플레이어 뒤쪽 120°에 들어오면 40% 피해 후 소멸. 내부 대기 12초.", PlayerItemCategory.SummonPet),
            new ItemDefinition("feeder_sac", "공급 소낭", "플레이어 스킬 직접 적중 3회 후 4초간 공격형 소환물의 직접 피해 +20%. 시전당 1회, 내부 대기 8초.", PlayerItemCategory.SummonPet),
            new ItemDefinition("patrolling_rib", "순찰 늑골", "Q를 사용하면 반경 1.2m를 도는 골편 1개가 1.4초 생김. 닿은 적당 공격력 25% 피해 1회. 내부 대기 4초.", PlayerItemCategory.SummonPet),
            new ItemDefinition("pulse_companion", "동조 유생", "W 직접 적중 5회마다 유생이 그 대상에 공격력 40% 피해의 파동 1회. 공격당 1회 누적, 내부 대기 2초.", PlayerItemCategory.SummonPet),
            new ItemDefinition("relay_colony", "중계 군락", "공격형 소환물의 직접 공격으로 잡몹을 처치하면 4m 내 다음 적에게 공격력 30% 피해의 포자 1개. 내부 대기 5초, 중계 포자는 재발동하지 않음.", PlayerItemCategory.SummonPet),
            new ItemDefinition("scent_receptor", "후각 수용체", "반경 14m에서 가장 가까운 미개봉 상자의 방향 표시. 미생성 상자나 벽 너머 경로는 표시하지 않음.", PlayerItemCategory.FunRandom),
            new ItemDefinition("organ_imprint", "장기 각인", "바이옴 방문마다 첫 3택 1 보상에서 지역 후보를 1자리 보장. 유효 지역 후보가 없으면 일반 후보로 채움.", PlayerItemCategory.FunRandom),
            new ItemDefinition("mutation_lens", "변이 감별안", "바이옴 방문마다 1번, 보상 선택 중 후보 1개를 같은 보상 풀의 새 후보로 교환. 선택 전 사용.", PlayerItemCategory.FunRandom),
            new ItemDefinition("marrow_memory", "골수 기억판", "바이옴 방문마다 첫 레벨업에서 직전에 고른 스탯을 기존 5개 후보 중 한 자리에 포함. 기록이 없으면 기존 규칙 사용.", PlayerItemCategory.FunRandom),
            new ItemDefinition("symbiotic_receptor", "공생 수용체", "바이옴 방문마다 1번, 첫 조건 충족 보상에 보유 아이템과 연계 태그가 맞는 후보 1개 포함. 유효 후보가 있어야 사용 횟수 소모.", PlayerItemCategory.SummonPet),
            new ItemDefinition("boss_marrow_seal", "보스 골수인", "각 바이옴 보스의 첫 처치 보상에서 유효 상위 교체형 후보가 있으면 1개 포함. 보유한 하위형이 있는 계열만 해당.", PlayerItemCategory.BossSpecialized),
            new ItemDefinition("lymph_reservoir", "림프 저장낭", "바이옴 방문마다 첫 아이템 선택을 마치면 체력 1 회복. 상자 재접근과 청크 재진입으로 다시 발동하지 않음.", PlayerItemCategory.SurvivalDefense),
            new ItemDefinition("regional_buffer", "환경 순응막", "바이옴 방문마다 첫 지형 기믹 피해의 HP 감소량을 1 줄임. 0 미만으로 내려가지 않으며 낙사와 강제 이동 규칙은 유지.", PlayerItemCategory.SurvivalDefense),
            new ItemDefinition("trophy_receptor", "흔적 감각포", "14m 안에서 현재 활성화된 미처치 엘리트 중 가장 가까운 한 마리의 방향을 표시.", PlayerItemCategory.BossSpecialized),
            new ItemDefinition("redundancy_filter", "잔여 여과소", "바이옴 방문마다 한 번, 보상 후보가 모두 기본 능력치일 때 유효한 미보유 특수 후보가 있으면 1자리 교체.", PlayerItemCategory.FunRandom),
        });

        public static bool Contains(string id)
        {
            foreach (var item in All) if (string.Equals(item.ItemId, id, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }
    }
}
