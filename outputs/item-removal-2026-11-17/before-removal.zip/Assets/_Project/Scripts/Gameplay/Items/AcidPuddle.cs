using System;
using System.Collections.Generic;
using UnityEngine;

namespace Necrocis
{
    public class AcidPuddle : MonoBehaviour
    {
        private const string PoolName = "PlayerItem.AcidPuddle";
        private const int MaxActivePuddles = 2;
        private static readonly Func<GameObject> CreateFunc = CreatePuddleObject;
        private static readonly List<AcidPuddle> ActivePuddles = new List<AcidPuddle>(MaxActivePuddles);

        private HealthEffectSource? providedSource;
        private float tickDamage;
        private float radius;
        private float tickInterval;
        private float nextTickTime;
        private float startTime;
        private float lifeDuration;
        private int remainingTicks;
        private SpriteRenderer visualRenderer;
        private uint healthGeneration;
        private HealthEffectSource damageSource;
        private readonly HashSet<EnemyLogicalLife> healthRecipients = new HashSet<EnemyLogicalLife>();

        public static AcidPuddle Spawn(Vector3 position, float tickDamage, float duration, float radius, float tickInterval, int maxActive = MaxActivePuddles, HealthEffectSource? source = null)
        {
            PruneInactivePuddles();
            // Refresh nearby acid without restarting its pending damage tick.
            foreach (var active in ActivePuddles)
            {
                if (active.providedSource != source) continue;
                Vector3 delta = active.transform.position - position;
                delta.y = 0f;
                if (delta.sqrMagnitude > Mathf.Max(0.2f, radius) * Mathf.Max(0.2f, radius)) continue;
                active.tickDamage = Mathf.Max(active.tickDamage, tickDamage);
                active.radius = Mathf.Max(active.radius, radius);
                active.remainingTicks = Mathf.Max(active.remainingTicks,
                    Mathf.Max(1, Mathf.RoundToInt(duration / Mathf.Max(0.05f, active.tickInterval))));
                active.startTime = Time.time;
                return active;
            }
            int matching = 0; foreach (var active in ActivePuddles) if (active.providedSource == source) matching++;
            if (matching >= Mathf.Max(1, maxActive))
            {
                // Keep both existing areas alive long enough to deal their damage.
                return null;
            }

            GameObject puddleObject = RuntimePool.Acquire(PoolName, CreateFunc);
            if (puddleObject == null || !puddleObject.TryGetComponent(out AcidPuddle puddle))
            {
                RuntimePool.Release(puddleObject);
                return null;
            }

            puddleObject.name = "AcidPuddle";
            puddleObject.transform.position = new Vector3(position.x, position.y + 0.05f, position.z);
            puddle.Initialize(tickDamage, duration, radius, tickInterval, source);
            ActivePuddles.Remove(puddle);
            ActivePuddles.Add(puddle);
            return puddle;
        }

        public static void RetireSource(HealthEffectSource source)
        { foreach (var puddle in ActivePuddles.ToArray()) if (puddle != null && puddle.providedSource == source) RuntimePool.Release(puddle.gameObject); }

        private void OnDisable()
        {
            ActivePuddles.Remove(this);
            RetireHealthSource();
            unchecked { healthGeneration++; }
        }

        public void Initialize(float damage, float duration, float areaRadius, float interval, HealthEffectSource? source = null)
        {
            RetireHealthSource();
            unchecked { healthGeneration++; }
            providedSource = source;
            damageSource = source ?? HealthEffectSource.ForOwner(this, "acidic-rupture", healthGeneration);
            tickDamage = Mathf.Max(0.1f, damage);
            radius = Mathf.Max(0.2f, areaRadius);
            tickInterval = Mathf.Max(0.05f, interval);
            lifeDuration = Mathf.Max(0.1f, duration);
            startTime = Time.time;
            remainingTicks = Mathf.Max(1, Mathf.RoundToInt(lifeDuration / tickInterval));
            nextTickTime = startTime + tickInterval;
            EnsureVisual();
            visualRenderer.enabled = true;
            transform.localScale = Vector3.one * TextureSpriteCache.GetUniformScaleForWorldSize(
                visualRenderer != null ? visualRenderer.sprite : null,
                Mathf.Max(0.2f, radius * 2f * 0.85f));
        }

        private void Update()
        {
            if (remainingTicks <= 0)
            {
                RuntimePool.Release(gameObject);
                return;
            }

            if (Time.time < nextTickTime)
            {
                UpdateVisual();
                return;
            }

            uint generation = healthGeneration;
            nextTickTime += tickInterval;
            ApplyTickDamage();
            if (healthGeneration != generation || !isActiveAndEnabled) return;
            remainingTicks--;
            UpdateVisual();
        }

        private void ApplyTickDamage()
        {
            uint generation = healthGeneration;
            var enemies = EnemyController.ActiveEnemyControllers;
            if (enemies == null || enemies.Count == 0)
            {
                return;
            }

            Vector3 origin = transform.position;
            float radiusSqr = radius * radius;

            for (int i = 0; i < enemies.Count; i++)
            {
                EnemyController enemy = enemies[i];
                if (enemy == null || enemy.IsDead)
                {
                    continue;
                }

                Vector3 toEnemy = enemy.transform.position - origin;
                toEnemy.y = 0f;
                if (toEnemy.sqrMagnitude > radiusSqr)
                {
                    continue;
                }

                if(enemy.LogicalLife!=null)healthRecipients.Add(enemy.LogicalLife);
                enemy.TakeDamage(tickDamage, damageSource);
                if (healthGeneration != generation || !isActiveAndEnabled) return;
            }
        }

        private void RetireHealthSource()
        {
            if (!providedSource.HasValue) foreach (var recipient in healthRecipients)recipient.RemoveHealthSource(damageSource);
            healthRecipients.Clear();
        }

        private void EnsureVisual()
        {
            if (visualRenderer != null)
            {
                return;
            }

            visualRenderer = gameObject.GetComponent<SpriteRenderer>();
            if (visualRenderer == null)
            {
                visualRenderer = gameObject.AddComponent<SpriteRenderer>();
            }

            Sprite effectSprite = TextureSpriteCache.LoadResourceSprite("ItemEffects/acidic_rupture_effect");
            visualRenderer.sprite = effectSprite != null ? effectSprite : TextureSpriteCache.GetCircleSprite();
            visualRenderer.color = effectSprite != null
                ? new Color(1f, 1f, 1f, 0.72f)
                : new Color(0.32f, 0.95f, 0.28f, 0.42f);
            visualRenderer.sortingOrder = 1200;
        }

        private void UpdateVisual()
        {
            if (visualRenderer == null)
            {
                return;
            }

            float elapsed = Mathf.Clamp01((Time.time - startTime) / Mathf.Max(0.01f, lifeDuration));
            float pulse = 1f + Mathf.Sin(Time.time * 8f) * 0.05f;
            float effectScale = TextureSpriteCache.GetUniformScaleForWorldSize(
                visualRenderer.sprite,
                Mathf.Max(0.2f, radius * 2f * 0.85f));
            transform.localScale = Vector3.one * effectScale * pulse;
            Color color = visualRenderer.color;
            color.a = Mathf.Lerp(0.72f, 0.08f, elapsed);
            visualRenderer.color = color;
        }

        private static GameObject CreatePuddleObject()
        {
            GameObject obj = new GameObject("AcidPuddle");
            obj.AddComponent<SpriteRenderer>();
            obj.AddComponent<AcidPuddle>();
            return obj;
        }

        private static void PruneInactivePuddles()
        {
            for (int i = ActivePuddles.Count - 1; i >= 0; i--)
            {
                AcidPuddle puddle = ActivePuddles[i];
                if (puddle == null || !puddle.gameObject.activeInHierarchy)
                {
                    ActivePuddles.RemoveAt(i);
                }
            }
        }
    }
}
