using System;
using System.Collections.Generic;
using UnityEngine;
using static Necrocis.PlayerItemIds;

namespace Necrocis
{
    // Only original Q/W hits enter this executor. Its extra damage never recursively emits Q/W events.
    internal sealed class ItemTrajectoryEffects
    {
        private readonly IItemCombatHost host;
        private readonly IItemOwnershipView ownership;
        private readonly ItemAttackEffects attack;
        private uint lifetime, sutureVersion;
        private float lastBasicAttackTime, lastMeleeWindow = float.NegativeInfinity, lastRangedWindow = float.NegativeInfinity;
        private float sutureReadyAt, impactReadyAt, claspReadyAt, burstReadyAt, openingReadyAt;
        private int rangedCount;
        private readonly List<Suture> sutures = new List<Suture>();
        private readonly List<Orbit> orbits = new List<Orbit>();
        private const string OrbitPool = "PlayerItem.OrbitVesicle";
        private static readonly Func<GameObject> CreateOrbit = () =>
        {
            var go = new GameObject("OrbitVesicle");
            var renderer = go.AddComponent<SpriteRenderer>();
            renderer.sprite = TextureSpriteCache.GetCircleSprite();
            renderer.color = new Color(.9f, .15f, .25f, .95f);
            renderer.sortingOrder = 5350;
            go.transform.localScale = Vector3.one * .3f;
            return go;
        };
        private struct Suture
        {
            public EnemyController Enemy;
            public uint Generation, Version;
            public float Due, Damage;
            public HealthEffectSource Source;
        }
        private sealed class Orbit
        {
            public GameObject Visual;
            public Vector3 Direction;
            public float StartedAt, Damage, Range;
            public LayerMask Mask;
            public HealthEffectSource Source;
        }
        internal ItemTrajectoryEffects(IItemCombatHost host, IItemOwnershipView ownership, ItemAttackEffects attack)
        { this.host = host; this.ownership = ownership; this.attack = attack; lastBasicAttackTime = Time.time; }

        private bool Has(string id) => ownership.HasItem(id);
        private bool AnyOwned()
        {
            foreach (var item in ItemTrajectoryCatalog.All) if (Has(item.ItemId)) return true;
            return false;
        }
        private bool Current(TrajectoryAttackContext context) => context != null && context.Owner == this
            && context.Lifetime == lifetime && host.Enabled && !host.IsDead;

        public TrajectoryAttackContext Begin(bool ranged, Vector3 direction, float damage, LayerMask mask, float range)
        {
            if (!AnyOwned() || host.IsDead) return null;
            direction.y = 0;
            direction = direction.sqrMagnitude > .0001f ? direction.normalized : Vector3.forward;
            var context = new TrajectoryAttackContext
            {
                Owner = this, Lifetime = lifetime, Ranged = ranged, Direction = direction, SutureVersion = sutureVersion
            };
            float now = Time.time;
            bool compressed = Has(CompressedAlveolusId) && now - lastBasicAttackTime >= 2.5f - .0001f;
            lastBasicAttackTime = now; // One clock shared by Q and W, including attacks that miss.
            if (ranged)
            {
                bool burst = Has(BurstValveId) && now - lastMeleeWindow <= .9f && now >= burstReadyAt;
                lastMeleeWindow = float.NegativeInfinity; // Only the first W after Q may use the window.
                if (Has(OpeningCartilageId)) lastRangedWindow = now;
                if (burst)
                {
                    burstReadyAt = now + 2f;
                    ApplyJet(direction, damage * .35f, mask);
                }
                if (Has(OrbitVesicleId) && ++rangedCount >= 4)
                {
                    rangedCount = 0;
                    var visual = RuntimePool.Acquire(OrbitPool, CreateOrbit);
                    var orbit = new Orbit { Visual = visual, Direction = direction, StartedAt = now,
                        Damage = damage * .4f, Mask = mask, Range = range,
                        Source = host.GetItemHealthEffectSource(OrbitVesicleId, "projectile") };
                    orbits.Add(orbit);
                    PositionOrbit(orbit, 0);
                }
            }
            else if (Has(BurstValveId)) lastMeleeWindow = now;
            if (compressed) ApplyWave(direction, damage * .3f, mask);
            return context;
        }

        public float ConsumeMeleeRange()
        {
            float now = Time.time;
            bool apply = Has(OpeningCartilageId) && now - lastRangedWindow <= .9f && now >= openingReadyAt;
            lastRangedWindow = float.NegativeInfinity;
            if (!apply) return 1f;
            openingReadyAt = now + 2f;
            return 1.2f;
        }

        private static bool Normal(EnemyController enemy) => enemy != null && !enemy.IsDead && !enemy.IsElite
            && !enemy.IsBossEncounter && (enemy.Balance == null || enemy.Balance.Current.Tier == MonsterTier.Normal);

        public void PrepareMelee(TrajectoryAttackContext context, IReadOnlyList<EnemyController> targets)
        {
            if (!Current(context) || context.Ranged || !Has(ImpactMarrowId)) return;
            float distance = .9f * .9f;
            foreach (var enemy in targets)
            {
                if (!Normal(enemy)) continue;
                Vector3 delta = enemy.transform.position - host.Transform.position; delta.y = 0;
                if (delta.sqrMagnitude > distance) continue;
                distance = delta.sqrMagnitude; context.ImpactTarget = enemy; context.ImpactGeneration = enemy.SpawnGeneration;
            }
        }

        public void DirectHit(TrajectoryAttackContext context, EnemyController enemy, uint generation, float damage, Vector3 hitPosition)
        {
            if (!Current(context)) return;
            if (context.Ranged)
            {
                if (context.SutureClaimed) return;
                context.SutureClaimed = true;
                if (!Has(SutureStingerId) || context.SutureVersion != sutureVersion || Time.time < sutureReadyAt
                    || enemy == null || enemy.IsDead || enemy.SpawnGeneration != generation) return;
                sutureReadyAt = Time.time + .8f;
                sutures.Add(new Suture { Enemy = enemy, Generation = generation, Version = sutureVersion,
                    Due = Time.time + .4f, Damage = damage * .25f,
                    Source = host.GetItemHealthEffectSource(SutureStingerId, "delayed-hit") });
                return;
            }
            if (!Normal(enemy) || enemy.SpawnGeneration != generation) return;
            Vector3 delta = enemy.transform.position - host.Transform.position; delta.y = 0;
            float distance = delta.magnitude;
            if (Has(ImpactMarrowId) && !context.ImpactClaimed && enemy == context.ImpactTarget
                && generation == context.ImpactGeneration && Time.time >= impactReadyAt)
            {
                context.ImpactClaimed = true; impactReadyAt = Time.time + 1.8f;
                Displace(enemy, context.Direction, .6f, false);
            }
            if (Has(ClaspingTendonId) && !context.ClaspClaimed && distance >= 1.2f)
            {
                context.ClaspClaimed = true;
                if (Time.time < claspReadyAt) return;
                claspReadyAt = Time.time + 2f;
                Displace(enemy, -delta.normalized, .4f, true);
            }
        }

        // Small steps preserve world movement restrictions; a box sweep also stops at physical walls.
        private void Displace(EnemyController enemy, Vector3 direction, float distance, bool avoidPlayer)
        {
            if (enemy.IsPatternPositionLocked || direction.sqrMagnitude < .0001f) return;
            direction.y = 0; direction.Normalize();
            Collider body = enemy.GetComponent<Collider>();
            Rigidbody rigidbody = enemy.GetComponent<Rigidbody>();
            Collider playerBody = host.Transform.GetComponent<Collider>();
            for (float left = distance; left > .001f; left -= .05f)
            {
                float step = Mathf.Min(.05f, left);
                if (body != null)
                {
                    Bounds bounds = body.bounds;
                    var hits = Physics.BoxCastAll(bounds.center, Vector3.Max(bounds.extents - Vector3.one * .01f, Vector3.one * .01f),
                        direction, Quaternion.identity, step + .01f, ~0, QueryTriggerInteraction.Ignore);
                    foreach (var hit in hits)
                    {
                        if (hit.collider == body || hit.collider.transform.IsChildOf(enemy.transform)
                            || hit.collider.GetComponentInParent<EnemyController>() != null
                            || hit.collider.transform.IsChildOf(host.Transform)) continue;
                        if (Mathf.Abs(Vector3.Dot(hit.normal, direction)) > .01f) step = Mathf.Min(step, Mathf.Max(0, hit.distance - .01f));
                    }
                    if (avoidPlayer && playerBody != null)
                    {
                        Vector3 center = bounds.center + direction * step;
                        Bounds other = playerBody.bounds;
                        if (Mathf.Abs(center.x - other.center.x) <= bounds.extents.x + other.extents.x + .01f
                            && Mathf.Abs(center.z - other.center.z) <= bounds.extents.z + other.extents.z + .01f) break;
                    }
                }
                if (step < .001f) break;
                Vector3 before = rigidbody != null ? rigidbody.position : enemy.transform.position;
                enemy.ApplyKnockback(direction, step);
                Vector3 after = rigidbody != null ? rigidbody.position : enemy.transform.position;
                // Rigidbody.position can be ahead of Transform until the next physics step.
                // Subsequent sweeps in this same hit must use the newly committed body position.
                enemy.transform.position = after;
                Physics.SyncTransforms();
                if ((after - before).sqrMagnitude < .0000001f) break;
            }
        }

        private static bool Candidate(EnemyController enemy, LayerMask mask) => ItemEnemyQueries.IsTargetable(enemy)
            && (mask.value & (1 << enemy.gameObject.layer)) != 0;

        private void ApplyWave(Vector3 direction, float damage, LayerMask mask)
        {
            Vector3 origin = host.Transform.position;
            HealthEffectSource source = host.GetItemHealthEffectSource(CompressedAlveolusId, "wave");
            using var targets = EnemyHitLife.CaptureOwned(EnemyController.ActiveEnemyControllers);
            for (int i = 0; i < targets.Length; i++)
            {
                var life = targets.Buffer[i]; var enemy = life.Enemy;
                if (!life.IsActiveCandidate || !Candidate(enemy, mask)) continue;
                Vector3 delta = enemy.transform.position - origin; delta.y = 0;
                if (delta.sqrMagnitude > 1.8f * 1.8f || delta.sqrMagnitude > .0001f
                    && Vector3.Dot(delta.normalized, direction) < Mathf.Cos(50 * Mathf.Deg2Rad)) continue;
                enemy.TakeDamage(damage, source);
            }
            DrawLine("CompressedAlveolus", origin, origin + direction * 1.8f, .4f, new Color(.9f, .5f, .2f));
            DrawLine("CompressedAlveolus", origin, origin + Quaternion.Euler(0, -50, 0) * direction * 1.8f, .08f, Color.yellow);
            DrawLine("CompressedAlveolus", origin, origin + Quaternion.Euler(0, 50, 0) * direction * 1.8f, .08f, Color.yellow);
        }

        private void ApplyJet(Vector3 direction, float damage, LayerMask mask)
        {
            Vector3 origin = host.Transform.position, end = origin + direction * 2f;
            EnemyController closest = null;
            float nearest = float.PositiveInfinity;
            foreach (var enemy in EnemyController.ActiveEnemyControllers)
            {
                if (!Candidate(enemy, mask)) continue;
                Vector3 delta = enemy.transform.position - origin; delta.y = 0;
                float along = Vector3.Dot(delta, direction);
                if (along < 0 || along > 2 || along >= nearest) continue;
                Vector3 side = delta - direction * along;
                if (side.sqrMagnitude > .2f * .2f) continue;
                closest = enemy; nearest = along;
            }
            if (closest != null) closest.TakeDamage(damage, host.GetItemHealthEffectSource(BurstValveId, "jet"));
            DrawLine("BurstValve", origin, end, .15f, new Color(1f, .3f, .15f));
        }
        private void DrawLine(string name, Vector3 from, Vector3 to, float width, Color color)
            => host.SpawnLineVisual(name, from + Vector3.up * .5f, to + Vector3.up * .5f, color,
                new Color(color.r, color.g, color.b, 0), width, width, .15f);

        private void PositionOrbit(Orbit orbit, float progress)
        {
            if (orbit.Visual == null) return;
            Vector3 offset = Quaternion.Euler(0, progress * 180, 0) * -orbit.Direction;
            orbit.Visual.transform.position = host.Transform.position + Vector3.up * .6f + offset;
        }

        public void Tick()
        {
            if (host.IsDead) { ResetAll(); return; }
            float now = Time.time;
            for (int i = sutures.Count - 1; i >= 0; i--)
            {
                var pending = sutures[i];
                if (now < pending.Due) continue;
                sutures.RemoveAt(i); // Claim before synchronous damage callbacks.
                if (!Has(SutureStingerId) || pending.Version != sutureVersion || pending.Enemy == null
                    || !pending.Enemy.isActiveAndEnabled || pending.Enemy.IsDead || pending.Enemy.SpawnGeneration != pending.Generation) continue;
                pending.Enemy.TakeDamage(pending.Damage, pending.Source);
            }
            for (int i = orbits.Count - 1; i >= 0; i--)
            {
                var orbit = orbits[i];
                float progress = Mathf.Clamp01((now - orbit.StartedAt) / .25f);
                PositionOrbit(orbit, progress);
                if (progress < 1) continue;
                orbits.RemoveAt(i);
                Vector3 origin = orbit.Visual != null ? orbit.Visual.transform.position : host.Transform.position;
                RuntimePool.Release(orbit.Visual);
                if (Has(OrbitVesicleId)) attack.SpawnChildProjectile(origin, orbit.Direction, orbit.Damage, orbit.Mask,
                    orbit.Range, Projectile.SpawnKind.TrajectoryExtra, orbit.Source);
            }
        }

        public void Acquired(string id) { if (ItemTrajectoryCatalog.Contains(id)) Removed(id); }
        public void Removed(string id)
        {
            switch (id?.ToLowerInvariant())
            {
                case CompressedAlveolusId: lastBasicAttackTime = Time.time; break;
                case SutureStingerId: unchecked { sutureVersion++; } sutures.Clear(); sutureReadyAt = Time.time; break;
                case OrbitVesicleId:
                    rangedCount = 0;
                    foreach (var orbit in orbits) RuntimePool.Release(orbit.Visual);
                    orbits.Clear(); break;
                case ImpactMarrowId: impactReadyAt = Time.time; break;
                case ClaspingTendonId: claspReadyAt = Time.time; break;
                case BurstValveId: lastMeleeWindow = float.NegativeInfinity; burstReadyAt = Time.time; break;
                case OpeningCartilageId: lastRangedWindow = float.NegativeInfinity; openingReadyAt = Time.time; break;
            }
        }
        public void ResetAll()
        {
            unchecked { lifetime++; }
            foreach (var item in ItemTrajectoryCatalog.All) Removed(item.ItemId);
        }
        public void Capture(SavedItemStateData state)
        {
            if (state == null || !ItemTrajectoryCatalog.Contains(state.itemId)) return;
            state.hasTrajectoryState = true;
            float now = Time.time, ready = now, window = float.NegativeInfinity;
            switch (state.itemId)
            {
                case CompressedAlveolusId: state.trajectoryIdleSeconds = Mathf.Clamp(now - lastBasicAttackTime, 0, 2.5f); break;
                case SutureStingerId: ready = sutureReadyAt; break;
                case OrbitVesicleId: state.trajectoryAttackProgress = rangedCount; break;
                case ImpactMarrowId: ready = impactReadyAt; break;
                case ClaspingTendonId: ready = claspReadyAt; break;
                case BurstValveId: ready = burstReadyAt; window = lastMeleeWindow; break;
                case OpeningCartilageId: ready = openingReadyAt; window = lastRangedWindow; break;
            }
            state.trajectoryCooldownRemaining = Mathf.Max(0, ready - now);
            state.trajectoryWindowRemaining = Mathf.Max(0, window + .9f - now);
        }
        public void Restore(IReadOnlyList<SavedItemStateData> states)
        {
            if (states == null) return;
            float now = Time.time;
            foreach (var state in states)
            {
                if (state == null || !state.hasTrajectoryState || !Has(state.itemId)) continue;
                float remaining = Mathf.Max(0, state.trajectoryCooldownRemaining);
                float window = state.trajectoryWindowRemaining > 0
                    ? now + Mathf.Clamp(state.trajectoryWindowRemaining, 0, .9f) - .9f : float.NegativeInfinity;
                switch (state.itemId)
                {
                    case CompressedAlveolusId: lastBasicAttackTime = now - Mathf.Clamp(state.trajectoryIdleSeconds, 0, 2.5f); break;
                    case SutureStingerId: sutureReadyAt = now + Mathf.Min(.8f, remaining); break;
                    case OrbitVesicleId: rangedCount = Mathf.Clamp(state.trajectoryAttackProgress, 0, 3); break;
                    case ImpactMarrowId: impactReadyAt = now + Mathf.Min(1.8f, remaining); break;
                    case ClaspingTendonId: claspReadyAt = now + Mathf.Min(2f, remaining); break;
                    case BurstValveId: burstReadyAt = now + Mathf.Min(2f, remaining); lastMeleeWindow = window; break;
                    case OpeningCartilageId: openingReadyAt = now + Mathf.Min(2f, remaining); lastRangedWindow = window; break;
                }
            }
        }
    }
}
