using UnityEngine;

namespace Necrocis
{
    internal sealed partial class ItemExpansionEffects
    {
        private LineRenderer scentArrow, trophyArrow;
        private float nextIndicatorScan;
        private Vector3? scentTarget, trophyTarget;
        private void ClearIndicators()
        {
            if (scentArrow != null) UnityEngine.Object.Destroy(scentArrow.gameObject);
            if (trophyArrow != null) UnityEngine.Object.Destroy(trophyArrow.gameObject);
            nextIndicatorScan = 0;
            scentArrow = trophyArrow = null; scentTarget = trophyTarget = null;
        }
        private void TickIndicators()
        {
            if (Time.time >= nextIndicatorScan)
            {
                nextIndicatorScan = Time.time + .2f; scentTarget = trophyTarget = null;
                if (Has("scent_receptor"))
                {
                    float best = 14;
                    foreach (var box in UnityEngine.Object.FindObjectsByType<WorldItemBoxPickup>(FindObjectsSortMode.None))
                    {
                        if (!box.IsUnopenedReward) continue;
                        float distance = Distance(owner.transform.position, box.transform.position);
                        if (distance <= best && ClearGroundPath(owner.transform.position, box.transform.position)) { best = distance; scentTarget = box.transform.position; }
                    }
                }
                if (Has("trophy_receptor"))
                {
                    var enemy = FindClosest(owner.transform.position, 14, predicate: target => target.IsElite);
                    if (enemy != null) trophyTarget = enemy.transform.position;
                }
            }
            ShowArrow(ref scentArrow, Has("scent_receptor") ? scentTarget : null, new Color(1, .8f, .2f), 1.3f);
            ShowArrow(ref trophyArrow, Has("trophy_receptor") ? trophyTarget : null, new Color(1, .25f, .3f), 1.8f);
        }
        private bool ClearGroundPath(Vector3 start, Vector3 end)
        {
            var biome = BiomeManager.Active;
            if (biome == null) return true;
            int steps = Mathf.Max(1, Mathf.CeilToInt(Distance(start, end) / Mathf.Max(.1f, biome.TileSize * .4f)));
            for (int i = 1; i <= steps; i++)
            { var cell = biome.WorldToGrid(Vector3.Lerp(start, end, (float)i / steps)); if (!biome.IsValidPosition(cell.x, cell.y) || !biome.IsWalkable(cell.x, cell.y)) return false; }
            return true;
        }
        private void ShowArrow(ref LineRenderer arrow, Vector3? target, Color color, float height)
        {
            if (!target.HasValue) { if (arrow != null) arrow.enabled = false; return; }
            if (arrow == null)
            {
                var go = new GameObject("ItemDirectionArrow"); go.transform.SetParent(owner.transform, false);
                arrow = go.AddComponent<LineRenderer>(); arrow.useWorldSpace = true; arrow.positionCount = 5;
                arrow.sharedMaterial = CombatVfxResources.GetLineMaterial(); arrow.startWidth = arrow.endWidth = .07f;
                arrow.startColor = arrow.endColor = color; arrow.sortingOrder = 5400;
            }
            arrow.enabled = true;
            Vector3 direction = target.Value - owner.transform.position; direction.y = 0; direction.Normalize();
            Vector3 start = owner.transform.position + Vector3.up * height, tip = start + direction * 1.3f;
            Vector3 side = Vector3.Cross(Vector3.up, direction) * .2f;
            arrow.SetPosition(0, start + direction * .5f); arrow.SetPosition(1, tip);
            arrow.SetPosition(2, tip - direction * .35f + side); arrow.SetPosition(3, tip); arrow.SetPosition(4, tip - direction * .35f - side);
        }
    }
}
