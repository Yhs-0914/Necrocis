using System;
using System.Collections.Generic;
using UnityEngine;
using static Necrocis.PlayerItemIds;

namespace Necrocis
{
    internal sealed class ItemSkillEffects
    {
        private readonly IItemCombatHost host;
        private readonly IItemOwnershipView ownership;
        private readonly ItemAttackEffects attack;
        private readonly Dictionary<string, uint> versions = new Dictionary<string, uint>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<SkillTargetKey, float> pairedMarks = new Dictionary<SkillTargetKey, float>();
        private readonly List<SkillTargetKey> expiredMarks = new List<SkillTargetKey>();
        private readonly List<DelayedPulse> pulses = new List<DelayedPulse>();
        private uint lifetime;
        private int manaProgress;
        private float reflexUntil = float.NegativeInfinity, residualUntil = float.NegativeInfinity, retaliationUntil = float.NegativeInfinity;
        private float reflexReadyAt, resonantReadyAt, rehearsalReadyAt, medullaReadyAt, pairedReadyAt, retaliationReadyAt;
        private struct DelayedPulse { public SkillCastContext Cast; public float Due, Damage; public Vector3 Origin; public HealthEffectSource Source; }
        internal ItemSkillEffects(IItemCombatHost host, IItemOwnershipView ownership, ItemAttackEffects attack)
        { this.host = host; this.ownership = ownership; this.attack = attack; }
        private bool Has(string id) => ownership.HasItem(id);
        private uint Version(string id) { versions.TryGetValue(id, out uint value); return value; }
        private Dictionary<string, uint> Snapshot()
        {
            var result = new Dictionary<string, uint>(StringComparer.OrdinalIgnoreCase);
            foreach (var item in ItemSkillCatalog.All) if (Has(item.ItemId)) result.Add(item.ItemId, Version(item.ItemId));
            return result;
        }
        private bool Can(Dictionary<string, uint> snapshot, string id) => snapshot != null && snapshot.TryGetValue(id, out uint version)
            && version == Version(id) && Has(id);
        private bool Current(SkillCastContext cast) => cast != null && cast.ItemOwner == this && cast.ItemLifetime == lifetime
            && !cast.IsCancelled && host.Enabled && !host.IsDead && cast.Controller != null && cast.Controller.isActiveAndEnabled;
        private bool Can(SkillCastContext cast, string id) => Current(cast) && Can(cast.Versions, id);
        public TrajectoryAttackContext BeginBasic(TrajectoryAttackContext context, bool ranged, Vector3 direction, LayerMask mask)
        {
            if (!Has(ReflexGanglionId) && !Has(ManaReservoirId) && !Has(ResidualMuscleId)) return context;
            context ??= new TrajectoryAttackContext { Ranged = ranged, Direction = direction };
            context.SkillOwner = this; context.SkillLifetime = lifetime; context.SkillVersions = Snapshot(); context.SkillMask = mask;
            return context;
        }
        public void BasicHit(TrajectoryAttackContext context, EnemyController enemy, uint generation, float damage, Vector3 position)
        {
            if (context == null || context.SkillOwner != this || context.SkillLifetime != lifetime || !host.Enabled || host.IsDead) return;
            if (!context.ManaCounted && Can(context.SkillVersions, ManaReservoirId))
            { context.ManaCounted = true; manaProgress = Mathf.Min(6, manaProgress + 1); }
            float now = Time.time;
            if (Can(context.SkillVersions, ReflexGanglionId) && now <= reflexUntil && now >= reflexReadyAt)
            {
                reflexUntil = float.NegativeInfinity; reflexReadyAt = now + 3;
                if (enemy != null && !enemy.IsDead && enemy.SpawnGeneration == generation)
                    enemy.TakeDamage(damage * .3f, host.GetItemHealthEffectSource(ReflexGanglionId, "basic-followup"));
            }
            if (!context.Ranged && Can(context.SkillVersions, ResidualMuscleId) && now <= residualUntil)
            {
                residualUntil = float.NegativeInfinity;
                Pulse(position, 1, host.AttackPower * .35f, context.SkillMask,
                    host.GetItemHealthEffectSource(ResidualMuscleId, "pulse"));
            }
        }
        public void BeginCast(SkillCastContext cast)
        {
            cast.ItemOwner = this; cast.ItemLifetime = lifetime; cast.Versions = Snapshot();
            float now = Time.time;
            // Capture before cast-triggered extras can synchronously move, kill or recycle a target.
            if (Can(cast, LongSynapseId))
                foreach (var enemy in EnemyController.ActiveEnemyControllers)
                {
                    if (!ItemEnemyQueries.IsTargetable(enemy)) continue;
                    Vector3 delta = enemy.transform.position - cast.Origin; delta.y = 0;
                    if (delta.sqrMagnitude >= 16) cast.FarTargets.Add(new SkillTargetKey(enemy));
                }
            if (cast.Slot == PlayerClassSkillController.SkillSlot.Skill1)
            {
                cast.ManaCharged = Can(cast, ManaReservoirId) && manaProgress >= 6;
                if (cast.ManaCharged) manaProgress = 0;
                cast.RetaliationCharged = Can(cast, RetaliationCortexId) && now <= retaliationUntil && now >= retaliationReadyAt;
                if (cast.RetaliationCharged) retaliationReadyAt = now + 8;
                retaliationUntil = float.NegativeInfinity;
                if (Can(cast, DifferentiationCellId)) Differentiate(cast);
            }
            else if (Can(cast, ResidualMuscleId)) residualUntil = now + 3;
        }
        public float Modify(SkillCastContext cast, EnemyController enemy, float damage)
        {
            if (!Current(cast)) return damage;
            float multiplier = 1;
            if (cast.ManaCharged && Can(cast, ManaReservoirId)) multiplier *= 1.2f;
            if (cast.RetaliationCharged && Can(cast, RetaliationCortexId)) multiplier *= 1.18f;
            var key = new SkillTargetKey(enemy);
            if (!cast.LongConsumed && Can(cast, LongSynapseId) && cast.FarTargets.Contains(key))
            { cast.LongConsumed = true; multiplier *= 1.15f; }
            if (cast.Slot == PlayerClassSkillController.SkillSlot.Skill2 && !cast.PairedAttempted && Can(cast, PairedNerveId))
            {
                cast.PairedAttempted = true;
                if (Time.time >= pairedReadyAt && pairedMarks.TryGetValue(key, out float until) && Time.time <= until)
                {
                    multiplier *= 1.2f; pairedReadyAt = Time.time + 8; pairedMarks.Remove(key);
                }
            }
            return damage * multiplier;
        }
        public void DirectHit(SkillCastContext cast, SkillTargetKey key, Vector3 position, bool killedNormal)
        {
            if (!Current(cast)) return;
            float now = Time.time;
            if (Can(cast, ReflexGanglionId) && now >= reflexReadyAt) reflexUntil = now + 2;
            if (cast.Slot != PlayerClassSkillController.SkillSlot.Skill1) return;
            if (Can(cast, PairedNerveId)) pairedMarks[key] = now + 5;
            if (!cast.MedullaConsumed && killedNormal && Can(cast, MedullaValveId))
            {
                cast.MedullaConsumed = true;
                if (now >= medullaReadyAt && cast.Controller.ReduceRemainingCooldown(PlayerClassSkillController.SkillSlot.Skill2, .7f) > 0)
                    medullaReadyAt = now + 4;
            }
        }
        public void Finish(SkillCastContext cast)
        {
            if (!Current(cast)) return;
            float now = Time.time;
            if (cast.UniqueTargets.Count >= 3 && Can(cast, ResonantBoneId) && now >= resonantReadyAt)
            {
                resonantReadyAt = now + 5;
                Pulse(cast.LastHitPosition, 1.4f, host.AttackPower * .45f, cast.Mask,
                    host.GetItemHealthEffectSource(ResonantBoneId, "pulse"));
            }
            if (cast.DirectHitCount == 0 && Can(cast, RehearsalTissueId) && now >= rehearsalReadyAt)
            {
                float remaining = cast.Controller.GetRemainingCooldown(cast.Slot);
                if (cast.Controller.ReduceRemainingCooldown(cast.Slot, Mathf.Min(2, remaining * .2f)) > 0)
                    rehearsalReadyAt = now + 10;
            }
        }
        public void CombatDamage(float actualHpLoss)
        {
            if (actualHpLoss > 0 && !host.IsDead && Has(RetaliationCortexId) && Time.time >= retaliationReadyAt)
                retaliationUntil = Time.time + 4;
        }
        private void Differentiate(SkillCastContext cast)
        {
            float damage = host.AttackPower * .45f;
            var source = host.GetItemHealthEffectSource(DifferentiationCellId, "class-extra");
            switch (cast.Class)
            {
                case PlayerClassType.Warrior:
                    using (var targets = EnemyHitLife.CaptureOwned(EnemyController.ActiveEnemyControllers))
                        for (int i = 0; i < targets.Length; i++)
                        {
                            var life = targets.Buffer[i];
                            if (life.IsActiveCandidate && PlayerAttackGeometry.Eligible(life.Enemy, cast.Mask)
                                && PlayerAttackGeometry.InArc(cast.Origin, cast.Direction, 1.6f, 90, life.Enemy))
                                life.Enemy.TakeDamage(damage, source);
                        }
                    Draw(cast.Origin, cast.Origin + cast.Direction * 1.6f);
                    break;
                case PlayerClassType.Archer:
                    attack.SpawnChildProjectile(cast.Origin + Vector3.up * .6f, cast.Direction, damage, cast.Mask,
                        3, Projectile.SpawnKind.TrajectoryExtra, source);
                    break;
                case PlayerClassType.Mage:
                    pulses.Add(new DelayedPulse { Cast = cast, Due = Time.time + .45f, Damage = damage, Origin = cast.Origin, Source = source });
                    break;
            }
        }
        private void Pulse(Vector3 position, float radius, float damage, LayerMask mask, HealthEffectSource source)
        {
            using var targets = EnemyHitLife.CaptureOwned(EnemyController.ActiveEnemyControllers);
            for (int i = 0; i < targets.Length; i++)
            {
                var life = targets.Buffer[i];
                if (life.IsActiveCandidate && PlayerAttackGeometry.Eligible(life.Enemy, mask)
                    && PlayerAttackGeometry.InCircle(position, radius, life.Enemy)) life.Enemy.TakeDamage(damage, source);
            }
            Draw(position - Vector3.right * radius, position + Vector3.right * radius);
            Draw(position - Vector3.forward * radius, position + Vector3.forward * radius);
        }
        private void Draw(Vector3 from, Vector3 to) => host.SpawnLineVisual("SkillItemPulse", from + Vector3.up * .5f,
            to + Vector3.up * .5f, new Color(.4f, .7f, 1), new Color(.4f, .7f, 1, 0), .25f, .1f, .2f);
        public void Tick()
        {
            if (host.IsDead) { ResetAll(); return; }
            for (int i = pulses.Count - 1; i >= 0; i--)
            {
                var pulse = pulses[i]; if (Time.time < pulse.Due) continue;
                pulses.RemoveAt(i);
                if (Can(pulse.Cast, DifferentiationCellId)) Pulse(pulse.Origin, 1.2f, pulse.Damage, pulse.Cast.Mask, pulse.Source);
            }
            if (pairedMarks.Count == 0) return;
            expiredMarks.Clear();
            foreach (var pair in pairedMarks) if (Time.time > pair.Value) expiredMarks.Add(pair.Key);
            foreach (var key in expiredMarks) pairedMarks.Remove(key);
        }
        public void ResetItem(string id)
        {
            if (!ItemSkillCatalog.Contains(id)) return;
            versions[id] = unchecked(Version(id) + 1);
            switch (id.ToLowerInvariant())
            {
                case ReflexGanglionId: reflexUntil = float.NegativeInfinity; reflexReadyAt = Time.time; break;
                case ResonantBoneId: resonantReadyAt = Time.time; break;
                case ManaReservoirId: manaProgress = 0; break;
                case RehearsalTissueId: rehearsalReadyAt = Time.time; break;
                case DifferentiationCellId: pulses.Clear(); break;
                case ResidualMuscleId: residualUntil = float.NegativeInfinity; break;
                case MedullaValveId: medullaReadyAt = Time.time; break;
                case PairedNerveId: pairedMarks.Clear(); pairedReadyAt = Time.time; break;
                case RetaliationCortexId: retaliationUntil = float.NegativeInfinity; retaliationReadyAt = Time.time; break;
            }
        }
        public void ResetAll()
        {
            unchecked { lifetime++; }
            foreach (var item in ItemSkillCatalog.All) ResetItem(item.ItemId);
        }
        public void Capture(SavedItemStateData state)
        {
            if (state == null || !ItemSkillCatalog.Contains(state.itemId)) return;
            state.hasSkillItemState = true;
            float ready = Time.time, window = float.NegativeInfinity;
            switch (state.itemId)
            {
                case ReflexGanglionId: ready = reflexReadyAt; window = reflexUntil; break;
                case ResonantBoneId: ready = resonantReadyAt; break;
                case ManaReservoirId: state.skillItemProgress = manaProgress; break;
                case RehearsalTissueId: ready = rehearsalReadyAt; break;
                case ResidualMuscleId: window = residualUntil; break;
                case MedullaValveId: ready = medullaReadyAt; break;
                case PairedNerveId: ready = pairedReadyAt; break;
                case RetaliationCortexId: ready = retaliationReadyAt; window = retaliationUntil; break;
            }
            state.skillItemCooldownRemaining = Mathf.Max(0, ready - Time.time);
            state.skillItemWindowRemaining = Mathf.Max(0, window - Time.time);
        }
        public void Restore(IReadOnlyList<SavedItemStateData> states)
        {
            if (states == null) return;
            foreach (var state in states)
            {
                if (state == null || !state.hasSkillItemState || !Has(state.itemId)) continue;
                float remaining = Mathf.Max(0, state.skillItemCooldownRemaining);
                float Window(float maximum) => state.skillItemWindowRemaining > 0
                    ? Time.time + Mathf.Clamp(state.skillItemWindowRemaining, 0, maximum) : float.NegativeInfinity;
                switch (state.itemId)
                {
                    case ReflexGanglionId: reflexReadyAt = Time.time + Mathf.Min(3, remaining); reflexUntil = Window(2); break;
                    case ResonantBoneId: resonantReadyAt = Time.time + Mathf.Min(5, remaining); break;
                    case ManaReservoirId: manaProgress = Mathf.Clamp(state.skillItemProgress, 0, 6); break;
                    case RehearsalTissueId: rehearsalReadyAt = Time.time + Mathf.Min(10, remaining); break;
                    case ResidualMuscleId: residualUntil = Window(3); break;
                    case MedullaValveId: medullaReadyAt = Time.time + Mathf.Min(4, remaining); break;
                    case PairedNerveId: pairedReadyAt = Time.time + Mathf.Min(8, remaining); break;
                    case RetaliationCortexId: retaliationReadyAt = Time.time + Mathf.Min(8, remaining); retaliationUntil = Window(4); break;
                }
            }
        }
    }
}
