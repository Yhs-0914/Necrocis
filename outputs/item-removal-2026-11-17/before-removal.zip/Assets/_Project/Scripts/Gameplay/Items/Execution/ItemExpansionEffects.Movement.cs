using UnityEngine;

namespace Necrocis
{
    internal sealed partial class ItemExpansionEffects
    {
        private Vector3 previousPosition, previousDirection, frictionPosition;
        private float walkingSeconds, dashWalkUntil, dashWalkDistance, frictionUntil, frictionTick;
        private bool dashWalkUsed;
        private bool Walking => player != null && player.IsMoving && !player.IsDashing && !player.IsBossDisplaced
            && !player.MovementExecutions.BlocksOrdinaryInput && (terrain == null || !terrain.IsTraversing);
        private string VisitKey => ItemExpansionRewards.CurrentVisitKey;
        internal float BasicMultiplier => 1;
        internal float DashSpeedMultiplier => 1;
        internal float DashCooldown(float original) => original;
        internal void BasicAttack() { }
        private void SyncMovementBonus(float bonus)
        {
            if (stats == null || Mathf.Approximately(appliedMove, bonus)) return;
            appliedMove = bonus;
            stats.RuntimeStats.RemoveModifiersFromSource(moveSource);
            if (bonus != 0) stats.RuntimeStats.AddModifier(CharacterStatType.MoveSpeed, bonus, CharacterStatModifierMode.Flat, moveSource);
        }
        internal void DashStarted(Vector3 position, float duration)
        {
            previousPosition = position; walkingSeconds = 0;
            if (Has("friction_mucus")) { frictionPosition = position; frictionUntil = Time.time + 1.8f; frictionTick = 0; }
        }
        internal void DashEnded(Vector3 position)
        {
            previousPosition = position;
            if (Trigger("ciliated_sole", 2)) Get("ciliated_sole").Until = Time.time + 1.2f;
            if (Has("afterimage_fiber")) Get("afterimage_fiber").Until = Time.time + 1.3f;
            if (Has("twin_step")) { dashWalkUntil = Time.time + 1.5f; dashWalkDistance = 0; dashWalkUsed = false; }
            if (Trigger("pressure_pouch", 3)) PushNormals(position, 1.1f, .55f);
        }
        internal void TraversalEnded()
        {
            previousPosition = owner.transform.position;
            if (Trigger("landing_pad", 10)) Get("landing_pad").Until = Time.time + 2;
        }
        internal float KnockbackMultiplier(EnemyController attacker) => Has("steady_step") && Walking && Normal(attacker) ? .75f : 1;
        private void PushNormals(Vector3 center, float radius, float distance)
        {
            using var targets = EnemyHitLife.CaptureOwned(EnemyController.ActiveEnemyControllers);
            for (int i = 0; i < targets.Length; i++)
            {
                var life = targets.Buffer[i]; var enemy = life.Enemy;
                if (!life.IsActiveCandidate || !Normal(enemy) || !ItemEnemyQueries.IsTargetable(enemy) || Distance(center, enemy.transform.position) > radius) continue;
                Vector3 direction = enemy.transform.position - center; direction.y = 0;
                if (direction.sqrMagnitude < .001f) direction = player != null ? player.GetLogicalFacingDirection() : Vector3.forward;
                enemy.ApplyKnockback(direction, distance);
            }
        }
        private void TickMovement()
        {
            Vector3 position = owner.transform.position, delta = position - previousPosition; delta.y = 0; previousPosition = position;
            bool walking = Walking;
            float distance = walking && delta.magnitude <= Mathf.Max(.5f, stats.MoveSpeed * Time.deltaTime * 2) ? delta.magnitude : 0;
            Vector3 direction = player != null ? player.GetLogicalFacingDirection() : delta.normalized;
            if (walking && Has("elastic_joint"))
            {
                if (walkingSeconds >= .5f && previousDirection.sqrMagnitude > .001f && Vector3.Angle(previousDirection, direction) >= 100 && Trigger("elastic_joint", 2.5f))
                { Get("elastic_joint").Until = Time.time + .7f; walkingSeconds = 0; }
                walkingSeconds += Time.deltaTime;
            }
            else walkingSeconds = 0;
            previousDirection = direction;
            if (walking && !dashWalkUsed && Time.time <= dashWalkUntil && Has("twin_step"))
            {
                dashWalkDistance += distance;
                if (dashWalkDistance >= 1.5f && Trigger("twin_step", 4))
                { dashWalkUsed = true; player.ReduceOrdinaryDashCooldown(.25f); }
            }
            float bonus = Has("ciliated_sole") && Get("ciliated_sole").Until > Time.time ? .7f : 0;
            if (Has("elastic_joint") && Get("elastic_joint").Until > Time.time) bonus += .55f;
            if (Has("escape_vein") && Get("escape_vein").Until > Time.time) bonus += .85f;
            if (walking && Has("corner_nerve") && NearSolidWall(position, .6f)) bonus += .35f;
            if (walking && Has("bloodtrail_receptor"))
            {
                var enemy = FindClosest(position, 4, predicate: target => Status(target)?.IsBleeding == true);
                if (enemy != null)
                {
                    Vector3 toward = enemy.transform.position - position; toward.y = 0;
                    if (Vector3.Angle(direction, toward) <= 40) bonus += .55f;
                }
            }
            SyncMovementBonus(bonus);
            if (Has("friction_mucus") && Time.time < frictionUntil && Time.time >= frictionTick)
            {
                frictionTick = Time.time + .1f;
                using var targets = EnemyHitLife.CaptureOwned(EnemyController.ActiveEnemyControllers);
                for (int i = 0; i < targets.Length; i++)
                {
                    var life = targets.Buffer[i]; var enemy = life.Enemy;
                    if (life.IsActiveCandidate && ItemEnemyQueries.IsTargetable(enemy) && Distance(frictionPosition, enemy.transform.position) <= 1)
                        EnsureStatus(enemy).ApplyMoveSpeedSlow(.18f, Mathf.Min(.15f, frictionUntil - Time.time), Source("friction_mucus", "slow"));
                }
            }
        }
        private bool NearSolidWall(Vector3 position, float radius)
        {
            var biome = BiomeManager.Active;
            if (biome == null) return false;
            var cell = biome.WorldToGrid(position);
            for (int x = -1; x <= 1; x++) for (int y = -1; y <= 1; y++)
            {
                int gx = cell.x + x, gy = cell.y + y;
                if (!biome.IsSolidWallForItems(gx, gy)) continue;
                Vector3 center = biome.GridToWorld(gx, gy); float half = biome.TileSize * .5f;
                float dx = Mathf.Max(0, Mathf.Abs(position.x - center.x) - half), dz = Mathf.Max(0, Mathf.Abs(position.z - center.z) - half);
                if (dx * dx + dz * dz <= radius * radius) return true;
            }
            return false;
        }
    }
}
