using System;
using System.Collections.Generic;

namespace Necrocis
{
    public static class ItemTrajectoryCatalog
    {
        public static IReadOnlyList<ItemDefinition> All { get; } = Array.AsReadOnly(new[]
        {
            new ItemDefinition("spiral_fiber", "나선 섬유", "W 탄이 좌우 0.45m로 휘며 전진한다. 왕복 주기 0.45초, 기존 수명과 피해 유지.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("compressed_alveolus", "압축 폐포", "2.5초간 Q·W를 쓰지 않으면 다음 Q·W에 30% 피해의 부채꼴 파동을 추가한다. 반경 1.8m, 각도 100도.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("suture_stinger", "봉합 침", "W의 첫 적중 대상에게 0.4초 뒤 적중 피해 25%를 추가한다. 공격당 1명, 대기시간 0.8초.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("orbit_vesicle", "회전 혈소낭", "W 사용 4회마다 피해 40%의 혈소낭을 추가한다. 반경 1m를 0.25초간 반 바퀴 돈 뒤 전방 발사.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("spinal_hook", "척추 갈고리", "벽에서 소멸할 W 탄이 벽을 따라 최대 1.4m 이동해 첫 적에게 피해 40%를 준다. 탄당 1회, 반사 우선.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("distance_lens", "원거리 수정체", "W 탄이 발사 지점에서 4m 이상 떨어진 뒤 처음 적중하면 해당 피해가 18% 증가한다.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("impact_marrow", "충격 골수", "Q 적중 대상 중 0.9m 이내 가장 가까운 잡몹 1명을 전방으로 최대 0.6m 밀친다. 대기시간 1.8초, 벽에서 정지.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("clasping_tendon", "집게 힘줄", "Q로 맞힌 1.2m 이상 떨어진 첫 잡몹 1명을 최대 0.4m 당긴다. 대기시간 2초, 충돌체 바깥에서 정지.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("burst_valve", "분사 판막", "Q 직후 0.9초 안에 쓴 첫 W에 피해 35%의 좁은 제트를 추가한다. 거리 2m, 최대 1명, 대기시간 2초.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("opening_cartilage", "개방 연골", "W 직후 0.9초 안에 쓴 첫 Q의 범위가 20% 증가한다. 대기시간 2초.", PlayerItemCategory.AttackStyle),
        });
        public static bool Contains(string id)
        {
            foreach (var item in All)
                if (string.Equals(item.ItemId, id, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }
    }
}
