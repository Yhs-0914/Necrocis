using UnityEngine;

namespace Necrocis
{
    public partial class PlayerItemCombatEffects : ISkillItemEffects
    {
        private ItemSkillEffects skillItemEffects;
        private ItemSkillEffects SkillItems => skillItemEffects ?? (skillItemEffects = new ItemSkillEffects(this, Ownership, Attack));
        public void BeginSkillItemCast(SkillCastContext context) { Expansion.SkillStarted(context); SkillItems.BeginCast(context); }
        public float ModifySkillItemDamage(SkillCastContext context, EnemyController enemy, float damage)
            => Expansion.ModifySkill(context.Expansion, enemy, SkillItems.Modify(context, enemy, damage));
        public void NotifySkillItemDirectHit(SkillCastContext context, SkillTargetKey target, Vector3 position, bool killedNormal)
            => SkillItems.DirectHit(context, target, position, killedNormal);
        public void FinishSkillItemCast(SkillCastContext context) => SkillItems.Finish(context);
        public void NotifySkillItemCombatDamage(float actualHpLoss)
        {
            Expansion.CombatDamage(actualHpLoss);
            if (HasItem(PlayerItemIds.RetaliationCortexId)) SkillItems.CombatDamage(actualHpLoss);
        }
    }
}
