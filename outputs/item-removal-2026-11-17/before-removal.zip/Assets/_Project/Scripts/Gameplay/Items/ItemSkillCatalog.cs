using System;
using System.Collections.Generic;

namespace Necrocis
{
    public static class ItemSkillCatalog
    {
        public static IReadOnlyList<ItemDefinition> All { get; } = Array.AsReadOnly(new[]
        {
            new ItemDefinition("reflex_ganglion", "반사 신경절", "E·R 직접 적중 후 2초 안의 첫 Q·W 적중에 피해 30% 추가. 내부 대기시간 3초.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("resonant_bone", "공명 골편", "E·R 한 번으로 서로 다른 적 3명 이상 적중 시 마지막 적중 위치 반경 1.4m에 공격력 45% 충격파. 대기시간 5초.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("mana_reservoir", "마력 저류낭", "Q·W 직접 적중 6회 후 다음 E의 직접 피해 +20%. 공격당 1회 누적, 최대 6회.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("rehearsal_tissue", "복기 조직", "E·R의 모든 피해 판정 종료까지 직접 적중이 없으면 해당 스킬의 남은 대기시간 20% 감소, 최대 2초. 내부 대기시간 10초.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("differentiation_cell", "분화 줄기세포", "E 시전 시 전사: 전방 1.6m 충격파, 궁수: 3m 잔상 화살, 마법사: 0.45초 후 반경 1.2m 파동. 공격력 45%, 시전당 1회.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("residual_muscle", "잔류 근섬유", "R 사용 후 3초 안의 첫 Q 적중 위치 반경 1m에 공격력 35% 충격파. R당 1회.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("medulla_valve", "연수 판막", "E로 잡몹을 직접 처치하면 R의 남은 대기시간 0.7초 감소. E당 1회, 내부 대기시간 4초.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("paired_nerve", "쌍신경 매듭", "E에 적중한 적을 5초 안에 R의 첫 직접 적중으로 맞히면 해당 피해 +20%. 내부 대기시간 8초.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("retaliation_cortex", "반격 피질", "전투 피해로 HP를 잃은 뒤 4초 안에 사용한 첫 E의 직접 피해 +18%. 내부 대기시간 8초.", PlayerItemCategory.AttackStyle),
            new ItemDefinition("long_synapse", "장거리 시냅스", "시전 당시 4m 이상 떨어져 있던 적에게 E·R의 첫 해당 직접 적중 피해 +15%. 시전당 1회.", PlayerItemCategory.AttackStyle),
        });
        public static bool Contains(string id)
        {
            foreach (var item in All)
                if (string.Equals(item.ItemId, id, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }
    }
}
