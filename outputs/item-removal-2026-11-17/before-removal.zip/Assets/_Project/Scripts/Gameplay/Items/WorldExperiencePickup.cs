using System.Collections.Generic;
using UnityEngine;

namespace Necrocis
{
    public sealed class WorldExperiencePickup : MonoBehaviour
    {
        private static readonly List<WorldExperiencePickup> active = new List<WorldExperiencePickup>();
        private int amount;
        private float multiplier;
        private bool resolved, pulling, consumed;
        private string run;
        public static void Spawn(Vector3 position, int amount, bool resolved, float multiplier)
        {
            if (amount <= 0) return;
            var go = new GameObject("ExperiencePickup"); go.transform.position = position + Vector3.up * .25f;
            var pickup = go.AddComponent<WorldExperiencePickup>();
            pickup.amount = amount; pickup.resolved = resolved; pickup.multiplier = multiplier; pickup.run = SaveService.ActiveRunId;
            var visual = go.AddComponent<SpriteRenderer>(); visual.sprite = TextureSpriteCache.GetCircleSprite();
            visual.color = new Color(.3f, .85f, 1); visual.sortingOrder = 5000;
            go.transform.localScale = Vector3.one * TextureSpriteCache.GetUniformScaleForWorldSize(visual.sprite, .2f);
            go.AddComponent<Billboard>().SetUpdateMode(Billboard.UpdateMode.Once); active.Add(pickup);
        }
        public static int PullNearest(PlayerController player, float radius, int maximum)
        {
            if (player == null || player.IsDead) return 0;
            var candidates = new List<WorldExperiencePickup>();
            foreach (var pickup in active)
            {
                if (pickup == null || pickup.consumed || pickup.pulling) continue;
                Vector3 delta = pickup.transform.position - player.transform.position; delta.y = 0;
                if (delta.sqrMagnitude <= radius * radius) candidates.Add(pickup);
            }
            candidates.Sort((a, b) => (a.transform.position - player.transform.position).sqrMagnitude.CompareTo((b.transform.position - player.transform.position).sqrMagnitude));
            int count = Mathf.Min(maximum, candidates.Count);
            for (int i = 0; i < count; i++) candidates[i].pulling = true;
            return count;
        }
        private void Update()
        {
            if (Time.deltaTime <= 0 || consumed) return;
            var player = PlayerController.Instance;
            if (player == null || player.IsDead) return;
            Vector3 target = player.transform.position + Vector3.up * .25f;
            Vector3 delta = target - transform.position; delta.y = 0;
            if (delta.sqrMagnitude <= .7f * .7f) { Grant(); Destroy(gameObject); }
            else if (pulling) transform.position = Vector3.MoveTowards(transform.position, target, 8 * Time.deltaTime);
        }
        private void Grant()
        {
            if (consumed || amount <= 0 || run != SaveService.ActiveRunId) return;
            consumed = true;
            if (resolved) LevelUpManager.AddResolvedEnemyKillExp(amount); else LevelUpManager.AddEnemyKillExp(amount, multiplier);
        }
        private void OnDestroy()
        {
            active.Remove(this);
            // Scene travel must not discard experience already earned in this run.
            if (Application.isPlaying) Grant();
        }
    }
}
