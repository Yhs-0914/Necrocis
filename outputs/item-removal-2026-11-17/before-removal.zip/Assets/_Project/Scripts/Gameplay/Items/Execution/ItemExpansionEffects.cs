using System;
using System.Collections.Generic;
using UnityEngine;

namespace Necrocis
{
    // One context per player input, shared by its rays/projectiles. Extras never emit direct-hit events.
    internal sealed class ItemExpansionAttack
    {
        internal ItemExpansionEffects Owner;
        internal uint Lifetime;
        internal bool Skill, Ranged, Counted, BossCounted, SlowExtended, AfterimageUsed;
        internal readonly Dictionary<string, uint> Versions = new Dictionary<string, uint>();
        internal readonly HashSet<SkillTargetKey> FrozenApplied = new HashSet<SkillTargetKey>();
        internal readonly HashSet<SkillTargetKey> Frozen = new HashSet<SkillTargetKey>(), Compound = new HashSet<SkillTargetKey>();
        internal readonly Dictionary<SkillTargetKey, bool> BleedBefore = new Dictionary<SkillTargetKey, bool>();
        internal readonly Dictionary<SkillTargetKey, bool> PoisonBefore = new Dictionary<SkillTargetKey, bool>();
    }

    internal sealed partial class ItemExpansionEffects
    {
        private sealed class State
        {
            internal float ReadyAt, Until, AuxAt, Value;
            internal int Progress, Charges;
            internal string Context;
            internal uint Version;
        }
        private sealed class TargetState
        {
            internal readonly Dictionary<string, float> Ready = new Dictionary<string, float>();
        }
        private struct DelayedHit
        {
            internal string Id;
            internal uint Version, Generation;
            internal EnemyController Enemy;
            internal float Due, Damage;
        }
        private readonly PlayerItemCombatEffects owner;
        private readonly PlayerStats stats;
        private readonly PlayerController player;
        private readonly ProceduralTerrainMotor terrain;
        private readonly Dictionary<string, State> states = new Dictionary<string, State>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<EnemyLogicalLife, TargetState> targetStates = new Dictionary<EnemyLogicalLife, TargetState>();
        private readonly HashSet<EnemyLogicalLife> defeated = new HashSet<EnemyLogicalLife>();
        private readonly List<DelayedHit> delayed = new List<DelayedHit>();
        private readonly object moveSource = new object();
        private float appliedMove;
        private uint lifetime;
        private bool Alive => owner != null && owner.isActiveAndEnabled && stats != null && !stats.IsDead;
        private bool Has(string id) => Alive && owner.HasItem(id);
        private float Power => stats != null ? Mathf.Max(.1f, stats.AttackPower) : 1;
        private State Get(string id)
        {
            if (!states.TryGetValue(id, out var value)) states.Add(id, value = new State());
            return value;
        }
        private bool Trigger(string id, float cooldown)
        {
            if (!Has(id)) return false;
            var state = Get(id);
            if (Time.time < state.ReadyAt) return false;
            state.ReadyAt = Time.time + cooldown;
            return true;
        }
        private bool TargetReady(string id, EnemyController enemy, float cooldown, bool commit)
        {
            if (!Has(id) || enemy == null || enemy.LogicalLife == null || enemy.LogicalLife.IsRetired) return false;
            var life = enemy.LogicalLife;
            if (!targetStates.TryGetValue(life, out var state)) targetStates.Add(life, state = new TargetState());
            float now = life.Clock(Time.time);
            if (state.Ready.TryGetValue(id, out float ready) && now < ready) return false;
            if (commit) state.Ready[id] = now + cooldown;
            return true;
        }
        internal ItemExpansionEffects(PlayerItemCombatEffects owner)
        {
            this.owner = owner; stats = owner.GetComponent<PlayerStats>(); player = owner.GetComponent<PlayerController>();
            terrain = owner.GetComponent<ProceduralTerrainMotor>(); previousPosition = owner.transform.position;
        }
        private HealthEffectSource Source(string id, string effect = "hit") => owner.GetItemHealthEffectSource(id, effect);
        private void Heal(string id, float amount) { if (Has(id)) stats.Heal(amount, Source(id, "heal")); }
        private static float Distance(Vector3 a, Vector3 b) { a.y = b.y; return (a - b).magnitude; }
        private static EnemyStatusEffectController Status(EnemyController enemy) => enemy != null ? enemy.GetComponent<EnemyStatusEffectController>() : null;
        private static bool Normal(EnemyController enemy) => enemy != null && !enemy.IsElite && !enemy.IsBossEncounter
            && (enemy.Balance == null || enemy.Balance.Current.Tier == MonsterTier.Normal);
        private static EnemyStatusEffectController EnsureStatus(EnemyController enemy)
        {
            var status = Status(enemy);
            if (status == null) { status = enemy.gameObject.AddComponent<EnemyStatusEffectController>(); status.Initialize(enemy); }
            return status;
        }
        private bool Current(ItemExpansionAttack context, string id) => context != null && context.Owner == this
            && context.Lifetime == lifetime && Has(id) && context.Versions.TryGetValue(id, out uint version) && version == Get(id).Version;
        internal ItemExpansionAttack Begin(bool skill, bool ranged)
        {
            var context = new ItemExpansionAttack { Owner = this, Lifetime = lifetime, Skill = skill, Ranged = ranged };
            foreach (var item in ItemExpansionCatalog.All) if (Has(item.ItemId)) context.Versions[item.ItemId] = Get(item.ItemId).Version;
            return context;
        }
        internal void Acquired(string id)
        {
            if (!ItemExpansionCatalog.Contains(id)) return;
            uint version = Get(id).Version + 1;
            states[id] = new State { Version = version };
        }
        internal void Removed(string id)
        {
            if (states.TryGetValue(id, out var state)) { state.Version++; state.Until = state.Value = 0; }
            delayed.RemoveAll(hit => string.Equals(hit.Id, id, StringComparison.OrdinalIgnoreCase));
            RemoveCompanions(id);
            if (id == "target_lymphocyte") marked = null;
            SyncMovementBonus(0);
        }
        internal void Disable()
        {
            lifetime++; delayed.Clear(); SyncMovementBonus(0); RemoveCompanions(null); ClearIndicators();
            marked = null; frictionUntil = 0; dashWalkUntil = 0;
        }
        internal void Tick()
        {
            if (!Alive || Time.deltaTime <= 0) return;
            TickMovement(); TickDefense(); TickCompanions(); TickIndicators();
            for (int i = delayed.Count - 1; i >= 0; i--)
            {
                var hit = delayed[i];
                if (Time.time < hit.Due) continue;
                delayed.RemoveAt(i);
                if (Has(hit.Id) && Get(hit.Id).Version == hit.Version && ItemEnemyQueries.IsTargetable(hit.Enemy)
                    && hit.Enemy.SpawnGeneration == hit.Generation) hit.Enemy.TakeDamage(hit.Damage, Source(hit.Id));
            }
        }
        private void Delay(string id, EnemyController enemy, float seconds, float damage)
            => delayed.Add(new DelayedHit { Id = id, Version = Get(id).Version, Generation = enemy.SpawnGeneration,
                Enemy = enemy, Due = Time.time + seconds, Damage = damage });
        internal void PrepareHit(ItemExpansionAttack context, EnemyController enemy)
        {
            if (context == null || enemy == null) return;
            context.BleedBefore[new SkillTargetKey(enemy)] = Status(enemy)?.IsBleeding == true;
            context.PoisonBefore[new SkillTargetKey(enemy)] = Status(enemy)?.IsPoisoned == true;
        }
        internal float ModifySkill(ItemExpansionAttack context, EnemyController enemy, float damage)
        {
            if (enemy == null || context == null) return damage;
            PrepareHit(context, enemy);
            var status = Status(enemy); var key = new SkillTargetKey(enemy);
            if (status == null) return damage;
            int count = (status.IsPoisoned ? 1 : 0) + (status.IsBleeding ? 1 : 0) + (status.IsSlowed ? 1 : 0);
            if (Current(context, "compound_antigen") && count >= 2 && context.Compound.Count < 2
                && !context.Compound.Contains(key) && TargetReady("compound_antigen", enemy, 6, true))
            { context.Compound.Add(key); damage *= 1.22f; }
            if (Current(context, "frozen_fissure") && status.IsSlowed && context.Frozen.Count < 2
                && !context.Frozen.Contains(key) && TargetReady("frozen_fissure", enemy, 6, true))
            { context.Frozen.Add(key); status.ConsumeSlow(.75f); }
            return damage;
        }
        internal void DirectHit(ItemExpansionAttack context, EnemyController enemy, uint generation, float damage, Vector3 position)
        {
            if (!Alive || context == null || enemy == null || enemy.SpawnGeneration != generation) return;
            bool living = ItemEnemyQueries.IsTargetable(enemy); var status = Status(enemy);
            if (living && Current(context, "target_lymphocyte")) { marked = enemy; markedGeneration = generation; markedUntil = Time.time + 2; }
            if (!context.Counted)
            {
                context.Counted = true;
                if (context.Skill && Current(context, "feeder_sac") && Time.time >= Get("feeder_sac").ReadyAt && ++Get("feeder_sac").Progress >= 3)
                { Get("feeder_sac").Progress = 0; Get("feeder_sac").Until = Time.time + 4; Get("feeder_sac").ReadyAt = Time.time + 8; }
                if (!context.Skill && context.Ranged && Current(context, "pulse_companion") && Time.time >= Get("pulse_companion").ReadyAt
                    && ++Get("pulse_companion").Progress >= 5)
                { Get("pulse_companion").Progress = 0; Get("pulse_companion").ReadyAt = Time.time + 2; if (living) enemy.TakeCompanionDamage(Power * .4f, Source("pulse_companion")); }
            }
            if (!context.BossCounted && enemy.IsBossEncounter && BiomeManager.Active != null && Current(context, "recovery_capsule"))
            {
                context.BossCounted = true; var state = Get("recovery_capsule"); string encounter = VisitKey + "/boss-recovery";
                if (state.Context != encounter) { state.Context = encounter; state.Progress = 0; }
                int used = SaveService.HasItemVisitUse(encounter + "/0") ? (SaveService.HasItemVisitUse(encounter + "/1") ? 2 : 1) : 0;
                if (used < 2 && ++state.Progress >= 12)
                { state.Progress = 0; if (SaveService.TryUseItemVisit(encounter + "/" + used)) Heal("recovery_capsule", 1); }
            }
            if (!living || enemy.SpawnGeneration != generation) return;
            if (Current(context,"frozen_fissure") && context.Frozen.Contains(new SkillTargetKey(enemy)) && context.FrozenApplied.Add(new SkillTargetKey(enemy))) enemy.TakeDamage(Power * .55f, Source("frozen_fissure"));
            if (!ItemEnemyQueries.IsTargetable(enemy) || enemy.SpawnGeneration != generation) return;
            if (!context.Skill && Current(context, "afterimage_fiber") && !context.AfterimageUsed && Time.time <= Get("afterimage_fiber").Until
                && Trigger("afterimage_fiber", 3))
            { context.AfterimageUsed = true; Get("afterimage_fiber").Until = 0; Delay("afterimage_fiber", enemy, .18f, Power * .35f); }
            if (!context.Skill && status != null)
            {
                if (Current(context, "clot_disruptor") && status.IsBleeding && Behind(enemy, 60)
                    && TargetReady("clot_disruptor", enemy, 4, true)) status.ConsumeBleedTick();
                if (!context.Ranged && Current(context, "acid_seal") && status.IsPoisoned && Trigger("acid_seal", 5))
                    AcidPuddle.Spawn(position, .4f, 2, .9f, 1, 1, Source("acid_seal", "acid"));
                if (!context.Ranged && !context.SlowExtended && Current(context, "slow_coagulum") && status.IsSlowed && status.TryExtendBleed(.6f))
                    context.SlowExtended = true;
            }
            if (status != null && Current(context, "nerve_wick") && status.IsBleeding && status.IsPoisoned
                && context.BleedBefore.TryGetValue(new SkillTargetKey(enemy), out bool wasBleeding) && wasBleeding
                && context.PoisonBefore.TryGetValue(new SkillTargetKey(enemy), out bool wasPoisoned) && !wasPoisoned
                && TargetReady("nerve_wick", enemy, 5, true)) enemy.TakeDamage(Power * .25f, Source("nerve_wick"));
        }
        internal void SkillPoisonApplied(ItemExpansionAttack context, EnemyController enemy)
        {
            if (enemy == null || !ItemEnemyQueries.IsTargetable(enemy) || !Current(context, "nerve_wick")) return;
            if (context.BleedBefore.TryGetValue(new SkillTargetKey(enemy), out bool bleeding) && bleeding && TargetReady("nerve_wick", enemy, 5, true))
                enemy.TakeDamage(Power * .25f, Source("nerve_wick"));
        }
        internal void Killed(EnemyController enemy)
        {
            if (!Alive || enemy == null || enemy.LogicalLife == null || !defeated.Add(enemy.LogicalLife)) return;
            var status = Status(enemy);
            if (status != null && status.IsPoisoned && status.PoisonCanTransfer && Trigger("infectious_mucus", 3))
            {
                EnemyController closest = FindClosest(enemy.transform.position, 2, enemy, target => Status(target)?.IsPoisoned != true);
                if (closest != null) status.TransferPoisonTo(EnsureStatus(closest), Source("infectious_mucus", "poison"));
            }
            if (status != null && (status.IsPoisoned || status.IsBleeding) && Has("serum_leech"))
            {
                var state = Get("serum_leech");
                if (Time.time >= state.ReadyAt && ++state.Progress >= 6)
                { state.Progress = 0; state.ReadyAt = Time.time + 12; Heal("serum_leech", 1); }
            }
            if (Normal(enemy) && status != null && status.HasSlowExcluding(Source("cold_bloom", "slow")) && Trigger("cold_bloom", 4))
            {
                int count = 0;
                using var targets = EnemyHitLife.CaptureOwned(EnemyController.ActiveEnemyControllers);
                for (int i = 0; i < targets.Length && count < 2; i++)
                {
                    var life = targets.Buffer[i]; var target = life.Enemy;
                    if (!life.IsActiveCandidate || !Normal(target) || !ItemEnemyQueries.IsTargetable(target) || Distance(enemy.transform.position, target.transform.position) > 1.5f) continue;
                    EnsureStatus(target).ApplyMoveSpeedSlow(.15f, 1.2f, Source("cold_bloom", "slow")); count++;
                }
            }
            if (Has("scar_tissue") && Get("scar_tissue").AuxAt > 0 && Time.time <= Get("scar_tissue").AuxAt && Trigger("scar_tissue", 10))
                Get("scar_tissue").Until = Time.time + 8;
        }
        private bool Behind(EnemyController enemy, float halfAngle)
        {
            Vector3 away = owner.transform.position - enemy.transform.position; away.y = 0;
            Vector3 facing = enemy.LogicalFacingDirection;
            return away.sqrMagnitude > .001f && Vector3.Angle(-facing, away) <= halfAngle;
        }
        private EnemyController FindClosest(Vector3 center, float radius, EnemyController excluded = null, Predicate<EnemyController> predicate = null)
        {
            EnemyController best = null;
            foreach (var enemy in EnemyController.ActiveEnemyControllers)
            {
                if (enemy == excluded || !ItemEnemyQueries.IsTargetable(enemy) || predicate != null && !predicate(enemy)) continue;
                float distance = Distance(center, enemy.transform.position);
                if (distance <= radius) { best = enemy; radius = distance; }
            }
            return best;
        }
        internal void Capture(SavedItemStateData target)
        {
            if (!ItemExpansionCatalog.Contains(target.itemId)) return;
            var state = Get(target.itemId); target.hasExpansionState = true;
            target.expansionCooldownRemaining = Mathf.Max(0, state.ReadyAt - Time.time);
            target.expansionWindowRemaining = Mathf.Max(0, state.Until - Time.time);
            target.expansionAuxRemaining = Mathf.Max(0, state.AuxAt - Time.time);
            target.expansionContext = state.Context;
            target.expansionShield = state.Value; target.expansionProgress = state.Progress; target.expansionCharges = state.Charges;
        }
        internal void Restore(IReadOnlyList<SavedItemStateData> saved)
        {
            Disable(); states.Clear();
            if (saved == null) return;
            foreach (var item in saved)
            {
                if (item == null || !item.hasExpansionState || !owner.HasItem(item.itemId) || !ItemExpansionCatalog.Contains(item.itemId)) continue;
                var state = Get(item.itemId);
                state.ReadyAt = Time.time + Mathf.Clamp(item.expansionCooldownRemaining, 0, 60);
                state.Until = item.expansionWindowRemaining > 0 ? Time.time + Mathf.Clamp(item.expansionWindowRemaining, 0, 30) : 0;
                state.AuxAt = item.expansionAuxRemaining > 0 ? Time.time + Mathf.Clamp(item.expansionAuxRemaining, 0, 30) : 0;
                state.Context = item.expansionContext;
                state.Progress = Mathf.Clamp(item.expansionProgress, 0, 12); state.Charges = Mathf.Clamp(item.expansionCharges, 0, 2);
                state.Value = Mathf.Clamp(item.expansionShield, 0, 3);
            }
            previousPosition = owner.transform.position;
        }
    }
}
