using System.Collections.Generic;
using UnityEngine;

namespace Necrocis
{
    public partial class PlayerItemCombatEffects : ITrajectoryItemEffects
    {
        private ItemTrajectoryEffects trajectoryEffects;
        private ItemTrajectoryEffects Trajectory => trajectoryEffects
            ?? (trajectoryEffects = new ItemTrajectoryEffects(this, Ownership, Attack));
        public bool HasTrajectoryItem(string id) => IsAvailable && HasItem(id);
        public TrajectoryAttackContext BeginTrajectoryAttack(bool ranged, Vector3 direction, float damage, LayerMask mask, float range)
        {
            var context = SkillItems.BeginBasic(Trajectory.Begin(ranged, direction, damage, mask, range), ranged, direction, mask)
                ?? new TrajectoryAttackContext { Ranged = ranged, Direction = direction };
            context.Expansion = Expansion.Begin(false, ranged); Expansion.BasicStarted(ranged); return context;
        }
        public void PrepareTrajectoryDirectHit(TrajectoryAttackContext context, EnemyController enemy) => Expansion.PrepareHit(context?.Expansion, enemy);
        public float ConsumeTrajectoryMeleeRangeMultiplier() => Trajectory.ConsumeMeleeRange();
        public void PrepareTrajectoryMeleeTargets(TrajectoryAttackContext context, IReadOnlyList<EnemyController> targets)
            => Trajectory.PrepareMelee(context, targets);
        public void NotifyTrajectoryDirectHit(TrajectoryAttackContext context, EnemyController enemy, uint generation,
            float damage, Vector3 hitPosition)
        {
            Expansion.DirectHit(context?.Expansion, enemy, generation, damage, hitPosition);
            Trajectory.DirectHit(context, enemy, generation, damage, hitPosition);
            skillItemEffects?.BasicHit(context, enemy, generation, damage, hitPosition);
        }
    }
}
