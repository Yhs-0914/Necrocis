using UnityEngine;

namespace Necrocis
{
    public partial class PlayerItemCombatEffects
    {
        private bool suppressDeferredHitResponse;
        private ItemExpansionEffects expansionEffects;
        internal void ApplyDeferredItemDamage(float amount, HealthEffectSource source)
        { suppressDeferredHitResponse = true; try { GetComponent<PlayerDamageCoordinator>()?.ApplyBypassDamage(amount, source); } finally { suppressDeferredHitResponse = false; } }
        private ItemExpansionEffects Expansion => expansionEffects ?? (expansionEffects = new ItemExpansionEffects(this));
        private void HandleExpansionHealthChanged(CharacterStats sender, CharacterHealthChangedEventArgs args)
            => Expansion.HealthChanged(sender, args);
        public float GetItemDashCooldown(float original) => Expansion.DashCooldown(original);
        public float ItemDashSpeedMultiplier => Expansion.DashSpeedMultiplier;
        public void NotifyItemDashStarted(Vector3 position, float duration) => Expansion.DashStarted(position, duration);
        public void NotifyItemDashEnded(Vector3 position) => expansionEffects?.DashEnded(position);
        public bool TryExpansionLethalGuard() => false;
        internal bool IsItemCombatActive => IsInCombat();
        public void NotifyItemTraversalEnded() => Expansion.TraversalEnded();
        public float GetItemKnockbackMultiplier(EnemyController enemy) => Expansion.KnockbackMultiplier(enemy);
        public void NotifyItemProjectileNearMiss() => Expansion.ProjectileNearMiss();
        public bool TryBlockItemProjectile() => Expansion.BlockProjectile();
        public float ProcessItemCombatDamage(float amount, EnemyDamageRequest request) => Expansion.CombatIncoming(amount, request);
        public float ProcessItemTerrainDamage(float amount, HealthEffectSource source) => Expansion.TerrainIncoming(amount, source);
        public float DeferItemDamage(float amount, HealthEffectSource source) => Expansion.DeferDamage(amount, source);
        private void HandleItemOverheal(float amount) => Expansion.Overheal(amount);
        public void ReflectAppliedDamage(EnemyController enemy, float amount) { if (amount > 0 && enemy != null && !enemy.IsDead && HasReflectiveSkin) enemy.TakeDamage(amount * reflectiveSkinDamageRatio, GetItemHealthEffectSource(ReflectiveSkinId, "reflection")); }
        public float ModifyExpansionCompanionDamage(EnemyController enemy, float damage) => Expansion.CompanionDamage(enemy, damage);
        public void NotifyExpansionCompanionHit(EnemyController enemy, Vector3 position, bool killedNormal = false) => Expansion.CompanionHit(enemy, position, killedNormal);
        public EnemyController GetExpansionPreferredTarget(Vector3 position, float radius) => Expansion.PreferredTarget(position, radius);
        public float ModifyExpansionTargetDamage(EnemyController enemy, float damage) => damage;
        public void NotifyDirectSkillPoison(SkillCastContext cast, EnemyController enemy) => Expansion.SkillPoisonApplied(cast.Expansion, enemy);
        public void NotifyExpansionSkillHit(SkillCastContext cast, EnemyController enemy, uint generation, float damage, Vector3 position) => Expansion.DirectHit(cast.Expansion, enemy, generation, damage, position);
        public void NotifyExpansionHit(EnemyController enemy, uint generation, float damage, Vector3 position)
            { }
    }
}
