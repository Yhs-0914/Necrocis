using System.Collections.Generic;
using UnityEngine;

namespace Necrocis
{
    internal sealed partial class ItemExpansionEffects
    {
        private sealed class Companion
        {
            internal string Id;
            internal GameObject Object;
            internal float Expires, NextAttack, Phase;
            internal EnemyController Target;
            internal uint Generation;
            internal readonly HashSet<EnemyLogicalLife> Hit = new HashSet<EnemyLogicalLife>();
        }
        private readonly List<Companion> companions = new List<Companion>();
        private EnemyController marked;
        private uint markedGeneration;
        private float markedUntil;
        private bool combatWasActive, processingRelay;
        internal EnemyController PreferredTarget(Vector3 center, float radius) => Has("target_lymphocyte") && Time.time < markedUntil
            && ItemEnemyQueries.IsTargetable(marked) && marked.SpawnGeneration == markedGeneration && Distance(center, marked.transform.position) <= radius ? marked : null;
        internal float CompanionDamage(EnemyController enemy, float damage)
            => Has("feeder_sac") && Get("feeder_sac").Until > Time.time ? damage * 1.2f : damage;
        internal void CompanionHit(EnemyController enemy, Vector3 position, bool killedNormal = false)
        {
            if (!killedNormal || processingRelay || !Trigger("relay_colony", 5)) return;
            processingRelay = true;
            try
            {
                var target = FindClosest(position, 4, enemy);
                if (target != null) target.TakeDamage(Power * .3f, Source("relay_colony", "relay"));
            }
            finally { processingRelay = false; }
        }
        internal void SkillStarted(SkillCastContext cast)
        {
            cast.Expansion = Begin(true, false);
            if (cast.Slot == PlayerClassSkillController.SkillSlot.Skill1 && Trigger("marrow_nest", 7))
            { RemoveCompanions("marrow_nest"); AddCompanion("marrow_nest", cast.Origin, 3); }
        }
        internal void BasicStarted(bool ranged)
        {
            if (!ranged && Trigger("patrolling_rib", 4))
            { RemoveCompanions("patrolling_rib"); AddCompanion("patrolling_rib", owner.transform.position, 1.4f); }
        }
        private Companion AddCompanion(string id, Vector3 position, float lifetime = float.PositiveInfinity, float phase = 0)
        {
            var go = new GameObject("ItemCompanion_" + id); go.transform.position = position;
            var sprite = go.AddComponent<SpriteRenderer>(); sprite.sprite = TextureSpriteCache.GetCircleSprite();
            sprite.color = new Color(.6f, .9f, .8f); sprite.sortingOrder = 5100;
            go.transform.localScale = Vector3.one * TextureSpriteCache.GetUniformScaleForWorldSize(sprite.sprite, .4f);
            go.AddComponent<Billboard>().SetUpdateMode(Billboard.UpdateMode.Once);
            var companion = new Companion { Id = id, Object = go, Phase = phase, Expires = Time.time + lifetime };
            companions.Add(companion); return companion;
        }
        private void RemoveCompanions(string id)
        {
            for (int i = companions.Count - 1; i >= 0; i--)
                if (id == null || companions[i].Id == id) RemoveCompanion(companions[i]);
        }
        private void RemoveCompanion(Companion companion)
        {
            companions.Remove(companion);
            if (companion.Object != null) { companion.Object.SetActive(false); UnityEngine.Object.Destroy(companion.Object); }
        }
        private int Count(string id) { int result = 0; foreach (var value in companions) if (value.Id == id) result++; return result; }
        private void TickCompanions()
        {
            if (Trigger("retrieval_tentacle", 1)) WorldExperiencePickup.PullNearest(player, 2.8f, 2);
            bool combat = owner.IsItemCombatActive;
            if (combat && !combatWasActive && Trigger("guardian_spore", 12)) AddCompanion("guardian_spore", owner.transform.position, 8);
            combatWasActive = combat;
            if (Has("predator_larva") && Count("predator_larva") == 0) AddCompanion("predator_larva", owner.transform.position);
            if (Has("bilobed_parasite")) while (Count("bilobed_parasite") < 2) AddCompanion("bilobed_parasite", owner.transform.position, phase: Count("bilobed_parasite") * Mathf.PI);
            foreach (var companion in companions.ToArray())
            {
                if (!companions.Contains(companion)) continue;
                if (!Has(companion.Id) || companion.Object == null || Time.time >= companion.Expires) { RemoveCompanion(companion); continue; }
                Vector3 center = owner.transform.position;
                float angle = Time.time * 3 + companion.Phase;
                if (companion.Id != "marrow_nest" && companion.Target == null)
                {
                    float radius = companion.Id == "patrolling_rib" ? 1.2f : 1;
                    companion.Object.transform.position = center + new Vector3(Mathf.Cos(angle) * radius, .5f, Mathf.Sin(angle) * radius);
                }
                Vector3 position = companion.Object.transform.position;
                if (companion.Id == "guardian_spore")
                {
                    var target = FindClosest(center, 3, predicate: enemy =>
                    { Vector3 to = enemy.transform.position - center; to.y = 0; return Vector3.Angle(-player.GetLogicalFacingDirection(), to) <= 60; });
                    if (target != null) { target.TakeCompanionDamage(Power * .4f, Source(companion.Id)); RemoveCompanion(companion); }
                    continue;
                }
                if (companion.Id == "predator_larva")
                {
                    if (companion.Target != null)
                    {
                        if (!ItemEnemyQueries.IsTargetable(companion.Target) || companion.Target.SpawnGeneration != companion.Generation) { companion.Target = null; continue; }
                        companion.Object.transform.position = Vector3.MoveTowards(position, companion.Target.transform.position, 10 * Time.deltaTime);
                        if (Distance(companion.Object.transform.position, companion.Target.transform.position) <= .5f)
                        { var target = companion.Target; companion.Target = null; target.TakeCompanionDamage(Power * .5f, Source(companion.Id)); }
                    }
                    else if (Time.time >= Get("predator_larva").ReadyAt)
                    {
                        var projectiles = EnemyProjectile.ActiveEnemyProjectiles;
                        for (int i = projectiles.Count - 1; i >= 0; i--)
                        {
                            var projectile = projectiles[i];
                            if (projectile == null || !projectile.IsLaunched || Distance(position, projectile.transform.position) > 1.5f) continue;
                            projectile.Deflect(); Get("predator_larva").ReadyAt = Time.time + 5;
                            companion.Target = PreferredTarget(position, 8) ?? FindClosest(position, 8);
                            companion.Generation = companion.Target != null ? companion.Target.SpawnGeneration : 0; break;
                        }
                    }
                    continue;
                }
                if (Time.time < companion.NextAttack) continue;
                if (companion.Id == "marrow_nest")
                {
                    var target = PreferredTarget(position, 3) ?? FindClosest(position, 3);
                    if (target != null) { companion.NextAttack = Time.time + 1; target.TakeCompanionDamage(Power * .25f, Source(companion.Id)); }
                    continue;
                }
                // The pair shares one line and one per-target interval, never two ranged auto attacks.
                if (companion.Id == "bilobed_parasite" && companion.Phase > 0) continue;
                using var targets = EnemyHitLife.CaptureOwned(EnemyController.ActiveEnemyControllers);
                for (int i = 0; i < targets.Length; i++)
                {
                    var life = targets.Buffer[i]; var enemy = life.Enemy;
                    if (!Has(companion.Id) || !life.IsActiveCandidate || !ItemEnemyQueries.IsTargetable(enemy)) continue;
                    if (companion.Id == "patrolling_rib")
                    {
                        if (Distance(position, enemy.transform.position) <= .55f && companion.Hit.Add(enemy.LogicalLife))
                            enemy.TakeCompanionDamage(Power * .25f, Source(companion.Id));
                    }
                    else
                    {
                        Vector3 first = position, last = center * 2 - position, p = enemy.transform.position;
                        first.y = last.y = p.y = 0; Vector3 line = last - first;
                        float t = line.sqrMagnitude > .001f ? Mathf.Clamp01(Vector3.Dot(p - first, line) / line.sqrMagnitude) : 0;
                        if ((p - first - line * t).sqrMagnitude <= .3f * .3f && TargetReady("bilobed_parasite", enemy, .7f, true))
                            enemy.TakeCompanionDamage(Power * .2f, Source(companion.Id));
                    }
                }
            }
        }
    }
}
