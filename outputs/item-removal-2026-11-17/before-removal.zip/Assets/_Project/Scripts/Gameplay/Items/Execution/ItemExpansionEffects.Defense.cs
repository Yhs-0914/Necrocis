using UnityEngine;

namespace Necrocis
{
    internal sealed partial class ItemExpansionEffects
    {
        private float lastCombatDamage = float.NegativeInfinity;
        private bool belowPulseThreshold;
        internal bool GuardLethal() => false;
        internal void HealthChanged(CharacterStats sender, CharacterHealthChangedEventArgs args) { }
        internal void Overheal(float amount)
        {
            if (!Has("surplus_serum") || amount <= 0) return;
            var state = Get("surplus_serum");
            if (Time.time < state.ReadyAt || state.Charges > 0) return;
            state.Value += amount;
            if (state.Value < 3) return;
            state.Value = 1; state.Charges = 1; state.Until = Time.time + 10; state.ReadyAt = Time.time + 12;
        }
        internal float Incoming(float amount, EnemyController attacker) => amount;
        internal float CombatIncoming(float amount, EnemyDamageRequest request)
        {
            if (!Alive || amount <= 0 || !request.IsCombatDamage) return amount;
            if (Has("landing_pad") && Get("landing_pad").Until > Time.time)
            { amount *= .8f; Get("landing_pad").Until = 0; }
            if (Has("scar_tissue") && Get("scar_tissue").Until > Time.time)
            { amount *= .85f; Get("scar_tissue").Until = 0; }
            if (Has("fibrin_lock") && Get("fibrin_lock").Until > Time.time) amount *= .88f;
            if (request.IsContactDamage && Normal(request.Source) && Has("serous_rind") && Time.time >= Get("serous_rind").ReadyAt
                && Time.time - lastCombatDamage >= 8)
            { amount = Mathf.Max(0, amount - 1); Get("serous_rind").ReadyAt = Time.time + 12; lastCombatDamage = Time.time + 12; }
            if (Has("surplus_serum"))
            {
                var state = Get("surplus_serum");
                if (state.Until > Time.time && state.Charges > 0)
                {
                    float absorbed = Mathf.Min(amount, state.Value); amount -= absorbed;
                    state.Value -= absorbed; // Preserve fractional absorption until the whole shield is spent.
                    if (state.Value <= 0) { state.Value = 0; state.Charges = 0; ShieldBroken(); }
                }
            }
            return Mathf.Max(0, amount);
        }
        internal float TerrainIncoming(float amount, HealthEffectSource source)
        {
            if (!Alive || amount <= 0 || stats.RuntimeStats.PreviewDamage(amount, source).WholeUnits < 1) return amount;
            if (Trigger("shock_absorber", 22)) amount = Mathf.Max(0, amount - 1);
            if (amount > 0 && Has("regional_buffer") && SaveService.TryUseItemVisit(VisitKey + "/regional_buffer")) amount = Mathf.Max(0, amount - 1);
            return amount;
        }
        internal float DeferDamage(float amount, HealthEffectSource source)
        {
            if (stats.RuntimeStats.PreviewDamage(amount, source).WholeUnits < 3 || !Trigger("buffer_fat", 10)) return amount;
            var state = Get("buffer_fat"); state.Value = 1; state.AuxAt = Time.time + 1;
            return Mathf.Max(0, amount - 1);
        }
        internal void ShieldBroken()
        {
            if (Trigger("rupture_platelets", 6)) PushNormals(owner.transform.position, 1.4f, .65f);
        }
        internal void CombatDamage(float hpLoss)
        {
            if (!Alive || hpLoss <= 0) return;
            lastCombatDamage = Time.time;
            if (Trigger("escape_vein", 8)) Get("escape_vein").Until = Time.time + 1.5f;
            if (Has("scar_tissue")) Get("scar_tissue").AuxAt = Time.time + 4;
            if (hpLoss >= 2 && Trigger("fibrin_lock", 14)) Get("fibrin_lock").Until = Time.time + 3;
            bool below = stats.CurrentHealth / Mathf.Max(1, stats.MaxHealth) <= .350001f;
            bool crossed = (stats.CurrentHealth + hpLoss) / Mathf.Max(1, stats.MaxHealth) > .350001f;
            if (below && crossed && Trigger("pulse_stitch", 25)) Get("pulse_stitch").AuxAt = Time.time + 3;
            belowPulseThreshold = below;
        }
        private void TickDefense()
        {
            if (stats.CurrentHealth > stats.MaxHealth * .35f) belowPulseThreshold = false;
            if (Has("surplus_serum") && Get("surplus_serum").Charges > 0 && Get("surplus_serum").Until <= Time.time) { Get("surplus_serum").Charges = 0; Get("surplus_serum").Value = 0; }
            if (Has("pulse_stitch") && Get("pulse_stitch").AuxAt > 0 && Time.time >= Get("pulse_stitch").AuxAt)
            { Get("pulse_stitch").AuxAt = 0; Heal("pulse_stitch", 1); }
            if (Has("buffer_fat") && Get("buffer_fat").Value > 0 && Time.time >= Get("buffer_fat").AuxAt)
            {
                float amount = Get("buffer_fat").Value; Get("buffer_fat").Value = 0; Get("buffer_fat").AuxAt = 0;
                // Same original hit: bypass immunity/reductions and do not emit combat-hit triggers again.
                owner.ApplyDeferredItemDamage(amount, Source("buffer_fat", "deferred"));
            }
        }
        internal void ProjectileNearMiss()
        {
            if (Trigger("leukocyte_barrier", 18)) Get("leukocyte_barrier").Until = Time.time + 2.5f;
        }
        internal bool BlockProjectile()
        {
            if (!Has("leukocyte_barrier") || Get("leukocyte_barrier").Until <= Time.time) return false;
            Get("leukocyte_barrier").Until = 0; return true;
        }
    }
}
