using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Necrocis
{
    public static class ItemExpansionRewards
    {
        public static string CurrentVisitKey
        {
            get
            {
                var biome = BiomeManager.Active;
                return SaveService.ActiveRunId + "/" + (biome != null ? biome.MonsterVisit.VisitId + "/" + biome.BiomeType : "no-biome");
            }
        }
        private static string Family(string id) => ItemReplacementCatalog.CanonicalId(id);
        private static HashSet<string> Tags(string id)
        {
            id = Family(id); var tags = new HashSet<string>();
            if (id.Contains("muc") || id.Contains("infection") || id == "acid_seal" || id == "nerve_wick") tags.Add("poison");
            if (id.Contains("bleed") || id.Contains("hemorr") || id == "slow_coagulum" || id == "clot_disruptor" || id == "bloodtrail_receptor") tags.Add("bleed");
            if (id.Contains("freez") || id.Contains("cold") || id.Contains("frozen") || id == "slow_coagulum") tags.Add("slow");
            if (id.Contains("acid")) tags.Add("acid");
            if (ItemDefinitions.TryGet(id, out var item) && item.Category == PlayerItemCategory.SummonPet
                || id == "blood_drone" || id == "spore_colony" || id == "infected_host" || id == "guardian_organ") tags.Add("summon");
            if (id.Contains("step") || id.Contains("fiber") || id.Contains("vein") || id.Contains("joint")) tags.Add("movement");
            return tags;
        }
        private static bool Regional(string id, BiomeType biome)
        {
            var tags = Tags(id);
            return biome switch
            {
                BiomeType.Intestine => tags.Contains("bleed") || tags.Contains("poison"),
                BiomeType.Liver => tags.Contains("poison"),
                BiomeType.Stomach => tags.Contains("acid"),
                BiomeType.Lung => tags.Contains("movement") || tags.Contains("slow"),
                _ => false
            };
        }
        public static void ApplyToReward(WorldRewardSaveData reward, PlayerItemManager inventory)
        {
            if (reward == null || reward.collected || inventory == null) return;
            var owned = new HashSet<string>(inventory.AcquiredItems.Select(item => item.ItemId), StringComparer.OrdinalIgnoreCase);
            var offers = reward.itemChoices ??= new List<string>();
            var available = inventory.ItemEntries.Where(item => item != null && inventory.CanAcquireItem(item.ItemId)).Select(item => item.ItemId).ToList();
            var guarantees = new List<Predicate<string>>();
            bool changed = false;
            bool Guarantee(string perk, Predicate<string> predicate, string key)
            {
                if (!owned.Contains(perk) || SaveService.HasItemVisitUse(key)) return false;
                if (offers.Any(id => predicate(id)))
                {
                    if (!SaveService.TryUseItemVisit(key)) return false;
                    guarantees.Add(predicate); return true;
                }
                var candidates = available.Where(id => predicate(id) && !offers.Contains(id)).OrderBy(_ => UnityEngine.Random.value).ToList();
                foreach (string selected in candidates)
                {
                    int familySlot = offers.FindIndex(id => Family(id) == Family(selected));
                    for (int slot = offers.Count < 3 ? offers.Count : offers.Count - 1; slot >= 0; slot--)
                    {
                        if (familySlot >= 0 && slot != familySlot) continue;
                        var proposed = new List<string>(offers);
                        if (slot == proposed.Count) proposed.Add(selected); else proposed[slot] = selected;
                        if (!guarantees.All(rule => proposed.Any(id => rule(id))) || !CampaignRewardRules.HasUsableChoice(proposed, owned)) continue;
                        if (!SaveService.TryUseItemVisit(key)) return false;
                        offers.Clear(); offers.AddRange(proposed); guarantees.Add(predicate);
                        changed = true; return true;
                    }
                }
                return false;
            }
            Guarantee("organ_imprint", id => Regional(id, reward.biome), CurrentVisitKey + "/organ_imprint");
            var ownedTags = new HashSet<string>();
            foreach (string id in owned) if (id != "symbiotic_receptor") ownedTags.UnionWith(Tags(id));
            Guarantee("symbiotic_receptor", id => !owned.Contains(id) && Tags(id).Overlaps(ownedTags), CurrentVisitKey + "/symbiotic_receptor");
            if (reward.id != null && reward.id.StartsWith("region.", StringComparison.Ordinal) && reward.id.EndsWith(".boss", StringComparison.Ordinal))
                Guarantee("boss_marrow_seal", id => ItemReplacementCatalog.TryGet(id, out var tier) && tier.Tier > 1
                    && owned.Any(old => ItemReplacementCatalog.TryGet(old, out var lower) && lower.FamilyId == tier.FamilyId && lower.Tier < tier.Tier),
                    SaveService.ActiveRunId + "/boss_marrow_seal/" + reward.biome);
            if (offers.Count > 0 && offers.All(PlayerStatItemCatalog.IsRepeatable))
                Guarantee("redundancy_filter", id => !PlayerStatItemCatalog.TryGet(id, out _) && !owned.Contains(id), CurrentVisitKey + "/redundancy_filter");
            if (changed && SaveService.HasActiveSession) SaveService.TrySaveActiveRun(out _);
        }
        public static bool CanReroll(PlayerItemManager inventory) => inventory != null && inventory.ContainsItem("mutation_lens")
            && !SaveService.HasItemVisitUse(CurrentVisitKey + "/mutation_lens");
        public static bool TryReroll(WorldRewardSaveData reward, PlayerItemManager inventory, string previous)
        {
            if (!CanReroll(inventory) || reward == null || reward.collected || reward.itemChoices == null) return false;
            int index = reward.itemChoices.IndexOf(previous); if (index < 0) return false;
            var owned = inventory.AcquiredItems.Select(item => item.ItemId).ToArray();
            var candidates = inventory.ItemEntries.Where(item => item != null && inventory.CanAcquireItem(item.ItemId)
                && !reward.itemChoices.Any(id => Family(id) == Family(item.ItemId))
                && CampaignRewardRules.HasUsableChoice(reward.itemChoices.Where((id, slot) => slot != index).Append(item.ItemId), owned)).Select(item => item.ItemId).ToList();
            if (candidates.Count == 0 || !SaveService.TryUseItemVisit(CurrentVisitKey + "/mutation_lens")) return false;
            reward.itemChoices[index] = candidates[UnityEngine.Random.Range(0, candidates.Count)];
            if (SaveService.HasActiveSession) SaveService.TrySaveActiveRun(out _);
            return true;
        }
        public static void EnsureMemoryChoice(List<CharacterStatType> choices)
        {
            var inventory = PlayerItemManager.Instance;
            if (inventory == null || !inventory.ContainsItem("marrow_memory") || SaveService.HasItemVisitUse(CurrentVisitKey + "/marrow_memory")) return;
            SaveService.TryUseItemVisit(CurrentVisitKey + "/marrow_memory");
            if (!SaveService.TryGetLastItemStatChoice(out var previousValue)) return;
            var previous = (CharacterStatType)previousValue;
            if (!choices.Contains(previous)) choices[choices.Count - 1] = previous;
        }
        public static void ItemSelected(PlayerController player)
        {
            var items = player != null ? player.GetComponent<PlayerItemCombatEffects>() : null;
            if (items != null && items.HasItem("lymph_reservoir") && SaveService.TryUseItemVisit(CurrentVisitKey + "/lymph_reservoir"))
                player.Stats.Heal(1, items.GetItemHealthEffectSource("lymph_reservoir", "heal"));
        }
        // Kept for pure reward-policy callers; acquisition rules live in CampaignRewardRules.
        public static List<string> Apply(IEnumerable<string> offers, IEnumerable<string> catalog, IEnumerable<string> inventory, int seed)
            => CampaignRewardRules.RefreshOffers(offers, catalog, inventory, null, seed);
    }
}
