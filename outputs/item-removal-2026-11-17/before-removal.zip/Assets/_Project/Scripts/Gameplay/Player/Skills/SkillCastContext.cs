using System;
using System.Collections.Generic;
using UnityEngine;

namespace Necrocis
{
    public readonly struct SkillTargetKey : IEquatable<SkillTargetKey>
    {
        private readonly int actorId;
        private readonly uint generation;
        public SkillTargetKey(EnemyController enemy) { actorId = enemy.GetInstanceID(); generation = enemy.SpawnGeneration; }
        public bool Equals(SkillTargetKey other) => actorId == other.actorId && generation == other.generation;
        public override bool Equals(object obj) => obj is SkillTargetKey other && Equals(other);
        public override int GetHashCode() => unchecked(actorId * 397 ^ (int)generation);
    }

    // One cast stays open through every delayed judgment and projectile flight.
    public sealed class SkillCastContext : IDisposable
    {
        public PlayerClassSkillController Controller { get; }
        public PlayerClassSkillController.SkillSlot Slot { get; }
        public PlayerClassType Class { get; }
        public Vector3 Origin { get; }
        public Vector3 Direction { get; }
        public LayerMask Mask { get; }
        public int DirectHitCount { get; private set; }
        public bool IsComplete { get; private set; }
        public bool IsCancelled { get; private set; }
        internal ItemExpansionAttack Expansion;
        internal ISkillItemEffects Effects;
        internal ItemSkillEffects ItemOwner;
        internal uint ItemLifetime;
        internal Dictionary<string, uint> Versions;
        internal readonly HashSet<SkillTargetKey> FarTargets = new HashSet<SkillTargetKey>();
        internal readonly HashSet<SkillTargetKey> UniqueTargets = new HashSet<SkillTargetKey>();
        internal bool ManaCharged, RetaliationCharged, LongConsumed, PairedAttempted, MedullaConsumed;
        internal Vector3 LastHitPosition;
        private int pendingSources = 1;

        internal SkillCastContext(PlayerClassSkillController controller, PlayerClassSkillController.SkillSlot slot,
            PlayerClassType playerClass, Vector3 origin, Vector3 direction, LayerMask mask, ISkillItemEffects effects)
        { Controller = controller; Slot = slot; Class = playerClass; Origin = origin; Direction = direction; Mask = mask; Effects = effects; }
        internal void Retain() { if (!IsComplete && !IsCancelled) pendingSources++; }
        public void Dispose()
        {
            if (IsComplete || IsCancelled) return;
            if (--pendingSources > 0) return;
            IsComplete = true;
            Controller?.FinishSkillItemCast(this);
        }
        internal void Cancel() { if (!IsComplete) IsCancelled = true; }
        internal DamageResult ApplyDirect(EnemyController enemy, float damage, HealthEffectSource source, Vector3 position)
        {
            if (enemy == null || enemy.IsDead || damage <= 0) return DamageResult.Invalid;
            var key = new SkillTargetKey(enemy);
            uint targetGeneration = enemy.SpawnGeneration;
            float previousHealth = enemy.Stats != null ? enemy.Stats.CurrentHealth : 0;
            bool normal = !enemy.IsElite && !enemy.IsBossEncounter
                && (enemy.Balance == null || enemy.Balance.Current.Tier == MonsterTier.Normal);
            bool active = !IsCancelled && !IsComplete;
            if (active) Retain(); // A synchronous hit callback may return the last projectile to its pool.
            try
            {
                float modified = active && Effects != null ? Effects.ModifySkillItemDamage(this, enemy, damage) : damage;
                DamageResult result = enemy.TryTakeDamage(modified, source);
                if (active && result.HitAccepted)
                {
                    if (Effects is PlayerItemCombatEffects itemEffects)
                    {
                        itemEffects.ApplyCommonOnHitEffects(enemy, modified, position, targetGeneration);
                        itemEffects.NotifyExpansionSkillHit(this, enemy, targetGeneration, modified, position);
                    }
                    DirectHitCount++; UniqueTargets.Add(key); LastHitPosition = position;
                    Effects?.NotifySkillItemDirectHit(this, key, position,
                        normal && previousHealth > 0 && result.HpApplied >= previousHealth);
                }
                return result;
            }
            finally { if (active) Dispose(); }
        }
    }

    public interface ISkillItemEffects
    {
        void BeginSkillItemCast(SkillCastContext context);
        float ModifySkillItemDamage(SkillCastContext context, EnemyController enemy, float damage);
        void NotifySkillItemDirectHit(SkillCastContext context, SkillTargetKey target, Vector3 position, bool killedNormal);
        void FinishSkillItemCast(SkillCastContext context);
    }
}
