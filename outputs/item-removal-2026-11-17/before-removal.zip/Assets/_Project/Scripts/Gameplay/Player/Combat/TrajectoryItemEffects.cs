using System.Collections.Generic;
using UnityEngine;

namespace Necrocis
{
    // Shared by every ray/projectile in one Q/W activation, including delayed proliferation.
    public sealed class TrajectoryAttackContext
    {
        internal ItemExpansionAttack Expansion;
        internal ItemTrajectoryEffects Owner;
        internal uint Lifetime;
        internal uint SutureVersion;
        internal bool Ranged, SutureClaimed, ClaspClaimed, ImpactClaimed;
        internal EnemyController ImpactTarget;
        internal uint ImpactGeneration;
        internal Vector3 Direction;
        internal ItemSkillEffects SkillOwner;
        internal uint SkillLifetime;
        internal Dictionary<string, uint> SkillVersions;
        internal bool ManaCounted;
        internal LayerMask SkillMask;
        public bool IsRanged => Ranged;
    }

    public interface ITrajectoryItemEffects
    {
        bool HasTrajectoryItem(string id);
        TrajectoryAttackContext BeginTrajectoryAttack(bool ranged, Vector3 direction, float damage, LayerMask mask, float range);
        void PrepareTrajectoryDirectHit(TrajectoryAttackContext context, EnemyController enemy);
        float ConsumeTrajectoryMeleeRangeMultiplier();
        void PrepareTrajectoryMeleeTargets(TrajectoryAttackContext context, IReadOnlyList<EnemyController> targets);
        void NotifyTrajectoryDirectHit(TrajectoryAttackContext context, EnemyController enemy, uint generation,
            float damage, Vector3 hitPosition);
    }
}
