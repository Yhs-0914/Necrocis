using UnityEngine;

namespace Necrocis
{
    [DisallowMultipleComponent]
    [DefaultExecutionOrder(-9000)]
    public sealed class PlayerDamageCoordinator : MonoBehaviour
    {
        private PlayerController player;
        private CharacterStats stats;
        private PlayerStats ownerStats;
        private Health health;
        private PlayerItemCombatEffects effects;
        private bool subscribed, resolvingRawDeath, deathNotified;

        public CharacterStats Stats => stats;

        private void Awake() => BindLocal();
        private void OnEnable() => BindLocal();
        private void OnDisable() => Unsubscribe();

        private void BindLocal()
        {
            var ownerStats = GetComponent<PlayerStats>();
            if (ownerStats == null) return;
            Bind(GetComponent<PlayerController>(), ownerStats, GetComponent<Health>(), GetComponent<PlayerItemCombatEffects>());
        }

        public void Bind(PlayerController owner, PlayerStats ownerStats, Health ownerHealth, PlayerItemCombatEffects ownerEffects)
        {
            CharacterStats next = ownerStats != null ? ownerStats.RuntimeStats : null;
            if (stats != next) Unsubscribe();
            player = owner; this.ownerStats = ownerStats; health = ownerHealth; effects = ownerEffects; stats = next;
            if (!subscribed && stats != null && isActiveAndEnabled)
            {
                stats.HealthChanged += HandleHealthChanged;
                subscribed = true;
            }
        }

        private void Unsubscribe()
        {
            if (subscribed && stats != null) stats.HealthChanged -= HandleHealthChanged;
            subscribed = false;
        }

        public void BeginLifetime(bool clearRemainders = true)
        {
            deathNotified = false;
            if (clearRemainders)
            {
                if (ownerStats != null) ownerStats.BeginHealthLifetime();
                else stats?.BeginHealthLifetime();
            }
        }

        public DamageResult TryApplyIncoming(EnemyDamageRequest request)
        {
            if (stats == null || stats.IsDead || deathNotified || request.Amount <= 0f) return DamageResult.Invalid;
            if ((health != null && health.IsInvincible) || (player != null && player.IsDashInvincible))
                return new DamageResult(true, 0f, DamageBlockReason.Invincible);
            effects?.NotifyCombatInteraction();
            EnemyController attacker = request.Source;
            Vector3 sourcePosition = attacker != null ? attacker.transform.position : transform.position - Vector3.forward;
            float amount = effects != null ? effects.ProcessIncomingDamage(request.Amount, attacker) : request.Amount;
            if (amount <= 0f) return new DamageResult(true, 0f, DamageBlockReason.Absorbed);
            if (request.IsTerrainDamage && effects != null) amount = effects.ProcessItemTerrainDamage(amount, request.EffectSource);
            if (request.IsCombatDamage && effects != null)
            {
                amount = effects.ProcessItemCombatDamage(amount, request);
                amount = effects.DeferItemDamage(amount, request.EffectSource);
            }
            if (amount <= 0) return new DamageResult(true, 0, DamageBlockReason.Absorbed);
            uint attackerGeneration = attacker != null ? attacker.SpawnGeneration : 0;
            DamageResult result = ApplyFinalDamage(amount, request.EffectSource, sourcePosition, true);
            if (request.IsCombatDamage && result.HpApplied > 0)
            {
                effects?.NotifySkillItemCombatDamage(result.HpApplied);
                if (attacker != null && attacker.SpawnGeneration == attackerGeneration) effects?.ReflectAppliedDamage(attacker, result.HpApplied);
            }
            return result;
        }

        public DamageResult ApplyBypassDamage(float amount, HealthEffectSource source)
        {
            if (stats == null || stats.IsDead || deathNotified || amount <= 0f) return DamageResult.Invalid;
            return ApplyFinalDamage(amount, source, transform.position - Vector3.forward, false);
        }

        private DamageResult ApplyFinalDamage(float amount, HealthEffectSource source, Vector3 sourcePosition, bool showHit)
        {
            HealthDeltaPreview preview = stats.PreviewDamage(amount, source);
            float? revivalHealth = null;
            if (preview.WholeUnits >= stats.CurrentHealth && effects != null
                && !revivalHealth.HasValue
                && effects.TryConsumeSplitRegeneration(stats.CurrentHealth, stats.MaxHealth, out float reviveHealth))
                revivalHealth = reviveHealth;
            if (showHit && preview.WholeUnits >= 1f && !revivalHealth.HasValue)
                AudioManager.Instance?.PlaySFX("PlayerHit");
            if (!stats.TryApplyDamage(preview, out float applied, revivalHealth)) return DamageResult.Invalid;
            if (applied > 0f) SaveService.RecordPlayerHit(applied, stats.IsDead);
            if (revivalHealth.HasValue)
            {
                ownerStats?.AdvanceHealthEffectGeneration();
                deathNotified = false;
                health?.BeginRevivalProtection();
                return new DamageResult(true, applied, revived: true);
            }
            if (showHit && applied >= 1f)
            {
                CombatVfx.PlayPlayerHit(transform, sourcePosition, applied, stats.IsDead);
                if (!stats.IsDead) health?.BeginHitProtection();
            }
            return new DamageResult(true, applied, died: stats.IsDead);
        }

        private void HandleHealthChanged(CharacterStats sender, CharacterHealthChangedEventArgs args)
        {
            if (args.CurrentValue <= 0f && sender.IsDead) ResolveRawDeath();
        }

        // Compatibility for direct low-level damage or a MaxHP change outside the incoming path.
        public bool ResolveRawDeath()
        {
            if (stats == null) return false;
            if (!stats.IsDead) return true;
            if (resolvingRawDeath || deathNotified) return false;
            resolvingRawDeath = true;
            try
            {
                if (effects != null && stats.MaxHealth > 0f
                    && effects.TryConsumeSplitRegeneration(0f, stats.MaxHealth, out float reviveHealth))
                {
                    if (ownerStats != null) ownerStats.BeginHealthLifetime();
                    else stats.BeginHealthLifetime();
                    stats.AdjustCurrentHealth(Mathf.Clamp(reviveHealth, Mathf.Min(1f, stats.MaxHealth), stats.MaxHealth));
                    health?.BeginRevivalProtection();
                    return true;
                }
                deathNotified = true;
                if (ownerStats != null) ownerStats.BeginHealthLifetime();
                else stats.BeginHealthLifetime();
                health?.NotifyResolvedDeath();
                player?.HandleDeath();
                return false;
            }
            finally { resolvingRawDeath = false; }
        }
    }
}
