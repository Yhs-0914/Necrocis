using System.Collections.Generic;
using UnityEngine;

namespace Necrocis
{
    public partial class PlayerClassSkillController
    {
        private readonly HashSet<SkillCastContext> itemCasts = new HashSet<SkillCastContext>();
        private SkillCastContext BeginSkillItemCast(SkillSlot slot)
        {
            var context = new SkillCastContext(this, slot, currentClass, transform.position, GetFacingDirection(),
                enemyMask, GetComponent<ISkillItemEffects>());
            itemCasts.Add(context);
            context.Effects?.BeginSkillItemCast(context);
            return context;
        }
        internal void FinishSkillItemCast(SkillCastContext context)
        {
            itemCasts.Remove(context);
            if (!context.IsCancelled) context.Effects?.FinishSkillItemCast(context);
        }
        private void CancelSkillItemCasts()
        {
            foreach (var context in itemCasts) context.Cancel();
            itemCasts.Clear();
        }
        public float ReduceRemainingCooldown(SkillSlot slot, float seconds)
        {
            if (seconds <= 0) return 0;
            float before = GetRemainingCooldown(slot);
            float reduced = Mathf.Min(before, seconds);
            if (slot == SkillSlot.Skill1) nextSkill1ReadyTime -= reduced;
            else nextSkill2ReadyTime -= reduced;
            return reduced;
        }
        private DamageResult ApplySkillItemDirectDamage(SkillCastContext context, EnemyController enemy, float damage, HealthEffectSource source)
            => context != null ? context.ApplyDirect(enemy, damage, source, enemy.transform.position) : enemy.TryTakeDamage(damage, source);
    }
}
