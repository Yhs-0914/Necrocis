using UnityEngine;

namespace Necrocis
{
    public partial class Projectile
    {
        private TrajectoryAttackContext trajectoryAttack;
        private Vector3 launchPosition, spiralOffset;
        private float trajectoryAge, wallSlideRemaining;
        private bool wallSlideUsed, isWallSliding;
        private ITrajectoryItemEffects TrajectoryEffects => spawnKind == SpawnKind.Normal && HasItemEffects
            ? itemEffects as ITrajectoryItemEffects : null;
        private bool HasTrajectory(string id) => TrajectoryEffects?.HasTrajectoryItem(id) == true;
        public void BindTrajectoryAttack(TrajectoryAttackContext context) => trajectoryAttack = context;

        private void ResetTrajectoryFlight()
        {
            trajectoryAttack = null; launchPosition = transform.position;
            spiralOffset = Vector3.zero; trajectoryAge = 0;
            wallSlideUsed = isWallSliding = false; wallSlideRemaining = 0;
        }
        private Vector3 TrajectoryStep(float deltaTime, float forwardDistance)
        {
            trajectoryAge += deltaTime;
            Vector3 offset = Vector3.zero;
            if (!isWallSliding && HasTrajectory(PlayerItemIds.SpiralFiberId))
                offset = Vector3.Cross(Vector3.up, moveDirection).normalized
                    * (.45f * Mathf.Sin(trajectoryAge * (Mathf.PI * 2f / .45f)));
            Vector3 step = moveDirection * forwardDistance + offset - spiralOffset;
            spiralOffset = offset;
            return step;
        }
        private float TrajectoryHitMultiplier()
        {
            float result = isWallSliding ? .4f : 1f;
            Vector3 delta = transform.position - launchPosition; delta.y = 0;
            if (currentHitCount == 0 && delta.sqrMagnitude >= 16f && HasTrajectory(PlayerItemIds.DistanceLensId))
                result *= 1.18f;
            return result;
        }
        private void NotifyTrajectoryHit(EnemyController enemy, uint generation, float damage)
            => TrajectoryEffects?.NotifyTrajectoryDirectHit(trajectoryAttack, enemy, generation, damage, transform.position);

        private void ResolveUnreflectedWall(Vector3 normal, ref Vector3 step)
        {
            if (wallSlideUsed || !HasTrajectory(PlayerItemIds.SpinalHookId))
            {
                EndFlight(launchGeneration); step = Vector3.zero; return;
            }
            wallSlideUsed = isWallSliding = true;
            normal.y = 0; normal.Normalize();
            Vector3 tangent = moveDirection - normal * Vector3.Dot(moveDirection, normal);
            if (tangent.sqrMagnitude < .0001f) tangent = Vector3.Cross(Vector3.up, normal);
            moveDirection = tangent.normalized;
            wallSlideRemaining = 1.4f;
            maxHitCount = currentHitCount + 1;
            deactivateTime = Time.time + wallSlideRemaining / Mathf.Max(.01f, currentSpeed);
            step = moveDirection * Mathf.Min(step.magnitude, wallSlideRemaining);
            spiralOffset = Vector3.zero;
        }
    }
}
