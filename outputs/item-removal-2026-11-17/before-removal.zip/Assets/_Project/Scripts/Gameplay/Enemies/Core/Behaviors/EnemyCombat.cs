using System.Collections.Generic;
using UnityEngine;

namespace Necrocis
{
    public partial class EnemyController
    {
        [SerializeField] private bool logDamageToConsole;
        private bool hitByPlayer;
        private bool suppressKillCredit;

        public void TakeFloodDamage(float damage) => TakeFloodDamage(damage, GetHealthEffectSource("legacy-flood"));

        public void TakeFloodDamage(float damage, HealthEffectSource source)
        {
            if (IsDead || IsBossEncounter || stats == null || damage <= 0f) return;
            ApplyIncomingDamage(damage, false, source);
        }

        private float DifficultyAttackCooldown => config != null ? GetRearmCooldown(config.attackCooldown) : 0f;

        public bool TryPerformAttack(float deltaTime)
        {
            if (statusEffectController != null && statusEffectController.IsStunned)
            {
                return false;
            }

            // 공격 애니메이션 재생 중이면 대기
            if (attackAnimPlaying) return false;

            attackTimer -= deltaTime;
            if (attackTimer > 0f) return false;

            // 공격 애니메이션이 있으면 재생 → 완료 시 데미지
            Sprite[] attackFrames = GetAttackFrames();
            if (attackFrames != null && attackFrames.Length > 0)
            {
                attackAnimPlaying = true;
                usingMoveAnimation = false;

                // 대식세포 등: 공격 시 콜라이더 확장
                if (config.expandColliderOnAttack)
                {
                    ExpandAttackCollider();
                }

                UpdateAttackFacing();

                animatedSprite.enabled = true;
                currentLoopFrames = null;
                animatedSprite.PlayOneShot(attackFrames, config.attackAnimationSpeed, OnAttackAnimationComplete);
                return true;
            }

            // 공격 애니메이션이 없으면 즉시 데미지 (기존 동작)
            ApplyDamageToPlayer();
            attackTimer = DifficultyAttackCooldown;
            return false;
        }

        public bool PlayAttackAnimationOnly()
        {
            if (IsDead || config == null || animatedSprite == null || attackAnimPlaying)
            {
                return false;
            }

            Sprite[] attackFrames = GetAttackFrames();
            if (attackFrames == null || attackFrames.Length == 0)
            {
                return false;
            }

            attackAnimPlaying = true;
            usingMoveAnimation = false;
            UpdateAttackFacing();
            animatedSprite.enabled = true;
            currentLoopFrames = null;
            animatedSprite.PlayOneShot(attackFrames, config.attackAnimationSpeed, OnPatternAttackAnimationComplete);
            return true;
        }

        public bool IsPatternAnimationPlaying => attackAnimPlaying;

        public bool PlayPatternAnimation(Sprite[] frames, float frameRate, System.Action onComplete = null, bool returnToIdleOnComplete = true)
        {
            if (IsDead || animatedSprite == null || frames == null || frames.Length == 0 || attackAnimPlaying)
            {
                return false;
            }

            attackAnimPlaying = true;
            usingMoveAnimation = false;
            currentLoopFrames = null;
            animatedSprite.enabled = true;
            animatedSprite.PlayOneShot(frames, Mathf.Max(0.01f, frameRate), () =>
            {
                attackAnimPlaying = false;
                if (colliderExpanded)
                {
                    RestoreCollider();
                }

                if (returnToIdleOnComplete)
                {
                    SetIdleAnimation();
                }

                onComplete?.Invoke();
            });
            return true;
        }


        private void OnAttackAnimationComplete()
        {
            attackAnimPlaying = false;
            attackTimer = DifficultyAttackCooldown;

            // A synchronous damage callback can retire/reuse this component.
            uint generation=SpawnGeneration;
            ApplyDamageToPlayer();
            if(generation!=SpawnGeneration||IsRetiringLifetime||!gameObject.activeInHierarchy)return;

            // 콜라이더 복원
            if (colliderExpanded)
            {
                RestoreCollider();
            }

            // 대기 애니메이션으로 복귀
            SetIdleAnimation();
        }

        private void OnPatternAttackAnimationComplete()
        {
            attackAnimPlaying = false;
            if (colliderExpanded)
            {
                RestoreCollider();
            }

            SetIdleAnimation();
        }


        private void ApplyDamageToPlayer()
        {
            PlayerController player = PlayerController.Instance;
            if (player == null) return;

            float damage = EnemyCombatCalculator.GetAttackDamage(stats, config);

            if (config.isRanged)
            {
                LaunchProjectile(damage);
                return;
            }

            if (!CanMeleeDamagePlayer(player))
            {
                return;
            }

            Health playerHealth = player.HealthComponent;
            if (playerHealth == null) return;

            if (!IsBossEncounter)
            {
                AudioManager.Instance?.PlaySFX("EnemyAttack");
            }
            player.TakeDamage(CreateAttackDamage(damage));
        }


        private bool CanMeleeDamagePlayer(PlayerController player)
        {
            if (player == null || config == null) return false;
            Vector3 delta = player.transform.position - GetCurrentPosition(); delta.y = 0;
            float range = GetEffectiveMeleeAttackRange(player);
            if (delta.sqrMagnitude > range * range) return false;
            if (player.HitCollider != null && TryGetMeleeAttackBounds(out Bounds attackBounds))
                return CombatHitGeometry.BoundsTouchCollider(attackBounds, player.HitCollider, MeleeContactSkin(player));
            return true;
        }

        private bool TryGetMeleeAttackBounds(out Bounds bounds)
        {
            bounds = default;
            if (config == null)
            {
                return false;
            }

            Vector3 localCenter = config.expandColliderOnAttack ? config.attackColliderCenter : config.colliderCenter;
            Vector3 localSize = config.expandColliderOnAttack ? config.attackColliderSize : config.colliderSize;
            if (localSize.x <= 0f || localSize.y <= 0f || localSize.z <= 0f)
            {
                return false;
            }

            Vector3 scaledSize = Vector3.Scale(localSize, Abs(transform.lossyScale));
            bounds = new Bounds(transform.TransformPoint(localCenter), scaledSize);
            return true;
        }


        private static Vector3 Abs(Vector3 value)
        {
            return new Vector3(Mathf.Abs(value.x), Mathf.Abs(value.y), Mathf.Abs(value.z));
        }


        private void LaunchProjectile(float damage)
        {
            Sprite projSprite = config.projectileSprite; // null이면 EnemyProjectile에서 기본 구체 사용

            Vector3 spawnPos = GetCurrentPosition();
            Vector3 toPlayer = PlayerController.Instance.transform.position - spawnPos;
            toPlayer.y = 0f;
            if (toPlayer.sqrMagnitude < 0.0001f) return;

            Vector3 dir = toPlayer.normalized;
            spawnPos += dir * config.projectileSpawnOffset;
            spawnPos.y += 2f;

            // 스프라이트 방향 업데이트
            if (spriteRenderer != null)
            {
                spriteRenderer.flipX = dir.x < 0f;
            }

            EnemyProjectile proj = EnemyProjectile.Acquire(spawnPos, projSprite, config.projectileScale);
            if (!IsBossEncounter)
            {
                AudioManager.Instance?.PlaySFX("EnemyAttack");
            }
            proj.Launch(dir, damage, config.projectileSpeed, config.projectileLifeTime, this);
        }

        public void TakeCompanionDamage(float damage, HealthEffectSource source)
        {
            var items = PlayerController.Instance != null ? PlayerController.Instance.GetComponent<PlayerItemCombatEffects>() : null;
            uint generation = SpawnGeneration;
            Vector3 position = transform.position;
            float modified = items != null ? items.ModifyExpansionCompanionDamage(this, damage) : damage;
            bool normal = !IsElite && !IsBossEncounter;
            DamageResult result = ApplyIncomingDamage(modified, true, source, false);
            if (result.HitAccepted && SpawnGeneration == generation) items?.NotifyExpansionCompanionHit(this, position, result.Died && normal);
        }

        public void TakeDamage(float damage) => TryTakeDamage(damage, HealthEffectSource.Legacy);
        public void TakeDamage(float damage, HealthEffectSource source) => TryTakeDamage(damage, source);
        public DamageResult TryTakeDamage(float damage, HealthEffectSource source) => ApplyIncomingDamage(damage, true, source);

        private DamageResult ApplyIncomingDamage(float damage, bool fromPlayer, HealthEffectSource source, bool allowHostSpawn = true)
        {
            if (IsDead || IsRetiringLifetime || stats == null || damage <= 0f) return DamageResult.Invalid;
            uint expectedGeneration = SpawnGeneration;
            float finalDamage = fromPlayer ? EnemyCombatCalculator.GetIncomingDamage(damage, statusEffectController) : damage;
            if (finalDamage <= 0f) return DamageResult.Invalid;
            HealthDeltaPreview preview = stats.PreviewDamage(finalDamage, source);
            DamageBlockReason block = damageGate != null ? damageGate.EvaluateDamage(this, finalDamage, preview) : DamageBlockReason.None;
            if (SpawnGeneration != expectedGeneration || !gameObject.activeInHierarchy) return DamageResult.Invalid;
            if (block != DamageBlockReason.None)
            {
                var blocked = new DamageResult(true, 0f, block);
                if (fromPlayer)
                {
                    hitByPlayer = true;
                    DamageAccepted?.Invoke(this);
                }
                return blocked;
            }
            float previousHealth = stats.CurrentHealth;
            if (!stats.TryApplyDamage(preview, out float appliedDamage)) return DamageResult.Invalid;
            if (SpawnGeneration != expectedGeneration || !gameObject.activeInHierarchy)
                return new DamageResult(true, appliedDamage);
            var result = new DamageResult(true, appliedDamage);
            if (fromPlayer)
            {
                hitByPlayer = true;
                DamageAccepted?.Invoke(this);
                if (SpawnGeneration != expectedGeneration || !gameObject.activeInHierarchy) return result;
                PlayerController.Instance?.GetComponent<PlayerItemCombatEffects>()?.NotifyCombatInteraction();
                    var metrics = SaveService.BalanceMetrics;
                    if (metrics != null)
                    {
                        float effectiveDamage = Mathf.Max(0f, previousHealth - stats.CurrentHealth);
                        metrics.enemyDamageDealt += effectiveDamage;
                        var biome = BiomeManager.Active;
                        if (biome != null && biome.BiomeType != BiomeType.None)
                        {
                            var row = metrics.Region(biome.BiomeType);
                            if (IsBossEncounter) row.bossDamage += effectiveDamage;
                            else if (IsElite) row.eliteDamage += effectiveDamage;
                            else row.normalDamage += effectiveDamage;
                        }
                        if (FinalBossArena.Instance != null && IsBossEncounter) metrics.finalBossDamage += effectiveDamage;
                    }
                if (appliedDamage > 0f) DamageTaken?.Invoke(this, appliedDamage);
                if (SpawnGeneration != expectedGeneration || !gameObject.activeInHierarchy) return result;
            }
            if (appliedDamage > 0f) CombatVfx.PlayEnemyHit(this, appliedDamage, stats.IsDead);
            if (fromPlayer && logDamageToConsole && config != null && !config.isElite)
            {
                string enemyName = string.IsNullOrWhiteSpace(config.name) ? gameObject.name : config.name;
                Debug.Log($"[DamageLog] Player -> {enemyName} : {appliedDamage:0.##} (HP {stats.CurrentHealth:0.##}/{stats.MaxHealth:0.##})");
            }
            bool defeated = stats.IsDead;
            if (defeated)
            {
                if (defeatEventRaised) return new DamageResult(true, appliedDamage, died: true);
                suppressKillCredit = !fromPlayer && !hitByPlayer;
                if (!IsBossEncounter) AudioManager.Instance?.PlaySFX("EnemyDeath");
                if (!suppressKillCredit) EnemyDefeatBindings.NotifyPlayerKill(this, allowHostSpawn);
                if (SpawnGeneration != expectedGeneration || !gameObject.activeInHierarchy) return result;
                RaiseDefeated();
                if (SpawnGeneration == expectedGeneration && gameObject.activeInHierarchy) ChangeState(EnemyDeadState.Instance);
            }
            else if (appliedDamage > 0f && !IsBossEncounter) AudioManager.Instance?.PlaySFX("EnemyHit");
            return new DamageResult(true, appliedDamage, died: defeated);
        }

        public void GrantExp()
        {
            if (config == null || experienceGranted) return;
            experienceGranted = true;
            if (SuppressExperienceReward || suppressKillCredit || IsBossEncounter) return;
            float multiplier = DifficultyBalanceService
                .GetEnemyBalance(IsBossEncounter)
                .experienceReward;
            WorldExperiencePickup.Spawn(transform.position, Balance != null ? Balance.Current.Experience : config.expReward, Balance != null, multiplier);

            int experience = Balance != null ? Balance.Current.Experience : config.expReward;
            var biome = BiomeManager.Active;
            if (biome != null && experience > 0)
            {
                var itemSpawner = biome.GetComponent<WorldItemSpawner>();
                if (itemSpawner == null) itemSpawner = biome.gameObject.AddComponent<WorldItemSpawner>();
                itemSpawner.TrySpawnEnemyReward(this);
            }
            if (biome != null && experience > 0)
            {
                var row = SaveService.BalanceMetrics?.Region(biome.BiomeType);
                if (row != null)
                {
                    if (IsElite) row.eliteKills++; else row.normalKills++;
                    row.experience += experience;
                }
                if (!IsElite)
                    WorldRecoveryPickup.Spawn(SaveService.RegisterNormalKillForRecovery(biome.BiomeType, transform.position));
            }

            // 엘리트 스포너에 킬 알림
            if (EliteSpawner.Instance != null && !IsElite && !IsBossEncounter)
            {
                EliteSpawner.Instance.NotifyEnemyKilled(config.name);
            }
        }

        public void ExpandAttackCollider()
        {
            if (boxCollider == null || config == null || colliderExpanded) return;
            boxCollider.size = config.attackColliderSize;
            boxCollider.center = config.attackColliderCenter;
            colliderExpanded = true;
        }

        public void RestoreCollider()
        {
            if (boxCollider == null || config == null || !colliderExpanded) return;
            boxCollider.size = config.colliderSize;
            boxCollider.center = config.colliderCenter;
            colliderExpanded = false;
        }

        private Sprite[] GetAttackFrames()
        {
            if (config == null) return null;

            // 방향별 공격 스프라이트가 없으면 기본 attackSprites 사용
            bool hasDirectional = config.attackSpritesUp != null && config.attackSpritesUp.Length > 0;
            if (!hasDirectional)
            {
                return config.attackSprites;
            }

            // 방향별 공격 (NK세포)
            int dir = GetAttackDirection();
            switch (dir)
            {
                case 0: return config.attackSpritesUp;                        // 상
                case 1: return config.attackSprites;                          // 우
                case 2: return config.attackSprites;                          // 좌 (flipX로 처리)
                case 3: return config.attackSpritesDown;                      // 하
                default: return config.attackSprites;
            }
        }

        private int GetAttackDirection()
        {
            if (playerTransform == null) return facingDirection;

            Vector3 toPlayer = playerTransform.position - GetCurrentPosition();
            toPlayer.y = 0f;

            if (toPlayer.sqrMagnitude <= 0.000001f)
            {
                return facingDirection;
            }

            return GetPlanarDirection(toPlayer);
        }

        private void UpdateAttackFacing()
        {
            if (spriteRenderer == null || config == null)
            {
                return;
            }

            facingDirection = GetAttackDirection();
            bool hasDirectional = config.attackSpritesUp != null && config.attackSpritesUp.Length > 0;
            if (hasDirectional)
            {
                ApplyFacingFlip();
                return;
            }

            PlayerController player = PlayerController.Instance;
            if (player == null)
            {
                return;
            }

            ApplyFacingFlip();
            Vector3 toPlayer = player.transform.position - GetCurrentPosition();
            if (Mathf.Abs(toPlayer.x) > 0.01f)
            {
                spriteRenderer.flipX = toPlayer.x < 0f;
            }
        }

        public void CancelAttackAnimation()
        {
            if (!attackAnimPlaying) return;
            attackAnimPlaying = false;
            if (colliderExpanded) RestoreCollider();
            SetIdleAnimation();
        }

    }
}
