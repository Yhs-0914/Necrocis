using System.Collections.Generic;

namespace Necrocis
{
    public static partial class SaveService
    {
        private static readonly HashSet<string> temporaryItemUses = new HashSet<string>();
        public static bool HasItemVisitUse(string key) => HasActiveSession
            ? (activeRun.world.itemVisitUses ??= new List<string>()).Contains(key) : temporaryItemUses.Contains(key);
        public static bool TryUseItemVisit(string key)
        {
            if (string.IsNullOrEmpty(key) || HasItemVisitUse(key)) return false;
            if (HasActiveSession) { activeRun.world.itemVisitUses.Add(key); SaveRewardProgress(); }
            else temporaryItemUses.Add(key);
            return true;
        }
        public static bool TryGetLastItemStatChoice(out int stat)
        {
            stat = HasActiveSession ? activeRun.world.lastItemStatChoice : default;
            return HasActiveSession && activeRun.world.hasLastItemStatChoice;
        }
        public static void RememberItemStatChoice(int stat)
        {
            if (!HasActiveSession) return;
            activeRun.world.hasLastItemStatChoice = true; activeRun.world.lastItemStatChoice = stat;
        }
    }
}
