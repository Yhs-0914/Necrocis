using System;
using System.Collections.Generic;

namespace Necrocis
{
    public sealed class ItemReplacementDefinition
    {
        public string Id { get; }
        public string FamilyId { get; }
        public int Tier { get; }
        public string Name { get; }
        public string Description { get; }
        internal ItemReplacementDefinition(string id, string family, int tier, string name, string description)
        { Id = id; FamilyId = family; Tier = tier; Name = name; Description = description; }
    }

    // Family identity is shared by inventory, rewards and saved runtime state.
    public static class ItemReplacementCatalog
    {
        public static IReadOnlyList<ItemReplacementDefinition> All { get; } = Array.AsReadOnly(new[]
        {
            new ItemReplacementDefinition("dilute_mucus", "piercing_mucus", 1, "묽은 점액", "W 투사체가 최대 2명을 관통하고 관통마다 피해가 25% 감소한다."),
            new ItemReplacementDefinition("piercing_mucus", "piercing_mucus", 2, "관통 점액", "W 투사체가 최대 3명을 관통하고 관통마다 피해가 25% 감소한다."),
            new ItemReplacementDefinition("binding_mucus", "piercing_mucus", 3, "결속 점액", "W 투사체가 최대 3명을 관통하고 관통마다 피해가 10% 감소한다."),
            new ItemReplacementDefinition("luminous_tissue", "beam_organ", 1, "발광 조직", "W를 피해 80% 광선으로 변경한다. 광선 한 줄당 가장 가까운 적 1명만 적중한다."),
            new ItemReplacementDefinition("beam_organ", "beam_organ", 2, "광선 기관", "W를 피해 80%의 관통 광선으로 변경한다. 다중핵·후방 발사·세포 증식과 호환된다."),
            new ItemReplacementDefinition("focusing_organ", "beam_organ", 3, "집광 기관", "W를 피해 95%의 관통 광선으로 변경한다. 다중핵·후방 발사·세포 증식과 호환된다."),
            new ItemReplacementDefinition("split_fragment", "split_tissue", 1, "갈라진 조직", "W 적중 시 양옆에 적중 피해 20%의 탄을 1발씩 생성한다. 추가 탄은 다시 분열하지 않는다."),
            new ItemReplacementDefinition("split_tissue", "split_tissue", 2, "분열 조직", "W 적중 시 양옆에 적중 피해 35%의 탄을 1발씩 생성한다. 추가 탄은 다시 분열하지 않는다."),
            new ItemReplacementDefinition("radial_tissue", "split_tissue", 3, "방사 조직", "W 적중 시 양옆에 적중 피해 45%의 탄을 1발씩 생성한다. 추가 탄은 다시 분열하지 않는다."),
            new ItemReplacementDefinition("acid_leak", "acidic_rupture", 1, "산성 누출", "직접 공격 적중 시 반경 1.5m의 산성 장판을 생성한다. 4초간 초당 0.5 피해, 최대 1개."),
            new ItemReplacementDefinition("acidic_rupture", "acidic_rupture", 2, "산성 파열", "직접 공격 적중 시 반경 2m의 산성 장판을 생성한다. 4초간 초당 0.5 피해, 최대 2개."),
            new ItemReplacementDefinition("acid_cyst", "acidic_rupture", 3, "위산 낭종", "직접 공격 적중 시 반경 2.5m의 산성 장판을 생성한다. 4초간 초당 0.5 피해, 최대 2개."),
            new ItemReplacementDefinition("elastic_vessel", "vascular_reflection", 1, "탄성 혈관", "W 투사체가 벽에 최대 1회 반사한다. 기존 사거리와 수명을 사용한다."),
            new ItemReplacementDefinition("vascular_reflection", "vascular_reflection", 2, "혈관 반사", "W 투사체가 벽에 최대 3회 반사한다. 기존 사거리와 수명을 사용한다."),
            new ItemReplacementDefinition("layered_vessel", "vascular_reflection", 3, "겹벽 혈관", "W 투사체가 벽에 최대 4회 반사한다. 기존 사거리와 수명을 사용한다."),
            new ItemReplacementDefinition("dilute_mucosa", "toxic_mucosa", 1, "희석 점막", "직접 공격 적중 시 2초간 1초마다 적중 피해 15%의 중독 피해. 재적중 시 지속시간 갱신."),
            new ItemReplacementDefinition("toxic_mucosa", "toxic_mucosa", 2, "독성 점막", "직접 공격 적중 시 4초간 1초마다 적중 피해 15%의 중독 피해. 재적중 시 지속시간 갱신."),
            new ItemReplacementDefinition("concentrated_mucosa", "toxic_mucosa", 3, "농축 점막", "직접 공격 적중 시 4초간 1초마다 적중 피해 22%의 중독 피해. 재적중 시 지속시간 갱신."),
            new ItemReplacementDefinition("cooling_nerve", "freezing_nerve", 1, "냉각 신경", "직접 공격 적중 시 적 이동속도를 2초간 15% 감소시킨다."),
            new ItemReplacementDefinition("freezing_nerve", "freezing_nerve", 2, "빙결 신경", "직접 공격 적중 시 적 이동속도를 2초간 30% 감소시킨다."),
            new ItemReplacementDefinition("frost_ganglion", "freezing_nerve", 3, "서리 신경절", "직접 공격 적중 시 적 이동속도를 3초간 30% 감소시킨다."),
            new ItemReplacementDefinition("ruptured_capillary", "hemorrhage_organ", 1, "파열 모세혈관", "직접 공격 적중 시 1.6초간 0.8초마다 적중 피해 15%의 출혈 피해. 재적중 시 지속시간 갱신."),
            new ItemReplacementDefinition("hemorrhage_organ", "hemorrhage_organ", 2, "출혈 기관", "직접 공격 적중 시 3.2초간 0.8초마다 적중 피해 15%의 출혈 피해. 재적중 시 지속시간 갱신."),
            new ItemReplacementDefinition("spurting_vessel", "hemorrhage_organ", 3, "분출 혈관", "직접 공격 적중 시 4초간 0.8초마다 적중 피해 15%의 출혈 피해. 재적중 시 지속시간 갱신."),
            new ItemReplacementDefinition("clot_membrane", "platelet_membrane", 1, "응고막", "피해 1을 흡수하는 보호막. 소진 후 28초에 재생한다."),
            new ItemReplacementDefinition("platelet_membrane", "platelet_membrane", 2, "혈소판 막", "피해 1을 흡수하는 보호막. 소진 후 20초에 재생한다."),
            new ItemReplacementDefinition("aggregated_platelets", "platelet_membrane", 3, "응집 혈소판", "피해 2를 흡수하는 보호막. 소진 후 20초에 재생한다."),
            new ItemReplacementDefinition("regeneration_fragment", "recovery_factor", 1, "재생 조각", "전투 시간 60초마다 체력 1을 회복한다."),
            new ItemReplacementDefinition("recovery_factor", "recovery_factor", 2, "회복 인자", "전투 시간 45초마다 체력 1을 회복한다."),
            new ItemReplacementDefinition("regenerative_marrow", "recovery_factor", 3, "재생 골수", "전투 시간 32초마다 체력 1을 회복한다."),
            new ItemReplacementDefinition("blood_larva", "blood_drone", 1, "혈구 유생", "1.5초마다 가장 가까운 적을 공격력 25% 피해로 공격한다."),
            new ItemReplacementDefinition("blood_drone", "blood_drone", 2, "혈액 드론", "1초마다 가장 가까운 적을 공격력 25% 피해로 공격한다."),
            new ItemReplacementDefinition("pulsing_blood_drone", "blood_drone", 3, "박동 혈액 드론", "1초마다 가장 가까운 적을 공격력 35% 피해로 공격한다."),
            new ItemReplacementDefinition("shield_vesicle", "guardian_organ", 1, "방패 소낭", "플레이어 주위를 돌며 5.5초마다 적 투사체 1개를 막는다."),
            new ItemReplacementDefinition("guardian_organ", "guardian_organ", 2, "수호 장기", "플레이어 주위를 돌며 4초마다 적 투사체 1개를 막는다."),
            new ItemReplacementDefinition("layered_guardian", "guardian_organ", 3, "겹막 수호 장기", "플레이어 주위를 돌며 3.2초마다 적 투사체 1개를 막는다."),
        });
        private static readonly Dictionary<string, ItemReplacementDefinition> byId = BuildIndex();
        private static Dictionary<string, ItemReplacementDefinition> BuildIndex()
        {
            var result = new Dictionary<string, ItemReplacementDefinition>(StringComparer.OrdinalIgnoreCase);
            foreach (var item in All) result.Add(item.Id, item);
            return result;
        }
        public static bool TryGet(string id, out ItemReplacementDefinition definition)
        {
            definition = null;
            return id != null && byId.TryGetValue(id, out definition);
        }
        public static string CanonicalId(string id) => TryGet(id, out var item) ? item.FamilyId : id;
        public static int HighestTier(string familyId, IEnumerable<string> owned)
        {
            int tier = 0;
            foreach (string id in owned)
                if (TryGet(id, out var item) && string.Equals(item.FamilyId, familyId, StringComparison.OrdinalIgnoreCase))
                    tier = Math.Max(tier, item.Tier);
            return tier;
        }
        public static bool CanAcquire(string id, IEnumerable<string> owned)
            => !TryGet(id, out var item) || HighestTier(item.FamilyId, owned) < item.Tier;
    }
}
