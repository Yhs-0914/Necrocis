using System;
using System.Collections.Generic;
using System.Linq;

namespace Necrocis
{
    public enum ItemDropScenario { OriginalTable, ReviewMemo }

    public enum CampaignRewardRole { Attack, Survival, Utility }

    public static class CampaignRewardRules
    {
        public const string StarterRewardId = "campaign.starter-mutation";
        public const int NormalKillsPerRecovery = 30;
        public const int RecoveriesPerRegion = 3;
        public const float RecoveryHealth = 2f;
        public const float NormalItemDropChance = 0f;
        public const float EliteItemDropChance = 0.15f;

        public static bool ShouldDropItem(MonsterTier tier, float roll) => ShouldDropItem(tier, roll, ItemDropScenario.ReviewMemo);
        public static bool ShouldDropItem(MonsterTier tier, float roll, ItemDropScenario scenario) => tier == MonsterTier.Boss
            || (roll >= 0f && roll < (scenario == ItemDropScenario.OriginalTable
                ? (tier == MonsterTier.Elite ? .10f : .01f) : (tier == MonsterTier.Elite ? EliteItemDropChance : NormalItemDropChance)));

        // Draw from the entire catalog without job preferences or role quotas.
        public static List<string> ChooseStarterOffers(IEnumerable<string> catalog, IEnumerable<string> owned, int seed)
        {
            var excluded = new HashSet<string>(owned ?? Array.Empty<string>(), StringComparer.OrdinalIgnoreCase);
            var available = (catalog ?? Array.Empty<string>()).Where(id => !string.IsNullOrWhiteSpace(id)
                    && ItemReplacementCatalog.CanAcquire(id, excluded)
                    && (!excluded.Contains(id) || PlayerStatItemCatalog.IsRepeatable(id)))
                .Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(id => id, StringComparer.Ordinal).ToList();
            var random = new Random(seed);
            var result = new List<string>(3);
            while (result.Count < 3 && available.Count > 0)
            {
                int index = random.Next(available.Count);
                result.Add(available[index]);
                available.RemoveAll(id => SameFamily(id, result[result.Count - 1]));
            }
            EnsureUsableChoice(result, catalog, excluded);
            return result;
        }

        private static readonly HashSet<string> survival = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { "exoskeleton", "platelet_membrane", "recovery_factor", "reflective_skin", "bio_barrier",
          "split_regeneration", "imperfect_regeneration", "blood_contract", "guardian_organ", "vital_cell", "vital_organ",
          "landing_pad", "escape_vein", "serum_leech", "rupture_platelets", "surplus_serum", "buffer_fat", "scar_tissue",
          "leukocyte_barrier", "shock_absorber", "pulse_stitch", "fibrin_lock", "serous_rind", "recovery_capsule", "lymph_reservoir", "regional_buffer" };
        private static readonly HashSet<string> utility = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { "homing_cell", "hypertrophy_cell", "piercing_mucus", "pulse_bullet", "vascular_reflection",
          "freezing_nerve", "overclock_nerve", "muscle_spasm", "gluttonous_organ", "tentacle_colony", "elastic_fiber",
          "elongated_fiber", "active_fiber", "ciliated_sole", "friction_mucus", "elastic_joint", "corner_nerve", "twin_step",
          "retrieval_tentacle", "guardian_spore", "scent_receptor", "mutation_lens", "symbiotic_receptor", "redundancy_filter" };

        public static CampaignRewardRole Role(string id) => survival.Contains(ItemReplacementCatalog.CanonicalId(id)) ? CampaignRewardRole.Survival
            : utility.Contains(ItemReplacementCatalog.CanonicalId(id)) ? CampaignRewardRole.Utility : CampaignRewardRole.Attack;

        public static List<string> ChooseOffers(IEnumerable<string> catalog, IEnumerable<string> owned, string preferred, int seed, MonsterTier tier = MonsterTier.Normal)
        {
            var excluded = new HashSet<string>(owned ?? Array.Empty<string>(), StringComparer.OrdinalIgnoreCase);
            var available = (catalog ?? Array.Empty<string>()).Where(id => !string.IsNullOrWhiteSpace(id)
                    && ItemReplacementCatalog.CanAcquire(id, excluded)
                    && (!excluded.Contains(id) || PlayerStatItemCatalog.IsRepeatable(id)))
                .Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(id => id, StringComparer.Ordinal).ToList();
            var random = new Random(seed);
            var result = new List<string>(3);
            foreach (CampaignRewardRole role in Enum.GetValues(typeof(CampaignRewardRole)))
            {
                var pool = available.Where(id => Role(id) == role).ToList();
                if (pool.Count == 0) continue;
                string choice = pool.Find(id => string.Equals(id, preferred, StringComparison.OrdinalIgnoreCase)) ?? WeightedChoice(pool, random, tier);
                result.Add(choice);
                available.RemoveAll(id => SameFamily(id, choice));
            }
            while (result.Count < 3 && available.Count > 0)
            {
                int index = random.Next(available.Count);
                result.Add(available[index]);
                available.RemoveAll(id => SameFamily(id, result[result.Count - 1]));
            }
            EnsureUsableChoice(result, catalog, excluded);
            return result;
        }

        // Keep saved choices stable; replace choices acquired from another box in the meantime.
        public static List<string> RefreshOffers(IEnumerable<string> previous, IEnumerable<string> catalog,
            IEnumerable<string> owned, string preferred, int seed)
        {
            var excluded = new HashSet<string>(owned ?? Array.Empty<string>(), StringComparer.OrdinalIgnoreCase);
            var available = new HashSet<string>((catalog ?? Array.Empty<string>()).Where(id => !string.IsNullOrWhiteSpace(id)
                && ItemReplacementCatalog.CanAcquire(id, excluded)
                && (!excluded.Contains(id) || PlayerStatItemCatalog.IsRepeatable(id))), StringComparer.OrdinalIgnoreCase);
            var result = (previous ?? Array.Empty<string>()).Where(available.Contains)
                .Distinct(StringComparer.OrdinalIgnoreCase).GroupBy(ItemReplacementCatalog.CanonicalId, StringComparer.OrdinalIgnoreCase).Select(group => group.First()).Take(3).ToList();
            if (result.Count == 3) { EnsureUsableChoice(result, catalog, excluded); return result; }
            foreach (string id in ChooseOffers(available, Array.Empty<string>(), preferred, seed))
                if (!result.Any(choice => SameFamily(choice, id)) && result.Count < 3) result.Add(id);
            EnsureUsableChoice(result, catalog, excluded);
            return result;
        }

        private static string WeightedChoice(List<string> pool, Random random, MonsterTier tier)
        {
            int Weight(string id) => tier != MonsterTier.Normal && ItemReplacementCatalog.TryGet(id, out var item) && item.Tier > 1 ? 3 : 1;
            int total = pool.Sum(Weight), roll = random.Next(total);
            foreach (string id in pool) { roll -= Weight(id); if (roll < 0) return id; }
            return pool[0];
        }
        private static bool Ready(string id, HashSet<string> owned)
        {
            bool Has(string family) => owned.Any(value => ItemReplacementCatalog.CanonicalId(value) == family);
            bool poison = Has("toxic_mucosa"), bleed = Has("hemorrhage_organ"), slow = Has("freezing_nerve");
            switch (id)
            {
                case "infectious_mucus": case "acid_seal": return poison;
                case "frozen_fissure": return slow;
                case "bloodtrail_receptor": case "clot_disruptor": return bleed;
                case "nerve_wick": return poison && bleed;
                case "slow_coagulum": return slow && bleed;
                case "compound_antigen": return (poison ? 1 : 0) + (bleed ? 1 : 0) + (slow ? 1 : 0) >= 2;
                case "serum_leech": return poison || bleed;
                case "cold_bloom": return slow;
                case "target_lymphocyte": case "feeder_sac": case "relay_colony": return Has("blood_drone") || Has("infected_host") || Has("spore_colony")
                    || owned.Contains("bilobed_parasite") || owned.Contains("predator_larva") || owned.Contains("marrow_nest");
                default: return true;
            }
        }
        public static bool HasUsableChoice(IEnumerable<string> offers, IEnumerable<string> owned)
        {
            var inventory = new HashSet<string>(owned ?? Array.Empty<string>(), StringComparer.OrdinalIgnoreCase);
            return offers != null && offers.Any(id => Ready(id, inventory));
        }
        private static void EnsureUsableChoice(List<string> offers, IEnumerable<string> catalog, HashSet<string> owned)
        {
            if (offers.Count == 0 || offers.Any(id => Ready(id, owned))) return;
            string fallback = (catalog ?? Array.Empty<string>()).Where(id => Ready(id, owned)
                && ItemReplacementCatalog.CanAcquire(id, owned) && (!owned.Contains(id) || PlayerStatItemCatalog.IsRepeatable(id))
                && !offers.Any(choice => SameFamily(choice, id))).OrderBy(id => id, StringComparer.Ordinal).FirstOrDefault();
            if (fallback != null) offers[offers.Count - 1] = fallback;
        }
        private static bool SameFamily(string first, string second) => string.Equals(ItemReplacementCatalog.CanonicalId(first), ItemReplacementCatalog.CanonicalId(second), StringComparison.OrdinalIgnoreCase);

        public static bool RecoveryDue(int normalKills, int alreadyCreated) => alreadyCreated < RecoveriesPerRegion
            && normalKills >= (alreadyCreated + 1) * NormalKillsPerRecovery;

        public static bool TryUseEncounter(ICollection<string> used, string key)
        {
            if (string.IsNullOrEmpty(key) || used.Contains(key)) return false;
            used.Add(key);
            return true;
        }
    }

}
